#include "PanelModel.h"
#include <array>
#include <algorithm>
namespace ea {
float displayUiScale(int percent,float workAreaHeight) {
    return percent>0 ? std::clamp(percent/100.f,.5f,2.f) : std::clamp(workAreaHeight/900.f,.85f,1.75f);
}
static Layout readable(Layout l) {
    const float sx=l.horizontal?1.5f:220.f/140.f;
    const float sy=l.horizontal?1.4f:730.f/524.f;
    l.width*=sx;l.height*=sy;
    for(auto& c:l.controls) {auto& r=c.bounds;r={r.x*sx,r.y*sy,r.w*sx,r.h*sy};}
    for(auto& heading:l.headings) {
        auto& r=heading.bounds;
        if(!l.horizontal&&heading.text=="MANUAL WRITE") r.y+=6;
        r={r.x*sx,r.y*sy,r.w*sx,r.h*sy};
    }
    return l;
}
std::string commandFor(const std::string& id) {
    if (id.rfind("manual_",0)==0) return "write:"+id.substr(7);
    if (id.rfind("stop_",0)==0) return "onstop:"+id.substr(5);
    for (const auto& group : {"plugin","vol","svol","pan","span","mute","smute"})
        if (id==group) return "group:"+id;
    if (id=="copy_all") return "copy:all";
    if (id=="copy_pan") return "copy:pan";
    if (id=="paste_fill") return "paste:fill";
    if (id=="punch_capture") return "punch";
    return id;
}
Layout makeLayout(bool horizontal, bool shallow) {
    Layout l{horizontal ? (shallow ? 954.f : 666.f) : 140.f, horizontal ? (shallow ? 84.f : 140.f) : 472.f, horizontal,{},{}};
    auto add=[&](std::string id,std::string label,Rect r,std::string icon="",std::string tip="") {
        if(tip.empty()) {
            if(id=="plugin") tip="Write-enable other plug-in parameter automation";
            else if(id=="vol") tip="Write-enable track volume automation";
            else if(id=="svol") tip="Write-enable send volume automation";
            else if(id=="pan") tip="Write-enable track pan and all ReaSurround / ReaSurroundPan automation";
            else if(id=="span") tip="Write-enable send pan automation";
            else if(id=="mute") tip="Write-enable track mute automation";
            else if(id=="smute") tip="Write-enable send mute automation";
            else if(id=="preview") tip="Toggle Latch Preview; Ctrl/Cmd-click suspends/resumes it for A/B comparison; turning it off restores per-track automation control";
            else if(id=="preview_menu") tip="Preview punch, capture all and clear latches";
            else if(id=="capture") tip="Capture current values; Ctrl/Cmd-click captures selected tracks (blinking). Alt/Option captures all; Alt/Option+Shift captures selected tracks";
            else if(id=="punch_capture") tip="Punch captured values into automation during playback";
            else if(id=="join") tip="Automatically rejoin writing when playback resumes";
            else if(id=="match") tip="Clear latches and return to underlying automation";
            else if(id=="copy_all") tip="Copy all source automation; use the time selection to limit its range";
            else if(id=="copy_pan") tip="Copy track pan and ReaSurround / ReaSurroundPan automation";
            else if(id=="paste_fill") tip="Repeat copied automation to fill the time selection";
            else if(id=="paste_menu") tip="Paste at cursor, stretch to selection, repeat fill or copy enabled automation";
            else if(id=="settings") tip="Automation items and run at startup";
            else if(id=="scope") tip="Choose all tracks or selected tracks";
            else if(id.rfind("manual_",0)==0||id.rfind("stop_",0)==0) {
                const auto range=id.substr(id.rfind('_')+1);
                const std::string prefix=id.rfind("stop_",0)==0?"On stop: ":"Manual write: ";
                if(range=="start") tip=prefix+"current values from range start to play/edit position";
                else if(range=="all") tip=prefix+"current values across the time selection, otherwise project range";
                else if(range=="end") tip=prefix+"current values from play/edit position to range end";
                else if(range=="punch") tip=prefix+"current values from first touch/punch position to play/edit position";
                else if(range=="next") tip=prefix+"current values from play/edit position to the next automation point";
            }
        }
        l.controls.push_back({std::move(id),std::move(label),std::move(icon),std::move(tip),r});
    };
    add("suspend","SUSPEND",{8,8,124,21},"","Bypass all track envelopes and automation writing; click again to restore their previous states");
    l.headings.push_back({"WRITE ENABLE",{8,34,124,14}});
    add("plugin","PLUG IN",{8,52,124,22});
    const std::array<const char*,6> ids{"vol","svol","pan","span","mute","smute"};
    const std::array<const char*,6> names{"VOL","S VOL","PAN","S PAN","MUTE","S MUTE"};
    for (int i=0;i<6;++i) add(ids[i],names[i],{8.f+(i%2)*64.f,80.f+(i/2)*25.f,60,21});
    const std::array<const char*,5> ranges{"start","all","end","punch","next"};
    for (int section=0;section<2;++section) {
        const float y=162.f+section*84.f;
        l.headings.push_back({section==0 ? "MANUAL WRITE":"WRITE ON STOP",{8,y-15,124,14}});
        for (int i=0;i<5;++i) {
            const float x=i<3 ? 8.f+i*43.f : 29.f+(i-3)*43.f;
            add(std::string(section==0 ? "manual_":"stop_")+ranges[i],"",{x,y+(i<3 ? 5.f:33.f),38,23},ranges[i]);
        }
    }
    add("join","AUTO JOIN",{8,306,124,21});add("match","AUTO MATCH",{8,332,124,21});
    add("preview","PREVIEW",{8,358,99,21});add("preview_menu","",{111,358,21,21},"down");
    add("capture","CAPTURE",{8,384,99,21});add("punch_capture","",{111,384,21,21},"punchdown");
    l.headings.push_back({"COPY / PASTE",{8,410,124,14}});
    add("copy_all","COPY ALL",{8,429,124,21});add("copy_pan","COPY PAN",{8,455,124,21});
    add("paste_fill","FILL SELECTION",{8,481,103,21});add("paste_menu","",{115,481,17,21},"down");
    // Footer occupies a separate short row; width stays compact.
    if (!horizontal) { l.height=524;add("scope","ALL TRACKS",{8,508,103,15});add("settings","",{115,506,17,17},"gear");return readable(l); }
    l.headings.clear();
    for (auto& c:l.controls) {
        const auto id=c.id;
        if (id=="suspend"||id=="join"||id=="match") c.bounds={8,8.f+(id=="suspend"?0:id=="join"?27:54),124,22};
        else if (id=="preview"||id=="capture") c.bounds={8,89.f+(id=="capture"?27:0),99,22};
        else if(id=="preview_menu"||id=="punch_capture") c.bounds={111,89.f+(id=="punch_capture"?27:0),21,22};
        else if(id=="plugin") c.bounds={148,27,124,22};
        else {
            int index=-1;for(int i=0;i<6;++i) if(id==ids[i]) index=i;
            if(index>=0) c.bounds={148.f+(index%2)*64.f,55.f+(index/2)*27.f,60,22};
            else if(id.rfind("manual_",0)==0||id.rfind("stop_",0)==0) {
                const bool stop=id.rfind("stop_",0)==0;int i=0;while(i<5 && c.icon!=ranges[i]) ++i;
                const float base=stop?420.f:288.f;
                c.bounds={base+(i<3?i*42.f:20.f+(i-3)*42.f),27.f+(i<3?0:29),38,24};
            } else if(id=="copy_all") c.bounds={552,27,106,22};
            else if(id=="copy_pan") c.bounds={552,55,106,22};
            else if(id=="paste_fill") c.bounds={552,83,81,22};
            else if(id=="paste_menu") c.bounds={637,83,21,22};
        }
    }
    l.headings={{"WRITE ENABLE",{148,7,124,14}},{"MANUAL WRITE",{288,7,122,14}},
        {"WRITE ON STOP",{420,7,122,14}},{"COPY / PASTE",{552,7,106,14}}};
    add("scope","ALL TRACKS",{288,115,238,18});add("settings","",{638,115,20,18},"gear");
    if(shallow) {
        // Translate the preview/capture pair and clipboard into independent groups.
        for(auto& c:l.controls) {
            auto& r=c.bounds;
            if(c.id=="suspend"||c.id=="join"||c.id=="match") continue;
            if(c.id=="preview"||c.id=="capture"||c.id=="preview_menu"||c.id=="punch_capture") {r.x+=140;r.y-=81;}
            else if(c.id=="scope") r={148,63,100,15};
            else if(c.id=="settings") r={262,62,20,18};
            else if(c.id=="plugin") r={288,27,58,22};
            else {
                int i=-1;for(int j=0;j<6;++j) if(c.id==ids[j]) i=j;
                if(i>=0) r={352.f+(i/2)*64.f,27.f+(i%2)*27.f,60,22};
                else if(c.id.rfind("manual_",0)==0||c.id.rfind("stop_",0)==0) r.x+=264;
                else if(c.id=="copy_all") r={816,27,62,22};
                else if(c.id=="copy_pan") r={882,27,64,22};
                else if(c.id=="paste_fill") r={816,55,105,22};
                else if(c.id=="paste_menu") r={925,55,21,22};
            }
        }
        l.headings={{"WRITE ENABLE",{288,7,256,14}},{"MANUAL WRITE",{552,7,122,14}},
            {"WRITE ON STOP",{684,7,122,14}},{"COPY / PASTE",{816,7,130,14}}};
    }
    return readable(l);
}
}
