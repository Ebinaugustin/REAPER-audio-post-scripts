#include "ReaperHost.h"
#include <memory>
namespace {
std::unique_ptr<juce::ScopedJuceInitialiser_GUI> gui;
std::unique_ptr<ea::ReaperHost> host;
}
extern "C" REAPER_PLUGIN_DLL_EXPORT int REAPER_PLUGIN_ENTRYPOINT(REAPER_PLUGIN_HINSTANCE instance,reaper_plugin_info_t* info) {
    try {
        if(!info) {host.reset();gui.reset();return 0;}
        if(info->caller_version!=REAPER_PLUGIN_VERSION||!info->GetFunc||!info->Register) return 0;
        gui=std::make_unique<juce::ScopedJuceInitialiser_GUI>();
        juce::MessageManager::getInstance()->setCurrentThreadAsMessageThread();
        host=std::make_unique<ea::ReaperHost>(instance,*info);
        if(!host->initialise()) {host.reset();gui.reset();return 0;}
        return 1;
    } catch(...) {host.reset();gui.reset();return 0;}
}
