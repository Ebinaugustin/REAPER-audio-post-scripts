#pragma once
#include <deque>
#include <string>
#include <map>
#include <sstream>
#include <functional>
#include <algorithm>

namespace ea {
// All access occurs on REAPER's UI thread. Commands are data, never evaluated code.
class NativeBridge {
public:
    bool connected = false;
    bool closing = false;
    std::map<std::string, std::string> state;
    void push(std::string command) {
        if (closing || queue.size() >= 256) return;
        queue.push_back(std::move(command));
    }
    void requestClose() {
        closing = true;
        queue.clear();
        queue.push_back("close");
    }
    const char* next() {
        response.clear();
        if (!queue.empty()) { response = std::move(queue.front()); queue.pop_front(); }
        return response.c_str();
    }
    void publish(const char* packet) {
        if (!packet) return;
        std::istringstream input(packet);
        std::string line;
        while (std::getline(input, line)) {
            const auto separator = line.find('=');
            if (separator != std::string::npos)
                state[line.substr(0, separator)] = line.substr(separator + 1);
        }
    }
    bool flag(const std::string& key) const {
        const auto it = state.find(key);
        return it != state.end() && it->second == "1";
    }
    std::string text(const std::string& key) const {
        const auto it = state.find(key);
        return it == state.end() ? "" : it->second;
    }
    void reset() { connected = closing = false; queue.clear(); state.clear(); response.clear(); }
private:
    std::deque<std::string> queue;
    std::string response;
};
}
