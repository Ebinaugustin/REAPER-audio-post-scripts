#include "AutomationPanel.h"
#include "ReaperHost.h"
#include <cmath>
namespace ea {
static juce::Rectangle<float> rect(Rect r) {return {r.x,r.y,r.w,r.h};}
static juce::Font uiFont(float height,int style=juce::Font::plain) {
   #if JUCE_WINDOWS
    const char* family="Segoe UI";
   #elif JUCE_MAC
    const char* family="Helvetica Neue";
   #else
    const char* family="DejaVu Sans";
   #endif
    return juce::Font(juce::FontOptions(family,height,style));
}
AutomationPanel::AutomationPanel(ReaperHost& h):host(h),layout(makeLayout(false)),theme(host.setting("theme","reaper")),tooltips(this,650) {
    setOpaque(true);setWantsKeyboardFocus(false);setSize(220,730);startTimerHz(10);
}
AutomationPanel::Palette AutomationPanel::palette() const {
    using C=juce::Colour;
    C bg;
    if(theme=="silver") bg=C(0xffe4e7ec);
    else if(theme=="graphite") bg=C(0xff242a2e);
    else if(theme=="midnight") bg=C(0xff111b2b);
    else if(theme=="warm") bg=C(0xff302c28);
    else if(theme=="classic") bg=C(0xff45484a);
    else bg=host.themeBackground();
    const auto accent=host.themeAccent();
    const bool light=bg.getPerceivedBrightness()>.6f;
    return {bg,light?bg.darker(.13f):bg.brighter(.11f),light?C(0xff171b20):C(0xffeef2f4),accent,bg.darker(.5f)};
}
bool AutomationPanel::active(const std::string& id) const {
    if(id=="settings") return host.bridge.flag("items");
    if(id=="scope") return false;
    if(id=="suspend") return host.bridge.flag("suspended");
    if(id.rfind("stop_",0)==0) return host.bridge.flag("onstop_"+id.substr(5));
    for(const auto& group:{"plugin","vol","svol","pan","span","mute","smute"})
        if(id==group) return host.bridge.flag("enabled_"+id);
    return host.bridge.flag(id=="punch_capture"?"punch":id);
}
void AutomationPanel::paint(juce::Graphics& g) {
    const auto p=palette();g.fillAll(p.bg);
    g.addTransform(juce::AffineTransform::scale(scale).translated(offsetX-scrollX*scale,offsetY-scrollY*scale));
    for(const auto& heading:layout.headings) {
        auto r=rect(heading.bounds);g.setColour(p.text.withAlpha(.65f));
        g.setFont(uiFont(11.8f));g.drawText(heading.text,r,juce::Justification::centredLeft,false);
        const float textWidth=juce::GlyphArrangement::getStringWidth(g.getCurrentFont(),heading.text)+8;
        g.setColour(p.text.withAlpha(.17f));g.drawLine(r.getX()+textWidth,r.getCentreY(),r.getRight(),r.getCentreY(),.7f);
    }
    for(const auto& control:layout.controls) {
        const auto r=rect(control.bounds);const bool down=(pressed==control.id&&hover==control.id)||(flash==control.id&&juce::Time::getMillisecondCounterHiRes()<flashUntil);
        const bool selected=active(control.id)&&!(control.id=="capture"&&host.bridge.flag("capture_selected")&&(juce::Time::getMillisecondCounter()/420)%2!=0);
        auto face=selected?(control.id=="preview"?(host.bridge.flag("preview_suspended")?juce::Colour(0xff867043):juce::Colour(0xff24963e)):control.id=="capture"&&host.bridge.flag("capture_selected")?juce::Colour(0xffbb8830):p.accent):p.face;
        if(hover==control.id) face=face.brighter(.08f);
        if(down) face=face.darker(.22f);
        g.setColour(juce::Colours::black.withAlpha(.24f));g.fillRoundedRectangle(r.translated(0,1.5f),4.f);
        g.setGradientFill(juce::ColourGradient(face.brighter(down?.03f:.22f),r.getCentreX(),r.getY(),face.darker(down?.09f:.16f),r.getCentreX(),r.getBottom(),false));
        g.fillRoundedRectangle(r,4.f);
        {
            const juce::Graphics::ScopedSaveState glass(g);
            juce::Path clip;clip.addRoundedRectangle(r.reduced(1),3.5f);g.reduceClipRegion(clip);
            g.setGradientFill(juce::ColourGradient(juce::Colours::white.withAlpha(down?.08f:.24f),r.getCentreX(),r.getY(),juce::Colours::white.withAlpha(.015f),r.getCentreX(),r.getY()+r.getHeight()*.54f,false));
            g.fillRect(r.withHeight(r.getHeight()*.54f));
            g.setColour(p.accent.withAlpha(selected?.13f:.035f));g.fillRect(r.withTrimmedTop(r.getHeight()*.68f));
        }
        g.setColour(selected?face.brighter(.5f).withAlpha(.8f):p.edge);g.drawRoundedRectangle(r.reduced(.4f),4.f,.9f);
        g.setColour(juce::Colours::white.withAlpha(down?.06f:.14f));g.drawRoundedRectangle(r.reduced(1.3f),3.2f,.6f);
        g.setColour(down?juce::Colours::black.withAlpha(.38f):juce::Colours::white.withAlpha(.16f));
        g.drawLine(r.getX()+4,r.getY()+1.2f,r.getRight()-4,r.getY()+1.2f,.7f);
        auto content=r.translated(down?1.f:0.f,down?1.f:0.f);
        const auto ink=selected?face.contrasting():p.text;
        g.setColour(ink);
        if(!control.icon.empty()) icon(g,control.icon,content);
        else {
            auto label=control.label;
            if(control.id=="preview"&&host.bridge.flag("preview_suspended")) label="PREVIEW PAUSED";
            if(control.id=="scope") {
                const auto message=host.bridge.text("message");
                label=message.empty()?(host.bridge.text("scope")=="selected"?"SELECTED TRACKS":"ALL TRACKS"):message;
            }
            g.setFont(uiFont(control.id=="scope"?11.f:15.f,juce::Font::bold));
            g.drawFittedText(label,content.reduced(4,0).toNearestInt(),juce::Justification::centred,1,.8f);
        }
    }
}
void AutomationPanel::resized() {
    const bool horizontal=side==0||side==2||(side==4&&getWidth()>getHeight()*1.4);
    const bool shallow=horizontal&&getHeight()<150*preferredScale;
    layout=makeLayout(horizontal,shallow);
    scale=std::min(preferredScale,std::max(std::min(preferredScale,.85f),std::min(getWidth()/layout.width,getHeight()/layout.height)));
    // Requested small presets remain available; smaller dockers scroll instead of crushing text.
    if(side<0) scale=preferredScale;
    offsetX=std::max(0.f,(getWidth()-layout.width*scale)*.5f);
    offsetY=horizontal?std::max(0.f,(getHeight()-layout.height*scale)*.5f):0.f;
    scrollX=juce::jlimit(0.f,std::max(0.f,layout.width-getWidth()/scale),scrollX);
    scrollY=juce::jlimit(0.f,std::max(0.f,layout.height-getHeight()/scale),scrollY);
    repaint();
}
void AutomationPanel::setDockSide(int next) {if(side!=next) {side=next;scrollX=scrollY=0;resized();}}
void AutomationPanel::refresh() {theme=host.setting("theme","reaper");repaint();}
void AutomationPanel::showMenu(const std::string& kind) {menuPosition=juce::Desktop::getMousePosition();popup(kind);}
void AutomationPanel::setUiScale(float value) {if(std::abs(preferredScale-value)>.001f) {preferredScale=value;resized();}}
void AutomationPanel::timerCallback() {
    const auto p=palette();
    if(p.bg!=lastBackground||p.accent!=lastAccent||host.bridge.flag("capture_selected")) repaint();
    lastBackground=p.bg;lastAccent=p.accent;
}
juce::String AutomationPanel::getTooltip() {
    for(const auto& control:layout.controls) if(control.id==hover)
        return control.tooltip.empty()?juce::String(commandFor(control.id)):juce::String(control.tooltip);
    return {};
}
juce::Point<float> AutomationPanel::logical(juce::Point<float> p) const {return {(p.x-offsetX)/scale+scrollX,(p.y-offsetY)/scale+scrollY};}
std::string AutomationPanel::hit(juce::Point<float> p) const {
    if(!getLocalBounds().toFloat().contains(p)) return "";
    p=logical(p);for(const auto& c:layout.controls) if(rect(c.bounds).contains(p)) return c.id;return "";
}
void AutomationPanel::mouseMove(const juce::MouseEvent& e) {const auto next=hit(e.position);if(next!=hover) {hover=next;repaint();}}
void AutomationPanel::mouseExit(const juce::MouseEvent&) {hover.clear();repaint();}
void AutomationPanel::mouseDrag(const juce::MouseEvent& e) {mouseMove(e);}
void AutomationPanel::mouseDown(const juce::MouseEvent& e) {
    menuPosition=e.getScreenPosition();clickModifiers=e.mods;
    if(e.mods.isPopupMenu()) {pressed.clear();popup("context");return;}
    hover=hit(e.position);pressed=hover;repaint();
}
void AutomationPanel::mouseUp(const juce::MouseEvent& e) {
    menuPosition=e.getScreenPosition();
    const auto id=pressed;pressed.clear();hover=hit(e.position);repaint();
    if(!id.empty()&&id==hover&&!e.mods.isPopupMenu()) {
        flash=id;flashUntil=juce::Time::getMillisecondCounterHiRes()+90;
        const juce::Component::SafePointer<AutomationPanel> safe(this);
        juce::Timer::callAfterDelay(95,[safe] {if(safe) {safe->flash.clear();safe->repaint();}});
        activate(id);
    }
}
void AutomationPanel::mouseWheelMove(const juce::MouseEvent& e,const juce::MouseWheelDetails& wheel) {
    const float maxX=std::max(0.f,layout.width-getWidth()/scale),maxY=std::max(0.f,layout.height-getHeight()/scale);
    if(maxX>0&&!e.mods.isShiftDown()) scrollX=juce::jlimit(0.f,maxX,scrollX-(std::abs(wheel.deltaX)>std::abs(wheel.deltaY)?wheel.deltaX:wheel.deltaY)*100);
    else scrollY=juce::jlimit(0.f,maxY,scrollY-wheel.deltaY*100);
    repaint();
}
void AutomationPanel::activate(const std::string& id) {
    if(id=="preview_menu"||id=="paste_menu"||id=="settings"||id=="scope") {popup(id);return;}
    if(id=="capture") {
        if(clickModifiers.isCommandDown()||(clickModifiers.isAltDown()&&clickModifiers.isShiftDown())) host.enqueue("capture_selected");
        else host.enqueue(clickModifiers.isAltDown()?"capture_all":"capture");
        return;
    }
    if(id=="preview"&&clickModifiers.isCommandDown()) {host.enqueue("preview_suspend");return;}
    host.enqueue(commandFor(id));
}
juce::PopupMenu::Options AutomationPanel::menuOptionsAt(juce::Component* component,juce::Point<int> screen) {
    return juce::PopupMenu::Options().withTargetComponent(component).withTargetScreenArea({screen.x,screen.y,1,1});
}
juce::PopupMenu AutomationPanel::makePopupMenu(const std::string& kind) const {
    juce::PopupMenu menu;
    const auto version=host.bridge.text("version");
    menu.addSectionHeader(version.empty()?"EA Native Automation":"EA Native Automation v"+juce::String(version));
    auto sizes=[&] {
        juce::PopupMenu items;const int percentages[]={0,50,75,100,125,150,175,200};
        for(int i=0;i<8;++i) items.addItem(400+i,percentages[i]==0?"Auto (monitor / DPI)":juce::String(percentages[i])+"%",true,host.uiPercent()==percentages[i]);
        menu.addSubMenu("Window size",items);
    };
    if(kind=="preview_menu") {menu.addItem(1,"Punch preview values");menu.addItem(2,"Capture all enabled values");menu.addItem(3,"Clear preview latches");menu.addItem(4,host.bridge.flag("preview_suspended")?"Resume Preview":"Suspend Preview (A/B)",host.bridge.flag("preview"));}
    else if(kind=="paste_menu") {menu.addItem(11,"Paste at edit cursor");menu.addItem(12,"Paste to selection (stretch)");menu.addItem(13,"Paste to selection (repeat / fill)");menu.addItem(14,"Copy write-enabled automation");}
    else if(kind=="settings") {
        menu.addItem(21,"Use automation items for write / paste",true,host.bridge.flag("items"));
        menu.addItem(22,"Run at startup",true,host.startup());
        sizes();
    } else {
        menu.addItem(31,"All tracks",true,host.bridge.text("scope")!="selected");menu.addItem(32,"Selected tracks",true,host.bridge.text("scope")=="selected");
        menu.addSeparator();
        const char* positions[]={"Dock bottom","Dock left","Dock top","Dock right","Floating Docker"};
        for(int i=0;i<5;++i) menu.addItem(40+i,positions[i],true,host.dockSide()==i);
        menu.addItem(45,"Undock / floating panel",true,host.dockIndex()<0);
        juce::PopupMenu dockers;for(int i=0;i<16;++i) dockers.addItem(100+i,"Docker "+juce::String(i+1),true,host.dockIndex()==i);
        menu.addSubMenu("Choose Docker",dockers);
        juce::PopupMenu themes;
        const char* ids[]={"reaper","graphite","silver","midnight","warm","classic"};
        const char* names[]={"Follow REAPER theme","Graphite","Silver","Midnight","Warm graphite","Classic charcoal"};
        for(int i=0;i<6;++i) themes.addItem(200+i,names[i],true,theme==ids[i]);
        menu.addSubMenu("Theme",themes);
        sizes();
        juce::PopupMenu modes;const char* modeNames[]={"Trim / Read","Read","Touch","Write","Latch","Latch Preview"};
        for(int i=0;i<6;++i) modes.addItem(300+i,modeNames[i]);menu.addSubMenu("Automation mode",modes);
        menu.addSeparator();menu.addItem(50,"Clear capture");menu.addItem(21,"Use automation items for write / paste",true,host.bridge.flag("items"));
        menu.addItem(22,"Run at startup",true,host.startup());menu.addItem(51,"Close");
    }
    return menu;
}
void AutomationPanel::popup(const std::string& kind) {
    auto menu=makePopupMenu(kind);
    const juce::Component::SafePointer<AutomationPanel> safe(this);
    menu.showMenuAsync(menuOptionsAt(this,menuPosition),[safe](int choice) {
        if(!safe||choice==0) return;
        auto& panel=*safe;auto& host=panel.host;
        const std::map<int,std::string> commands={{1,"punch_preview"},{2,"capture_all"},{3,"match"},{4,"preview_suspend"},{11,"paste:cursor"},{12,"paste:fit"},{13,"paste:fill"},{14,"copy:enabled"},{21,"items"},{31,"scope:all"},{32,"scope:selected"},{50,"clear_capture"}};
        const auto it=commands.find(choice);if(it!=commands.end()) host.enqueue(it->second);
        else if(choice==22) host.setStartup(!host.startup());
        else if(choice>=40&&choice<=44) host.dockSide(choice-40);
        else if(choice==45) host.undock();else if(choice==51) host.close();
        else if(choice>=100&&choice<116) host.dock(choice-100);
        else if(choice>=200&&choice<206) {
            const char* ids[]={"reaper","graphite","silver","midnight","warm","classic"};
            panel.theme=ids[choice-200];host.save("theme",panel.theme);panel.repaint();
        } else if(choice>=300&&choice<306) host.enqueue("mode:"+std::to_string(choice-300));
        else if(choice>=400&&choice<408) {const int values[]={0,50,75,100,125,150,175,200};host.setUiPercent(values[choice-400]);}
    });
}
void AutomationPanel::icon(juce::Graphics& g,const std::string& kind,juce::Rectangle<float> r) {
    const float x=r.getCentreX(),y=r.getCentreY();
    const juce::Graphics::ScopedSaveState state(g);
    g.addTransform(juce::AffineTransform::scale(1.35f).translated(x*(1-1.35f),y*(1-1.35f)));
    auto arrow=[&](float centre,float dir) {g.drawArrow({centre-dir*5,y,centre+dir*5,y},1.15f,5,5);};
    if(kind=="start") {g.drawLine(x-10,y-6,x-10,y+6,1.15f);arrow(x,-1);}
    else if(kind=="end") {g.drawLine(x+10,y-6,x+10,y+6,1.15f);arrow(x,1);}
    else if(kind=="all") {g.drawLine(x-12,y-6,x-12,y+6,1.15f);g.drawLine(x+12,y-6,x+12,y+6,1.15f);arrow(x-4,-1);arrow(x+4,1);}
    else if(kind=="punch") {arrow(x-3,-1);g.fillEllipse(x+5,y-2,4,4);}
    else if(kind=="next") {g.fillEllipse(x-9,y-2,4,4);arrow(x+3,1);}
    else if(kind=="down") {juce::Path path;path.startNewSubPath(x-3,y-1);path.lineTo(x,y+2);path.lineTo(x+3,y-1);g.strokePath(path,juce::PathStrokeType(1.5f));}
    else if(kind=="punchdown") {g.drawArrow({x,y-5,x,y+3},1.3f,5,5);g.drawLine(x-5,y+5,x+5,y+5,1.2f);g.drawLine(x-5,y+3,x-5,y+5,1.2f);g.drawLine(x+5,y+3,x+5,y+5,1.2f);}
    else if(kind=="gear") {
        juce::Path path;
        for(int i=0;i<32;++i) {const float a=i*juce::MathConstants<float>::twoPi/32;const float radius=i%4<2?5.8f:4.5f;
            if(i==0) path.startNewSubPath(x+std::cos(a)*radius,y+std::sin(a)*radius);else path.lineTo(x+std::cos(a)*radius,y+std::sin(a)*radius);}
        path.closeSubPath();path.setUsingNonZeroWinding(false);path.addEllipse(x-2,y-2,4,4);g.fillPath(path);
    }
}
}
