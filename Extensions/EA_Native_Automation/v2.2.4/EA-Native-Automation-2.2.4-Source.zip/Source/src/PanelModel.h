#pragma once
#include <string>
#include <vector>
namespace ea {
struct Rect { float x,y,w,h; };
struct Control {
    std::string id,label,icon,tooltip;
    Rect bounds;
};
struct Heading { std::string text; Rect bounds; };
struct Layout { float width,height; bool horizontal; std::vector<Control> controls; std::vector<Heading> headings; };
Layout makeLayout(bool horizontal, bool shallow = false);
std::string commandFor(const std::string& id);
float displayUiScale(int percent,float workAreaHeight);
}
