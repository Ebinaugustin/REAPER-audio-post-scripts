#pragma once
#include "ReaperApi.h"
#include <memory>
namespace ea {
class ReaperHost;
class AutomationPanel;
class NativeWindow {
public:
    explicit NativeWindow(ReaperHost&);
    ~NativeWindow();
    void sync();
    void dock(int index);
    void undock();
    void applyUiScale();
    int dockIndex() const;
    int dockSide() const;
    bool isVisible() const {return handle!=nullptr;}
    void refresh();
    void showMenu(const std::string&);
private:
    ReaperHost& host;
    std::unique_ptr<AutomationPanel> panel;
    HWND handle=nullptr;
    void* embeddedParent=nullptr;
    int oldWidth=-1,oldHeight=-1,oldX=-1,oldY=-1;
    bool sizing=false,moving=false;
    double displayScale=0;
    juce::Rectangle<int> displayArea;
    static INT_PTR dialogProc(HWND,UINT,WPARAM,LPARAM);
    void create();
    void attach();
    void fitFloating(bool keepPosition);
    const juce::Displays::Display* currentDisplay() const;
};
}
