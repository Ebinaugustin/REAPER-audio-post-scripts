#pragma once
#include "ReaperApi.h"
#include "NativeBridge.h"
#include "ActionCatalog.h"
#include <memory>
#include <chrono>
namespace ea {
class NativeWindow;
class ReaperHost {
public:
    ReaperHost(REAPER_PLUGIN_HINSTANCE instance,reaper_plugin_info_t& info);
    ~ReaperHost();
    bool initialise();
    void shutdown();
    void tick();
    void open();
    void close();
    void connect(bool active);
    void publish(const char* state);
    NativeBridge bridge;
    bool visible() const;
    void enqueue(const std::string& command);
    bool handleAction(int command);
    int actionState(int command) const;
    void dock(int index);
    void dockSide(int side);
    void undock();
    int uiPercent() const;
    void setUiPercent(int percent);
    int dockIndex() const;
    int dockSide() const;
    bool startup() const;
    void setStartup(bool);
    std::string setting(const char* key,const char* fallback="") const;
    void save(const char* key,const std::string& value);
    juce::Colour themeBackground() const;
    juce::Colour themeAccent() const;
    void error(const std::string& message) const;
    HWND mainWindow() const {return info.hwnd_main;}
    REAPER_PLUGIN_HINSTANCE moduleInstance() const {return instance;}
private:
    REAPER_PLUGIN_HINSTANCE instance;
    reaper_plugin_info_t info;
    std::unique_ptr<NativeWindow> window;
    gaccel_register_t action{};
    int command=0;
    bool starting=false, startupPending=true, inTick=false,registered=false;
    struct RegisteredAction {int command=0;const ActionDefinition* definition=nullptr;gaccel_register_t accel{};int lastState=-2;};
    std::vector<RegisteredAction> actions;
    std::vector<const ActionDefinition*> pendingActions;
    std::chrono::steady_clock::time_point started;
    void registerApis(bool add);
    void performAction(const ActionDefinition&);
    int definitionState(const ActionDefinition&) const;
    void refreshActions();
};
extern ReaperHost* activeHost;
}
