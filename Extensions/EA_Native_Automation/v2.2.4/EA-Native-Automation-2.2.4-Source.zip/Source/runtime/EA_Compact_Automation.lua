-- @description EA Native Automation - JUCE panel
-- @version 2.2.4
-- @author Ebin Augustin / Codex
-- @about Launcher for the compiled REAPER extension. The UI is JUCE/C++.
if not reaper.APIExists('EA_Native_Open') then
  reaper.ShowMessageBox('Install the native extension and its engine folder in REAPER UserPlugins, then restart REAPER. See the native package guide.','EA Native Automation',0)
  return
end
-- The native action toggles the window; opening through this launcher is idempotent.
reaper.EA_Native_Open()
