// Exercise the actual Windows extension ABI without opening REAPER or a panel.
#include "reaper_plugin.h"
#include "ActionCatalog.h"
#include <map>
#include <string>
#include <iostream>
#include <stdexcept>
static std::map<std::string,void*> registrations;
static std::map<std::string,int> commandIds;
static std::map<int,gaccel_register_t*> accelerators;
static std::string failedCommand;
static std::string resourcePath,missingApi,lastScript,lastError;
static std::map<std::string,std::string> savedState;
static int invoked=0;
static int engineStarts=0;
static std::map<int,int> toolbarUpdates;
static void check(bool ok,const char* why) {if(!ok) throw std::runtime_error(why);}
static int registerItem(const char* key,void* value) {
    const std::string name(key);
    if(name=="command_id") {
        const std::string id(static_cast<const char*>(value));
        if(id==failedCommand) return 0;
        const auto found=commandIds.find(id);if(found!=commandIds.end()) return found->second;
        const int command=50001+static_cast<int>(commandIds.size());commandIds[id]=command;return command;
    }
    if(name=="gaccel") {auto* accel=static_cast<gaccel_register_t*>(value);accelerators[accel->accel.cmd]=accel;}
    if(name=="-gaccel") {
        auto* accel=static_cast<gaccel_register_t*>(value);accelerators.erase(accel->accel.cmd);
        if(!accelerators.empty()) return 1;
    }
    if(name[0]=='-') registrations.erase(name.substr(1));
    else registrations[name]=value;
    return 1;
}
static int addScript(bool add,int section,const char* file,bool commit) {
    check(add&&section==0&&commit,"Engine registration arguments");lastScript=file;++engineStarts;return 60000;
}
static void runCommand(int command,int) {invoked=command;}
static const char* getResource() {return resourcePath.c_str();}
static const char* getState(const char* section,const char* key) {return savedState[std::string(section)+":"+key].c_str();}
static void setState(const char* section,const char* key,const char* value,bool) {savedState[std::string(section)+":"+key]=value;}
static int message(const char* text,const char*,int) {lastError=text;return 0;}
static std::map<std::string,int> themeColours;
static int theme(const char* key,int flags) {
    check(flags==0,"Theme colours must include live theme transformations");
    const auto it=themeColours.find(key);return it==themeColours.end()?-1:it->second;
}
static void colour(int value,int* r,int* g,int* b) {*r=value&255;*g=(value>>8)&255;*b=(value>>16)&255;}
static void dockId(const char*,int) {}
static int dockPosition(int) {return 0;}
static int dockParent(HWND,bool*) {return -1;}
static void dockWindow(HWND) {}
static void dockAdd(HWND,const char*,const char*,bool) {}
static void toolbar(int,int id) {++toolbarUpdates[id];}
static void* getFunction(const char* key) {
    if(missingApi==key) return nullptr;
    const std::map<std::string,void*> api={
        {"AddRemoveReaScript",reinterpret_cast<void*>(addScript)},
        {"Main_OnCommand",reinterpret_cast<void*>(runCommand)},
        {"GetResourcePath",reinterpret_cast<void*>(getResource)},
        {"GetExtState",reinterpret_cast<void*>(getState)},
        {"SetExtState",reinterpret_cast<void*>(setState)},
        {"ShowMessageBox",reinterpret_cast<void*>(message)},
        {"GetThemeColor",reinterpret_cast<void*>(theme)},
        {"ColorFromNative",reinterpret_cast<void*>(colour)},
        {"Dock_UpdateDockID",reinterpret_cast<void*>(dockId)},
        {"DockGetPosition",reinterpret_cast<void*>(dockPosition)},
        {"DockIsChildOfDock",reinterpret_cast<void*>(dockParent)},
        {"DockWindowActivate",reinterpret_cast<void*>(dockWindow)},
        {"DockWindowRemove",reinterpret_cast<void*>(dockWindow)},
        {"DockWindowAddEx",reinterpret_cast<void*>(dockAdd)},
        {"RefreshToolbar2",reinterpret_cast<void*>(toolbar)}};
    const auto it=api.find(key);return it==api.end()?nullptr:it->second;
}
int main(int argc,char** argv) {
    HMODULE module=nullptr;
    try {
        check(argc==3,"Expected extension path and staged resource folder");resourcePath=argv[2];
        module=LoadLibraryA(argv[1]);check(module!=nullptr,"Windows could not load the compiled DLL");
        using Entry=int(*)(REAPER_PLUGIN_HINSTANCE,reaper_plugin_info_t*);
        const auto entry=reinterpret_cast<Entry>(GetProcAddress(module,"ReaperPluginEntry"));
        check(entry!=nullptr,"Extension entrypoint exported");
        reaper_plugin_info_t info{};info.caller_version=REAPER_PLUGIN_VERSION;info.Register=registerItem;info.GetFunc=getFunction;
        missingApi="DockWindowAddEx";
        check(entry(module,&info)==0&&registrations.empty(),"Missing host API rejects load cleanly");
        missingApi.clear();failedCommand="EA_NATIVE_AUTOMATION_WRITE_ALL";
        check(entry(module,&info)==0&&accelerators.empty()&&registrations.empty(),"Partial action-registration failure must unregister every action and API");
        failedCommand.clear();check(entry(module,&info)==1,"Extension loads with host APIs");
        check(registrations.size()==16,"Four script APIs plus action, hooks and timer registered");
        check(accelerators.size()==ea::actionCatalog().size()+1,"Every action and the original panel toggle appear in the Main Actions list");
        for(const auto& definition:ea::actionCatalog()) {
            const auto id=commandIds.at(definition.id);
            check(accelerators.count(id)!=0&&std::string(accelerators.at(id)->desc)==definition.title,"Stable named action registers the correct description");
        }
        const auto hook=reinterpret_cast<bool(*)(int,int)>(registrations.at("hookcommand"));
        const auto toggle=reinterpret_cast<int(*)(int)>(registrations.at("toggleaction"));
        check(!hook(1234,0)&&toggle(1234)==-1,"Unrelated REAPER actions are not consumed");
        const int startupId=commandIds.at("EA_NATIVE_AUTOMATION_STARTUP");
        check(toggle(startupId)==0&&hook(startupId,0)&&toggle(startupId)==1,"Startup action and toolbar state work with the panel closed");
        check(hook(startupId,0)&&toggle(startupId)==0,"Startup action toggles off");
        const int scaleId=commandIds.at("EA_NATIVE_AUTOMATION_SIZE_75");
        check(hook(scaleId,0)&&toggle(scaleId)==1,"Size preset action updates its radio state without opening the engine");
        const int themeId=commandIds.at("EA_NATIVE_AUTOMATION_THEME_1");
        check(hook(themeId,0)&&toggle(themeId)==1,"Theme action persists without opening the engine");
        check(registrations.count("API_EA_Native_Open")&&registrations.count("APIvararg_EA_Native_NextCommand"),"Native and Lua APIs registered");
        reinterpret_cast<void(*)()>(registrations.at("API_EA_Native_Open"))();
        check(invoked==60000&&lastScript.find("engine.lua")!=std::string::npos&&lastError.empty(),"Native action starts installed engine");
        invoked=0;reinterpret_cast<void(*)()>(registrations.at("API_EA_Native_Open"))();
        check(invoked==0,"Repeated open does not start a duplicate engine");
        const auto next=reinterpret_cast<const char*(*)()>(registrations.at("API_EA_Native_NextCommand"));
        check(std::string(next()).empty(),"New bridge starts empty");
        reinterpret_cast<void(*)(const char*)>(registrations.at("API_EA_Native_Publish"))("preview=1\nscope=selected\n");
        reinterpret_cast<void(*)(bool)>(registrations.at("API_EA_Native_Connect"))(false);
        entry(module,nullptr);check(registrations.empty()&&accelerators.empty(),"All action and API registrations removed on unload");
        FreeLibrary(module);module=nullptr;
        std::cout<<"PASS: compiled DLL load, host API validation, Lua bridge/action registration, duplicate-open protection and unload\n";return 0;
    } catch(const std::exception& e) {if(module) FreeLibrary(module);std::cerr<<e.what()<<'\n';return 1;}
}
