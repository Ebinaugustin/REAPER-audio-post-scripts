#include "PanelModel.h"
#include <iostream>
#include <stdexcept>
#include <set>
static void check(bool ok,const std::string& why) {if(!ok) throw std::runtime_error(why);}
int main() {
    try {
        for(auto mode:{0,1,2}) {
            const auto layout=ea::makeLayout(mode>0,mode==2);
            check(layout.controls.size()==30,"Every control is present");
            std::set<std::string> ids;
            for(size_t i=0;i<layout.controls.size();++i) {
                const auto& c=layout.controls[i];const auto r=c.bounds;
                check(ids.insert(c.id).second,"No duplicate control IDs");
                check(r.x>=0&&r.y>=0&&r.w>0&&r.h>0&&r.x+r.w<=layout.width&&r.y+r.h<=layout.height,"Control lies within layout: "+c.id);
                for(size_t j=0;j<i;++j) {
                    const auto q=layout.controls[j].bounds;
                    check(r.x>=q.x+q.w||q.x>=r.x+r.w||r.y>=q.y+q.h||q.y>=r.y+r.h,"No overlap: "+c.id+" and "+layout.controls[j].id);
                }
            }
            for(auto suffix:{"start","all","end","punch","next"}) {
                check(ids.count(std::string("manual_")+suffix)==1,"Manual icon exists");
                check(ids.count(std::string("stop_")+suffix)==1,"Stop icon exists");
            }
        }
        check(ea::commandFor("manual_all")=="write:all","Manual mapping");
        check(ea::commandFor("stop_next")=="onstop:next","Stop mapping");
        check(ea::commandFor("pan")=="group:pan","PAN mapping");
        check(ea::commandFor("paste_fill")=="paste:fill","Fill mapping");
        const auto vertical=ea::makeLayout(false);
        check(vertical.width==220&&vertical.height==730,"Readable 100% floating dimensions");
        for(const auto& c:vertical.controls)
            if(c.id.rfind("manual_",0)==0||c.id.rfind("stop_",0)==0)
                check(c.bounds.w>=59&&c.bounds.h>=32,"Readable write icon targets");
        check(ea::displayUiScale(50,1080)==.5f&&ea::displayUiScale(75,1080)==.75f&&ea::displayUiScale(200,1080)==2,"Explicit size presets");
        check(ea::displayUiScale(0,480)==.85f&&ea::displayUiScale(0,2160)==1.75f,"Automatic scale limits preserve readability");
        std::cout<<"PASS: all 30 controls, three layouts, no overlap, exact action mapping\n";return 0;
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
