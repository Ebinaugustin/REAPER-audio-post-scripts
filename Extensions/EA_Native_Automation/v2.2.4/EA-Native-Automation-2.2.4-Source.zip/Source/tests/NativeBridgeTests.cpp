#include "NativeBridge.h"
#include <iostream>
#include <stdexcept>
static void check(bool ok,const char* why) {if(!ok) throw std::runtime_error(why);}
int main() {
    try {
        ea::NativeBridge b;
        b.push("write:all");b.push("paste:fill");
        check(std::string(b.next())=="write:all","FIFO write");check(std::string(b.next())=="paste:fill","FIFO paste");check(std::string(b.next()).empty(),"Empty queue");
        b.publish("preview=1\nenabled_pan=1\nscope=selected\nmessage=Pasted 2 / skipped 0\n");
        check(b.flag("preview"),"Preview status");check(b.text("scope")=="selected","Scope status");check(!b.flag("missing"),"Missing status is false");
        b.push("write:all");b.requestClose();b.push("paste:fill");
        check(std::string(b.next())=="close","Close supersedes queued project edits");check(std::string(b.next()).empty(),"No commands accepted during closing");
        b.reset();for(int i=0;i<1000;++i) b.push("capture");int count=0;while(*b.next()) ++count;
        check(count==256,"Queue is bounded");
        std::cout<<"PASS: native command FIFO, state updates, close safety and bounded queue\n";return 0;
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
