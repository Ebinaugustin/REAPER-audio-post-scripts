// Optional Windows offscreen test; uses the production JUCE panel and host layer.
// Reuse the API-table fixture, without its extension-loading entrypoint.
#include "ReaperHost.h"
#include "AutomationPanel.h"
#define main unusedExtensionTestMain
#include "ExtensionLoadTests.cpp"
#undef main
static juce::MouseEvent mouse(ea::AutomationPanel& panel,float x,float y,int extraModifiers=0) {
    const juce::Point<float> pos{x,y};const auto now=juce::Time::getCurrentTime();
    return {juce::Desktop::getInstance().getMainMouseSource(),pos,juce::ModifierKeys::leftButtonModifier|extraModifiers,
            1,0,0,0,0,&panel,&panel,now,pos,now,1,false};
}
static ea::Rect control(const ea::Layout& layout,const std::string& id) {
    for(const auto& c:layout.controls) if(c.id==id) return c.bounds;
    throw std::runtime_error("Missing control: "+id);
}
static void click(ea::AutomationPanel& panel,const ea::Layout& layout,const char* id,float scale=1,int modifiers=0) {
    const auto r=control(layout,id);const auto event=mouse(panel,(r.x+r.w/2)*scale,(r.y+r.h/2)*scale,modifiers);
    panel.mouseDown(event);panel.mouseUp(event);
}
static void saveImage(ea::AutomationPanel& panel,const juce::File& folder,const char* name) {
    juce::PNGImageFormat png;juce::FileOutputStream stream(folder.getChildFile(name));
    check(stream.openedOk(),"Cannot open preview output");
    check(stream.setPosition(0)&&stream.truncate().wasOk(),"Cannot replace preview output");
    check(png.writeImageToStream(panel.createComponentSnapshot(panel.getLocalBounds(),true,2),stream),"Cannot encode native panel PNG");
}
int main(int argc,char** argv) {
    try {
        check(argc==2,"Expected offscreen preview folder");
        juce::ScopedJuceInitialiser_GUI gui;
        juce::MessageManager::getInstance()->setCurrentThreadAsMessageThread();
        reaper_plugin_info_t info{};info.caller_version=REAPER_PLUGIN_VERSION;info.Register=registerItem;info.GetFunc=getFunction;
        ea::ReaperHost host(GetModuleHandle(nullptr),info);check(host.initialise(),"Mock host must initialise");
        themeColours["col_main_bg"]=RGB(40,40,40);
        themeColours["col_toolbar_text_on"]=RGB(61,212,160);
        check(host.themeAccent()==juce::Colour(61,212,160),"Enabled-toolbar colour supplies the live REAPER accent");
        host.bridge.connected=true;
        host.save("theme","graphite");
        ea::AutomationPanel panel(host);panel.setVisible(true);
        const auto vertical=ea::makeLayout(false);const auto pv=control(vertical,"preview");
        const float px=pv.x+8,py=pv.y+pv.h*.72f;
        const juce::File folder=juce::File::getCurrentWorkingDirectory().getChildFile(juce::String::fromUTF8(argv[1]));
        check(folder.createDirectory().wasOk(),"Cannot create preview folder");
        panel.mouseDown(mouse(panel,px,py));check(std::string(host.bridge.next()).empty(),"Click acts on release, not press");
        const auto pressed=panel.createComponentSnapshot(panel.getLocalBounds());
        panel.mouseUp(mouse(panel,px,py));check(std::string(host.bridge.next())=="preview","Preview click queues real engine command");
        // Clear the short release flash before checking the normal face.
        juce::MessageManager::getInstance()->runDispatchLoopUntil(110);
        const auto normal=panel.createComponentSnapshot(panel.getLocalBounds());
        check(pressed.getPixelAt(static_cast<int>(px),static_cast<int>(py))!=normal.getPixelAt(static_cast<int>(px),static_cast<int>(py)),"Pressed face changes visibly");
        panel.mouseDown(mouse(panel,px,py));panel.mouseDrag(mouse(panel,0,0));panel.mouseUp(mouse(panel,0,0));
        check(std::string(host.bridge.next()).empty(),"Dragging out cancels the action");
        host.publish("preview=1\nenabled_plugin=1\nenabled_vol=1\nenabled_svol=1\nenabled_pan=1\nenabled_span=1\nenabled_mute=1\nenabled_smute=1\nscope=all\n");
        const auto preview=panel.createComponentSnapshot(panel.getLocalBounds());const auto green=preview.getPixelAt(static_cast<int>(px),static_cast<int>(py));
        check(green.getGreen()>green.getRed()*1.5,"Preview active face is green");
        click(panel,vertical,"preview",1,juce::ModifierKeys::ctrlModifier);
        check(std::string(host.bridge.next())=="preview_suspend","Ctrl-click Preview queues A/B suspension instead of exiting Preview");
        juce::MessageManager::getInstance()->runDispatchLoopUntil(110);
        host.publish("preview=1\npreview_suspended=1\nscope=all\n");
        const auto paused=panel.createComponentSnapshot(panel.getLocalBounds()).getPixelAt(static_cast<int>(px),static_cast<int>(py));
        check(paused!=green,"Suspended Preview has a distinct visual indication");
        saveImage(panel,folder,"preview-paused.png");
        host.publish("preview=1\nenabled_plugin=1\nenabled_vol=1\nenabled_svol=1\nenabled_pan=1\nenabled_span=1\nenabled_mute=1\nenabled_smute=1\nscope=all\n");
        const auto plugin=control(vertical,"plugin");const int ax=static_cast<int>(plugin.x+8),ay=static_cast<int>(plugin.y+plugin.h*.72f);
        for(const auto* name:{"reaper","graphite","silver","midnight","warm","classic"}) {
            host.save("theme",name);ea::AutomationPanel adaptive(host);adaptive.setVisible(true);
            const auto before=adaptive.createComponentSnapshot(adaptive.getLocalBounds()).getPixelAt(ax,ay);
            themeColours["col_toolbar_text_on"]=RGB(175,146,255);
            juce::MessageManager::getInstance()->runDispatchLoopUntil(120);
            const auto changed=adaptive.createComponentSnapshot(adaptive.getLocalBounds());
            const auto purple=changed.getPixelAt(ax,ay);
            check(purple!=before&&purple.getBlue()>purple.getGreen(),"Every panel style follows a changed REAPER accent");
            check(host.themeAccent()==juce::Colour(175,146,255),"Theme change is read without reopening the panel");
            if(std::string(name)=="reaper") saveImage(adaptive,folder,"reaper-purple.png");
            themeColours["col_toolbar_text_on"]=RGB(61,212,160);
        }
        themeColours["col_toolbar_text_on"]=RGB(230,230,230);themeColours["col_main_resize2"]=RGB(200,85,40);
        check(host.themeAccent()==juce::Colour(200,85,40),"Monochrome toolbar falls back to the theme highlight");
        themeColours.erase("col_toolbar_text_on");themeColours.erase("col_main_resize2");themeColours["genlist_selbg"]=RGB(130,55,170);
        check(host.themeAccent()==juce::Colour(130,55,170),"Missing theme tokens use an existing selection accent");
        themeColours.clear();themeColours["col_toolbar_text_on"]=RGB(150,150,150);
        check(host.themeAccent()==juce::Colour(150,150,150),"Entirely monochrome themes retain a neutral accent");
        themeColours.clear();check(host.themeAccent().getSaturation()==0,"No theme colour falls back to neutral, never a universal blue");
        themeColours["col_main_bg"]=RGB(40,40,40);themeColours["col_toolbar_text_on"]=RGB(61,212,160);
        for(const auto* name:{"graphite","silver","midnight","warm","classic","reaper"}) {
            host.save("theme",name);ea::AutomationPanel themed(host);themed.setVisible(true);
            saveImage(themed,folder,(std::string(name)+".png").c_str());
        }
        click(panel,vertical,"capture",1,juce::ModifierKeys::ctrlModifier);
        check(std::string(host.bridge.next())=="capture_selected","Ctrl-click selects Capture source without changing scope");
        click(panel,vertical,"capture",1,juce::ModifierKeys::altModifier|juce::ModifierKeys::shiftModifier);
        check(std::string(host.bridge.next())=="capture_selected","Pro Tools Alt+Shift shortcut supported");
        click(panel,vertical,"capture",1,juce::ModifierKeys::altModifier);
        check(std::string(host.bridge.next())=="capture_all","Alt captures all controls");
        click(panel,vertical,"capture");check(std::string(host.bridge.next())=="capture","Normal Capture is preserved");
        host.publish("capture=1\ncapture_selected=1\nscope=all\n");
        const auto cr=control(vertical,"capture");const int cx=static_cast<int>(cr.x+8),cy=static_cast<int>(cr.y+cr.h*.72f);
        const auto first=panel.createComponentSnapshot(panel.getLocalBounds()).getPixelAt(cx,cy);
        bool blink=false;
        for(int i=0;i<12&&!blink;++i) {
            juce::MessageManager::getInstance()->runDispatchLoopUntil(60);
            blink=panel.createComponentSnapshot(panel.getLocalBounds()).getPixelAt(cx,cy)!=first;
        }
        check(blink,"Selected-only Capture blinks");saveImage(panel,folder,"selected-capture.png");
        check(ea::AutomationPanel::menuOptionsAt(&panel,{-1250,65}).getTargetScreenArea()==juce::Rectangle<int>(-1250,65,1,1),"Menu anchor follows cursor even on a monitor with negative coordinates");
        host.publish("version=2.2.3\n");
        for(const auto& kind:{"", "settings", "preview_menu", "paste_menu"}) {
            auto menu=panel.makePopupMenu(kind);
            juce::PopupMenu::MenuItemIterator item(menu,false);
            check(item.next()&&item.getItem().isSectionHeader&&item.getItem().itemID==0
                &&item.getItem().text=="EA Native Automation v2.2.3","All context menus display the running engine version without an actionable header");
        }
        host.publish("version=2.2.4\n");
        auto changedMenu=panel.makePopupMenu("");
        juce::PopupMenu::MenuItemIterator changedItem(changedMenu,false);
        check(changedItem.next()&&changedItem.getItem().text=="EA Native Automation v2.2.4","Menu version follows the connected script rather than a hard-coded UI version");
        host.publish("version=2.2.3\n");
        host.publish("preview=1\nscope=all\n");
        const auto horizontal=ea::makeLayout(true);
        panel.setDockSide(0);panel.setSize(static_cast<int>(horizontal.width),static_cast<int>(std::round(horizontal.height)));saveImage(panel,folder,"horizontal.png");
        click(panel,horizontal,"copy_all");
        check(std::string(host.bridge.next())=="copy:all","Horizontal layout hit testing");
        const auto shallow=ea::makeLayout(true,true);
        panel.setSize(static_cast<int>(shallow.width),static_cast<int>(std::round(shallow.height)));saveImage(panel,folder,"shallow.png");
        click(panel,shallow,"paste_fill");
        check(std::string(host.bridge.next())=="paste:fill","Shallow layout hit testing");
        panel.setUiScale(2);panel.setSize(static_cast<int>(horizontal.width*2),static_cast<int>(std::round(horizontal.height*2)));click(panel,horizontal,"paste_fill",2);
        check(std::string(host.bridge.next())=="paste:fill","Scaled layout hit testing");
        panel.setDockSide(-1);
        for(int percent:{50,75,100,125,150,175,200}) {
            const float scale=percent/100.f;panel.setUiScale(scale);panel.setSize(static_cast<int>(vertical.width*scale),static_cast<int>(std::round(vertical.height*scale)));
            click(panel,vertical,"manual_all",scale);check(std::string(host.bridge.next())=="write:all","Manual hit target follows size preset");
        }
        panel.setUiScale(1);panel.setDockSide(1);panel.setSize(220,200);
        juce::MouseWheelDetails wheel{};wheel.deltaY=-10;
        panel.mouseWheelMove(mouse(panel,100,100),wheel);
        const auto fill=control(vertical,"paste_fill");const auto event=mouse(panel,fill.x+fill.w/2,fill.y+fill.h/2-(vertical.height-200));
        panel.mouseDown(event);panel.mouseUp(event);check(std::string(host.bridge.next())=="paste:fill","Short screens/dockers scroll overflow without shrinking labels");
        host.setUiPercent(75);check(host.uiPercent()==75,"Size preference persists through the host layer");
        for(const auto& definition:ea::actionCatalog()) if(definition.kind==ea::ActionKind::Engine) {
            check(host.handleAction(commandIds.at(definition.id)),"Native shortcut must be handled");
            check(std::string(host.bridge.next())==definition.command,"Every engine shortcut must queue the same command as its panel control");
        }
        host.publish("preview=1\npreview_suspended=1\nenabled_vol=1\nonstop_all=1\nscope=selected\nmode=3\nitems=1\n");
        for(const auto* id:{"PREVIEW","PREVIEW_SUSPEND","WRITE_ENABLE_VOLUME","WRITE_ON_STOP_ALL","SCOPE_SELECTED","MODE_3","ITEMS"})
            check(host.actionState(commandIds.at(std::string("EA_NATIVE_AUTOMATION_")+id))==1,"Action/toolbar toggles mirror published engine state");
        check(host.actionState(commandIds.at("EA_NATIVE_AUTOMATION_SCOPE_ALL"))==0,"Unselected track scope is not checked");
        const int previewAction=commandIds.at("EA_NATIVE_AUTOMATION_PREVIEW"),redraws=toolbarUpdates[previewAction];
        host.publish("preview=1\n");check(toolbarUpdates[previewAction]==redraws,"Unchanged engine state does not repeatedly refresh toolbars");
        host.publish("preview=0\nmode=\n");
        check(toolbarUpdates[previewAction]==redraws+1&&host.actionState(previewAction)==0,"Changed engine state refreshes its toolbar once");
        check(host.actionState(commandIds.at("EA_NATIVE_AUTOMATION_MODE_3"))==0,"Mixed track modes clear the mode radio state");

        // Exercise closed-panel shortcuts without creating a native window.
        // The fake Main_OnCommand records startup; connect is modelled on the next host tick.
        host.connect(false);
        const auto resource=folder.getChildFile("test-resource");
        check(resource.getChildFile("UserPlugins/EA_Native_Automation").createDirectory().wasOk(),"Create mock installed resource");
        check(resource.getChildFile("UserPlugins/EA_Native_Automation/engine.lua").replaceWithText("-- Mock installed engine\n"),"Write mock installed engine");
        resourcePath=resource.getFullPathName().toStdString();
        const int beforeStarts=engineStarts;
        host.handleAction(commandIds.at("EA_NATIVE_AUTOMATION_WRITE_ALL"));
        host.handleAction(commandIds.at("EA_NATIVE_AUTOMATION_CAPTURE_SELECTED"));
        check(engineStarts==beforeStarts+1&&std::string(host.bridge.next()).empty(),"Closed-panel shortcuts start one engine and wait for connection");
        host.bridge.connected=true;host.tick();
        check(std::string(host.bridge.next())=="write:all"&&std::string(host.bridge.next())=="capture_selected","Waiting shortcuts dispatch in order after engine connection");
        host.tick();check(std::string(host.bridge.next()).empty(),"Waiting actions are not replayed on later host ticks");
        host.close();check(std::string(host.bridge.next())=="close","Closing clears queued actions and requests engine cleanup");host.connect(false);
        host.handleAction(commandIds.at("EA_NATIVE_AUTOMATION_COPY_ALL"));host.close();
        host.bridge.connected=true;host.tick();check(std::string(host.bridge.next()).empty(),"Closing during startup discards pending automation edits");host.connect(false);
        const auto installedResource=resourcePath;resourcePath=resource.getChildFile("missing").getFullPathName().toStdString();
        host.handleAction(commandIds.at("EA_NATIVE_AUTOMATION_PASTE_FILL"));
        host.bridge.connected=true;host.tick();check(std::string(host.bridge.next()).empty(),"Failed engine startup cannot replay stale edits later");host.connect(false);resourcePath=installedResource;
        std::cout<<"PASS: shortcut dispatch for every engine action, startup/close queue safety, toolbar state/change notifications, live theme accent, panel feedback, modifiers/blink, menus and dock hit testing\n";
        return 0;
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
