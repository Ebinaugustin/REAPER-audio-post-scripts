# EA Native Automation 2.2.4

A compact JUCE/C++ automation panel for REAPER, with a dedicated native host integration layer. The automation engine remains a headless Lua script so the envelope, send matching and Manual Write fixes are retained. This is a native extension with a Lua backend.

## Install the Windows x64 package

1. Disable **Run at startup** in the older standalone panel if it was enabled, then close that panel. In REAPER choose **Options → Show REAPER resource path in explorer/finder**.
2. Exit REAPER. Copy the package's `UserPlugins` contents into that resource folder's `UserPlugins` folder. When upgrading, replace **both** the DLL and `EA_Native_Automation/engine.lua`. Keep the engine in its subfolder next to the DLL. Do not create a second nested `UserPlugins` folder.
3. Restart REAPER. Run **EA: Native Automation (JUCE) - toggle panel** from the Actions list.
4. Optional: load `Scripts/EA_Compact_Automation.lua` through **Actions → New action → Load ReaScript** as a launcher. It requires the extension; it is not the previous standalone script.

Use the gear menu to enable **Run at startup**. The extension opens the panel on subsequent REAPER starts without editing a startup script. The gear also switches automation items on/off. The default is ordinary envelope points; an existing saved preference from the older engine is retained.

The installed paths must look like this:

```text
REAPER resource folder/
  UserPlugins/
    reaper_ea_automation.dll
    EA_Native_Automation/
      engine.lua
```

The original standalone Lua deliverable is a separate fallback. Close one panel before opening the other. Copy buffers and capture snapshots are session data and are cleared when the panel closes.

## Keyboard shortcuts and toolbar actions

Version 2.2 registers **88 individual actions** alongside the existing panel toggle. They appear automatically when REAPER loads the extension; no separate action scripts need importing.

In **Actions → Show action list**, choose the **Main** section and search **EA: Automation**. Select an action, then use **Add** in the shortcut area to assign a key. The entries also work in REAPER custom actions and toolbars. Existing shortcuts for **EA: Native Automation (JUCE) - toggle panel** are preserved.

Actions include every Write Enable category, five Manual Write ranges, five Write on Stop modes, Suspend, Preview, Preview A/B suspension, all Capture variants, punch, Auto Match/Join, copy/paste/fill/stretch, track scope and automation modes. Panel menus, Docker placement, undocking, style, size and Run at startup are available too. Modifier-click commands have separate actions, so their shortcuts can be assigned directly. Full names and stable command IDs are listed in `ACTIONS.md`.

Automation actions open the panel automatically if it is closed, wait for its engine to connect, then run in order. Settings actions can save size, style or startup preferences without opening it. Closing the panel or failing to start the engine discards pending edits. An action triggered while the engine is closing is ignored; invoke it again after cleanup finishes.

Toggle actions reflect engine state in the Actions list and toolbars while the panel is running. Size/style/startup preferences also report their saved state while closed. The automation-mode radio state is clear for mixed modes or an active global override. Shared clipboards and Capture values last only while the panel remains open.

## Window and themes

The 100% floating content is 220 × 730 logical pixels, with larger labels, section headings and write buttons. **Size → Auto** is the default: it adapts to the current monitor's work area and OS display scaling, including when the floating window moves between monitors. Right-click offers 50%, 75%, 100%, 125%, 150%, 175% and 200%; this preference is saved. Floating windows retain a fixed size and fit inside the monitor's work area. On very small displays, use the mouse wheel to reach overflowing controls.

Left/right docks use a vertical layout; top/bottom docks use horizontal layouts, including a shallow layout. Docked content adapts to the available space and chosen size. When a Docker is too small to display every control legibly, the mouse wheel scrolls the overflow. Undocking rebuilds the native floating wrapper and restores a visible position within the monitor. On Windows, monitor fitting/scaling waits until a titlebar drag finishes, so it does not snap the panel back to the previous monitor. The destination monitor is chosen from the largest window overlap. OS titlebars vary by platform.

Right-click for docking, Docker 1–16, size, themes, automation mode, track scope and settings. Menus open at the mouse cursor. A side command selects an existing Docker assigned to that side. If no Docker occupies that side, assign one using REAPER's native Docker tab menu first. The host API does not expose a supported command to relocate an arbitrary Docker.

Panel styles: Follow REAPER, Graphite, Silver, Midnight, Warm graphite and Classic charcoal. **Active buttons follow the current REAPER accent in every style.** The panel first uses the theme's enabled-toolbar colour, then a coloured resize/selection highlight when toolbar colours are neutral. Entirely monochrome themes retain neutral buttons; there is no fixed blue fallback. Colour changes are detected while the panel is open. The enabled-toolbar and highlight tokens come from [REAPER's theme-colour API](https://www.reaper.fm/sdk/reascript/reascripthelp.html#GetThemeColor); a theme's image-only colours are not exposed through this API.

Follow REAPER also reads REAPER's background colour and derives a contrasting panel palette; it does not copy every image asset from a REAPER theme. Icons are vector-drawn and scale with labels. Rounded buttons have a glass-style sheen, highlighted edges, pressed displacement and a brief release flash. This is drawn styling, without OS background blur. Active labels contrast with the button colour. Preview lights green and selected-track Capture blinks amber as status indicators.

## Automation controls

- Write Enable gates plug-in, track volume/pan/mute and send volume/pan/mute. PAN includes all ReaSurround/ReaSurroundPan automation; there is no OBJ/BUS gate.
- Suspend bypasses all existing track, master and take envelopes, independently of track scope and Write Enable. It also prevents automation writing. Newly created envelopes are bypassed while Suspend remains on. Releasing Suspend or closing the panel restores each envelope's previous activation and the previous global override; points are preserved.
- Manual Write and Write on Stop provide start, whole range, end, punch and next ranges. Start/all/end use the time selection when present, otherwise the project range. Punch uses the first-touch/punch position and next writes up to the next automation point; hover for details.
- A successful Manual Write switches Preview off and returns global automation to **No global override / per-track**. A write with no valid destination/range leaves Preview available so the values are not discarded. Write on Stop retains its separate behaviour.
- Preview, Capture, punch, Auto Match and Auto Join use the existing engine. Turning Preview off sets global automation to **No global override / per-track**.
- **Ctrl-click Preview on Windows/Linux, or Cmd-click on macOS**, suspends/resumes Preview for A/B comparison. This follows the [Pro Tools Preview-suspension shortcut](https://resources.avid.com/SupportFiles/PT/Pro_Tools_Reference_Guide_12.8.2.pdf). The panel keeps held preview values, sets previewed tracks to Read while auditioning existing envelopes and restores the held values on resume. The button displays **PREVIEW PAUSED** in muted amber. The Preview dropdown also offers Suspend/Resume. Ordinary clicking still turns Preview off. Manual Write from paused Preview commits the held values and exits Preview after a successful write; punching is blocked until Preview resumes. Clearing latches discards the held values.
- **Ctrl-click Capture on Windows/Linux, or Cmd-click on macOS**, captures values from selected tracks and makes Capture blink. This is the requested custom shortcut. **Alt/Option-click** captures all tracks; **Alt/Option + Shift-click** also captures selected tracks, matching the modifier pattern in the [Avid Pro Tools reference guide](https://resources.avid.com/SupportFiles/attach/Pro_Tools/10.0/ENGLISH/Pro_Tools_Reference_Guide.pdf). These shortcuts capture existing envelopes in enabled parameter categories, including unarmed envelopes; they do not expose every possible plug-in parameter. The selected-track shortcut leaves the panel's normal track scope unchanged. Ordinary Capture uses the current scope and armed controls, and its indicator is steady.
- Copy All and Copy Pan work across tracks. The paste menu offers cursor paste, stretch to selection and repeat/fill to selection. Ordinary points are the default. Flat values are reduced and repeat boundaries are held without a connecting ramp.
- Native envelopes are matched by parameter, and matching envelopes can be exposed on the destination. Send automation uses existing sends only: bus/channel first, then an unused matching send slot. No sends or routing are created. Missing destinations are reported only when parameters cannot be matched.

This panel recreates the reference control arrangement with added copy/paste/settings controls. Pro Tools-specific automation behaviours are implemented through the capabilities of REAPER and the existing engine; the integration does not add an Atmos workflow.

## Cross-platform source builds

Required: CMake 3.24+, a supported C++17 compiler, network access for the pinned dependencies (or the supplied offline source bundles), and 64-bit REAPER. The Windows binary targets Windows 10/11 x64. JUCE 8.0.12, REAPER SDK and Cockos WDL revisions are pinned in `CMakeLists.txt`. A REAPER installation is not required to compile.

**Windows:** Visual Studio 2022 Build Tools with Desktop development with C++ and a Windows SDK. In a developer terminal:

```powershell
cmake -S . -B build -A x64 -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded
cmake --build build --config Release --parallel 2
ctest --test-dir build -C Release --output-on-failure
cmake --install build --config Release --prefix stage --component EA
```

**macOS:** Xcode command-line tools. Build a universal Intel/Apple Silicon extension:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release '-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64' -DCMAKE_OSX_DEPLOYMENT_TARGET=10.15
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
cmake --install build --prefix stage --component EA
```

**Linux:** GCC or Clang; development packages for GTK 3, X11, Xext, Xinerama, Xrandr, Xcursor, FreeType and Fontconfig. The window adapter requires REAPER's GTK/X11 or XWayland backend; pure Wayland is not supported. Install Lua 5.3/5.4 to run the engine model tests.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
cmake --install build --prefix stage --component EA
```

Copy the resulting `stage/UserPlugins` contents to the REAPER resource folder. Matching architecture is required. No installer modifies REAPER automatically. Windows uses `.dll`, macOS `.dylib`, Linux `.so`.

For an offline build, extract the three archives in `vendor` into separate folders and set `FETCHCONTENT_SOURCE_DIR_JUCE`, `FETCHCONTENT_SOURCE_DIR_REAPER_SDK` and `FETCHCONTENT_SOURCE_DIR_WDL` to their absolute paths when configuring. These archives contain the exact upstream source revisions used by this package.

The included GitHub workflow describes Windows x64, macOS universal and Linux x64 builds. It has not been run remotely. Check `VALIDATION.md` for what was actually compiled and tested. You will perform the live REAPER automation/docking tests.

For the optional Windows offscreen panel test and rendered theme previews, configure with `-DEA_BUILD_UI_TESTS=ON`. This test paints the production JUCE component without opening a window or REAPER, and checks button feedback, green Preview, Capture modifiers/blinking, cursor menu anchoring, size presets, mouse release/cancel behaviour and dock layout hit testing.

## Source and licence

The new native package is supplied with corresponding source under AGPL-3.0-or-later, using JUCE's open-source licensing option. JUCE also offers a commercial licence. Upstream source notices and licences are retained; see `THIRD-PARTY-NOTICES.md` and `LICENSE.txt`.

## Manual Write update in 2.2.1

Live Manual Write commits REAPER’s internal latched values with native action 42013 over the range chosen by the button. This avoids deriving native track/send envelope values from combined UI/trim reads. Only enabled, armed, actively writing envelopes in the panel scope participate. Automation items remain optional; captured, paused Preview and write-on-stop snapshots keep their explicit point path. A flat hold normally needs only its boundary points.

## Manual Write engine hotfix in 2.2.2

Manual Write finishes Preview before installing its final curve, then checks the complete hold after a host update. A successful status says **Verified … envelopes; Preview off**. If the curve changes afterwards, the status reports a verification failure and the latest operation is saved to `UserPlugins/EA_Native_Automation/ManualWrite-diagnostics.txt` for diagnosis. No additional import or setup is needed. The 2.2.2 engine-only hotfix reused the 2.2.1 native DLL; 2.2.3 rebuilds the DLL for the menu update.

## Lane visibility and version in 2.2.3

Writes preserve existing envelope visibility and inline/separate-lane placement. Manual writes require latched/touched controls or an explicit Capture; an empty Preview or repeated click after Preview ends does not target every armed envelope. Right-click the panel to see the running engine version in the menu header.

This update preserves your current layout. To close lanes already opened by an older version, select the affected tracks and run REAPER’s **Envelope: Hide all envelopes for tracks** action once. It hides lanes; your automation points remain.

## No time selection — version 2.2.4

The middle Manual Write button and **EA: Automation - Manual write: across selection / project range** now warn when there is no time selection. **OK** proceeds across the entire session; **Cancel** retains the current automation, Preview and Capture values. A valid time selection writes directly. Existing shortcut assignments still work. This engine update reuses the 2.2.3 native DLL.
