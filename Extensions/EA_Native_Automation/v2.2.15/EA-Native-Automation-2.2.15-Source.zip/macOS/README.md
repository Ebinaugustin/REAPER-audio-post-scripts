# macOS — universal source build kit

**A compiled macOS extension is not included.** This folder prepares an Intel + Apple Silicon universal build from the shared `../Source` folder. macOS has not been compiled or tested in this session.

Requirements: macOS, Xcode command-line tools and CMake 3.24+. The target's deployment minimum is macOS 10.15. Install Lua 5.3/5.4 if you also want the automation-engine model tests.

In Terminal, from this folder:

```sh
sh build.command
```

Alternatively, double-click `build.command` when executable. If macOS prevents launching a downloaded script, use the Terminal command above after inspecting it.

The script extracts the bundled dependency sources, configures a universal build, compiles, runs available tests and stages the result in `Ready-to-install`. It does not download dependencies or modify REAPER. Build output is in `build`.

After success, close REAPER and copy the contents of `Ready-to-install/UserPlugins` into the REAPER resource `UserPlugins` folder, including both `reaper_ea_automation.dylib` and `EA_Native_Automation/engine.lua`. Restart and run **EA: Native Automation (JUCE) - toggle panel**. The optional launcher is in `Ready-to-install/Scripts`.

Live macOS docking, display scaling and automation need platform testing. See `../VALIDATION.md` and `../Source/README.md`.
