#!/bin/sh
# Build from the supplied offline sources; never write to REAPER.
set -eu
PLATFORM_DIR=$(CDPATH= cd -P "$(dirname "$0")" && pwd)
BUNDLE_ROOT=$(CDPATH= cd -P "$PLATFORM_DIR/.." && pwd)
BUILD_DIR="$PLATFORM_DIR/build"
SOURCE_DIR="$BUNDLE_ROOT/Source"
DEPENDENCY_DIR="$BUILD_DIR/dependencies"
command -v cmake >/dev/null 2>&1 || { echo 'Install CMake 3.24+ first.' >&2; exit 1; }
cmake "-DEA_SOURCE_ROOT=$SOURCE_DIR" "-DEA_DEPENDENCY_ROOT=$DEPENDENCY_DIR" -P "$BUNDLE_ROOT/BuildSupport/PrepareDependencies.cmake"
cmake -S "$SOURCE_DIR" -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release \
  "-DFETCHCONTENT_SOURCE_DIR_JUCE=$DEPENDENCY_DIR/JUCE" \
  "-DFETCHCONTENT_SOURCE_DIR_REAPER_SDK=$DEPENDENCY_DIR/reaper-sdk" \
  "-DFETCHCONTENT_SOURCE_DIR_WDL=$DEPENDENCY_DIR/WDL" "-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64" -DCMAKE_OSX_DEPLOYMENT_TARGET=10.15
cmake --build "$BUILD_DIR" --config Release --parallel 2
ctest --test-dir "$BUILD_DIR" -C Release --output-on-failure
cmake --install "$BUILD_DIR" --config Release --prefix "$PLATFORM_DIR/Ready-to-install" --component EA
printf '%s\n' "Build ready in $PLATFORM_DIR/Ready-to-install. REAPER was not modified."
