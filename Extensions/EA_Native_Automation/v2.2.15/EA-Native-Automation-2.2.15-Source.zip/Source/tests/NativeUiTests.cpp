#include <set>
// Optional Windows offscreen test; uses the production JUCE panel and host layer.
// Reuse the API-table fixture, without its extension-loading entrypoint.
#include "ReaperHost.h"
#include "AutomationPanel.h"
#define main unusedExtensionTestMain
#include "ExtensionLoadTests.cpp"
#undef main
static juce::MouseEvent mouse(ea::AutomationPanel& panel,float x,float y,int extraModifiers=0) {
    const juce::Point<float> pos{x,y};const auto now=juce::Time::getCurrentTime();
    return {juce::Desktop::getInstance().getMainMouseSource(),pos,juce::ModifierKeys::leftButtonModifier|extraModifiers,
            1,0,0,0,0,&panel,&panel,now,pos,now,1,false};
}
static ea::Rect control(const ea::Layout& layout,const std::string& id) {
    for(const auto& c:layout.controls) if(c.id==id) return c.bounds;
    throw std::runtime_error("Missing control: "+id);
}
static void click(ea::AutomationPanel& panel,const ea::Layout& layout,const char* id,float scale=1,int modifiers=0,float ox=0,float oy=0) {
    const auto r=control(layout,id);const auto event=mouse(panel,(r.x+r.w/2)*scale+ox,(r.y+r.h/2)*scale+oy,modifiers);
    panel.mouseDown(event);panel.mouseUp(event);
}
static juce::ScrollBar* stripBar(ea::AutomationPanel& panel) {
    for(auto* child:panel.getChildren()) if(auto* bar=dynamic_cast<juce::ScrollBar*>(child)) return bar;
    throw std::runtime_error("Missing strip scrollbar");
}
static void checkStrip(ea::AutomationPanel& panel,ea::ReaperHost& host,int side,int width,int height,float preferred) {
    panel.setUiScale(preferred);panel.setDockSide(side);panel.setSize(width,height);
    const auto view=ea::makePanelView(side,static_cast<float>(width),static_cast<float>(height),preferred,host.sectionMask());
    const auto& layout=view.layout;
    check(layout.dockFlow,"Expected fixed-size dock toolbar flow");
    auto* bar=stripBar(panel);const bool overflow=bar->isVisible();
    const float cw=static_cast<float>(width)-(overflow&&!layout.horizontal?bar->getWidth():0);
    const float ch=static_cast<float>(height)-(overflow&&layout.horizontal?bar->getHeight():0);
    const float scale=view.scale,ox=view.offsetX,oy=view.offsetY;
    check(scale==preferred,"Docked buttons honor the exact selected scale, including 50% and 75%");
    for(const auto& c:layout.controls) {
        if(overflow) {
            const float centre=layout.horizontal?c.bounds.x+c.bounds.w/2:c.bounds.y+c.bounds.h/2;
            bar->setCurrentRangeStart(centre-static_cast<float>(bar->getCurrentRangeSize())/2,juce::sendNotificationSync);
        }
        const float start=overflow?static_cast<float>(bar->getCurrentRangeStart()):0;
        const float x=std::min(cw-1,(c.bounds.x+c.bounds.w/2-(layout.horizontal?start:0))*scale+ox);
        const float y=std::min(ch-1,(c.bounds.y+c.bounds.h/2-(layout.horizontal?0:start))*scale+oy);
        check(x>=0&&x<cw&&y>=0&&y<ch,"Every reflowed control can be brought into view");
        panel.mouseMove(mouse(panel,x,y));
        check(panel.getTooltip().toStdString()==c.tooltip,"Every compact control retains its correct hit target and tooltip");
        if(c.id!="preview_menu"&&c.id!="paste_menu"&&c.id!="settings"&&c.id!="scope") {
            panel.mouseDown(mouse(panel,x,y));panel.mouseUp(mouse(panel,x,y));
            check(std::string(host.bridge.next())==ea::commandFor(c.id),"Every compact button dispatches its original action");
        }
    }
    // Scroll to the leading edge before the next resize so offsets cannot mask bad hit tests.
    if(overflow) bar->setCurrentRangeStart(0,juce::sendNotificationSync);
}
static void saveImage(ea::AutomationPanel& panel,const juce::File& folder,const char* name,float density=2) {
    juce::PNGImageFormat png;juce::FileOutputStream stream(folder.getChildFile(name));
    check(stream.openedOk(),"Cannot open preview output");
    check(stream.setPosition(0)&&stream.truncate().wasOk(),"Cannot replace preview output");
    check(png.writeImageToStream(panel.createComponentSnapshot(panel.getLocalBounds(),true,density),stream),"Cannot encode native panel PNG");
}
int main(int argc,char** argv) {
    try {
        check(argc==2||argc==3,"Expected offscreen preview folder and optional REAPER-font fixture");
        if(argc==3) fontHostPath=argv[2];
        juce::ScopedJuceInitialiser_GUI gui;
        juce::MessageManager::getInstance()->setCurrentThreadAsMessageThread();
        reaper_plugin_info_t info{};info.caller_version=REAPER_PLUGIN_VERSION;info.Register=registerItem;info.GetFunc=getFunction;
        ea::ReaperHost host(GetModuleHandle(nullptr),info);check(host.initialise(),"Mock host must initialise");
        if(argc==3) {
            check(host.reaperFont(11).getTypefaceName().containsIgnoreCase("Inter"),"Loads REAPER's actual Inter-Regular.ttf");
            const auto medium=host.reaperFont(11,true);
            check(medium.getTypefaceName().containsIgnoreCase("Inter"),"Loads REAPER's actual Inter-Medium.ttf");
            check(!medium.isBold(),"REAPER's medium weight is used without synthetic bold");
            const auto savedFontPath=fontHostPath;fontHostPath.clear();
            {ea::ReaperHost fallback(GetModuleHandle(nullptr),info);check(fallback.reaperFont(11).getHeight()==11,"Missing REAPER font files safely use a platform font");}
            missingApi="GetExePath";
            {ea::ReaperHost fallback(GetModuleHandle(nullptr),info);check(!fallback.reaperFont(11).getTypefaceName().isEmpty(),"The font path API remains optional");}
            missingApi.clear();fontHostPath=savedFontPath;
        }
        themeColours["col_main_bg"]=RGB(40,40,40);
        themeColours["col_toolbar_text_on"]=RGB(61,212,160);
        check(host.themeAccent()==juce::Colour(61,212,160),"Enabled-toolbar colour supplies the live REAPER accent");
        host.bridge.connected=true;
        host.save("theme","graphite");
        ea::AutomationPanel panel(host);panel.setVisible(true);
        const auto vertical=ea::makeLayout(false);const auto pv=control(vertical,"preview");
        const float px=pv.x+8,py=pv.y+pv.h*.72f;
        const juce::File folder=juce::File::getCurrentWorkingDirectory().getChildFile(juce::String::fromUTF8(argv[1]));
        check(folder.createDirectory().wasOk(),"Cannot create preview folder");
        panel.mouseDown(mouse(panel,px,py));check(std::string(host.bridge.next()).empty(),"Click acts on release, not press");
        const auto pressed=panel.createComponentSnapshot(panel.getLocalBounds());
        panel.mouseUp(mouse(panel,px,py));check(std::string(host.bridge.next())=="preview","Preview click queues real engine command");
        // Clear the short release flash before checking the normal face.
        juce::MessageManager::getInstance()->runDispatchLoopUntil(110);
        const auto normal=panel.createComponentSnapshot(panel.getLocalBounds());
        check(pressed.getPixelAt(static_cast<int>(px),static_cast<int>(py))!=normal.getPixelAt(static_cast<int>(px),static_cast<int>(py)),"Pressed face changes visibly");
        panel.mouseDown(mouse(panel,px,py));panel.mouseDrag(mouse(panel,0,0));panel.mouseUp(mouse(panel,0,0));
        check(std::string(host.bridge.next()).empty(),"Dragging out cancels the action");
        host.publish("preview=1\nenabled_plugin=1\nenabled_vol=1\nenabled_svol=1\nenabled_pan=1\nenabled_span=1\nenabled_mute=1\nenabled_smute=1\nscope=all\n");
        const auto preview=panel.createComponentSnapshot(panel.getLocalBounds());const auto green=preview.getPixelAt(static_cast<int>(px),static_cast<int>(py));
        check(green.getGreen()>green.getRed()*1.5,"Preview active face is green");
        const auto previewFace=ea::pixelAlignedRect(pv,1);
        const int leftX=static_cast<int>(previewFace.x+5),rightX=static_cast<int>(previewFace.x+previewFace.w-5);
        const int middleY=static_cast<int>(previewFace.y+previewFace.h*.5f);
        const auto firstFace=panel.createComponentSnapshot(panel.getLocalBounds()).getPixelAt(leftX,middleY);
        bool wholeFaceBlink=false;
        for(int i=0;i<12&&!wholeFaceBlink;++i) {
            const auto frame=panel.createComponentSnapshot(panel.getLocalBounds());
            const auto left=frame.getPixelAt(leftX,middleY),right=frame.getPixelAt(rightX,middleY);
            check(left==right,"Preview has no separate dot: matching sides share the same button face");
            check(left.getGreen()>left.getRed()&&left.getGreen()>left.getBlue(),"Both button blink phases remain green");
            wholeFaceBlink=std::abs(static_cast<int>(left.getGreen())-firstFace.getGreen())>25;
            juce::MessageManager::getInstance()->runDispatchLoopUntil(80);
        }
        check(wholeFaceBlink,"The entire Preview button visibly alternates bright and dim green");
        host.publish("preview=0\npreview_suspended=0\n");
        const auto offFace=panel.createComponentSnapshot(panel.getLocalBounds()).getPixelAt(leftX,middleY);
        juce::MessageManager::getInstance()->runDispatchLoopUntil(450);
        check(panel.createComponentSnapshot(panel.getLocalBounds()).getPixelAt(leftX,middleY)==offFace,"Preview off remains a steady normal button");
        host.publish("preview=1\npreview_suspended=1\n");
        const auto pausedFace=panel.createComponentSnapshot(panel.getLocalBounds()).getPixelAt(leftX,middleY);
        juce::MessageManager::getInstance()->runDispatchLoopUntil(450);
        check(panel.createComponentSnapshot(panel.getLocalBounds()).getPixelAt(leftX,middleY)==pausedFace&&pausedFace.getRed()>pausedFace.getBlue(),"Paused A/B Preview remains steady amber");
        host.publish("preview=1\npreview_suspended=0\n");
        check(std::string(host.bridge.next()).empty(),"Full-button blinking never sends automation commands");
        click(panel,vertical,"preview",1,juce::ModifierKeys::ctrlModifier);
        check(std::string(host.bridge.next())=="preview_suspend","Ctrl-click Preview queues A/B suspension instead of exiting Preview");
        juce::MessageManager::getInstance()->runDispatchLoopUntil(110);
        host.publish("preview=1\npreview_suspended=1\nscope=all\n");
        const auto paused=panel.createComponentSnapshot(panel.getLocalBounds()).getPixelAt(static_cast<int>(px),static_cast<int>(py));
        check(paused!=green,"Suspended Preview has a distinct visual indication");
        saveImage(panel,folder,"preview-paused.png");
        host.publish("preview=1\nenabled_plugin=1\nenabled_vol=1\nenabled_svol=1\nenabled_pan=1\nenabled_span=1\nenabled_mute=1\nenabled_smute=1\nscope=all\n");
        const auto plugin=control(vertical,"plugin");const int ax=static_cast<int>(plugin.x+8),ay=static_cast<int>(plugin.y+plugin.h*.72f);
        for(const auto* name:{"reaper","graphite","silver","midnight","warm","classic"}) {
            host.save("theme",name);ea::AutomationPanel adaptive(host);adaptive.setVisible(true);
            const auto before=adaptive.createComponentSnapshot(adaptive.getLocalBounds()).getPixelAt(ax,ay);
            themeColours["col_toolbar_text_on"]=RGB(175,146,255);
            juce::MessageManager::getInstance()->runDispatchLoopUntil(120);
            const auto changed=adaptive.createComponentSnapshot(adaptive.getLocalBounds());
            const auto purple=changed.getPixelAt(ax,ay);
            check(purple!=before&&purple.getBlue()>purple.getGreen(),"Every panel style follows a changed REAPER accent");
            check(host.themeAccent()==juce::Colour(175,146,255),"Theme change is read without reopening the panel");
            if(std::string(name)=="reaper") saveImage(adaptive,folder,"reaper-purple.png");
            themeColours["col_toolbar_text_on"]=RGB(61,212,160);
        }
        themeColours["col_toolbar_text_on"]=RGB(230,230,230);themeColours["col_main_resize2"]=RGB(200,85,40);
        check(host.themeAccent()==juce::Colour(200,85,40),"Monochrome toolbar falls back to the theme highlight");
        themeColours.erase("col_toolbar_text_on");themeColours.erase("col_main_resize2");themeColours["genlist_selbg"]=RGB(130,55,170);
        check(host.themeAccent()==juce::Colour(130,55,170),"Missing theme tokens use an existing selection accent");
        themeColours.clear();themeColours["col_toolbar_text_on"]=RGB(150,150,150);
        check(host.themeAccent()==juce::Colour(150,150,150),"Entirely monochrome themes retain a neutral accent");
        themeColours.clear();check(host.themeAccent().getSaturation()==0,"No theme colour falls back to neutral, never a universal blue");
        themeColours["col_main_bg"]=RGB(40,40,40);themeColours["col_toolbar_text_on"]=RGB(61,212,160);
        for(const auto* name:{"graphite","silver","midnight","warm","classic","reaper"}) {
            host.save("theme",name);ea::AutomationPanel themed(host);themed.setVisible(true);
            saveImage(themed,folder,(std::string(name)+".png").c_str());
        }
        click(panel,vertical,"capture",1,juce::ModifierKeys::ctrlModifier);
        check(std::string(host.bridge.next())=="capture_selected","Ctrl-click selects Capture source without changing scope");
        click(panel,vertical,"capture",1,juce::ModifierKeys::altModifier|juce::ModifierKeys::shiftModifier);
        check(std::string(host.bridge.next())=="capture_selected","Pro Tools Alt+Shift shortcut supported");
        click(panel,vertical,"capture",1,juce::ModifierKeys::altModifier);
        check(std::string(host.bridge.next())=="capture_all","Alt captures all controls");
        click(panel,vertical,"capture");check(std::string(host.bridge.next())=="capture","Normal Capture is preserved");
        host.publish("capture=1\ncapture_selected=1\nscope=all\n");
        const auto cr=control(vertical,"capture");const int cx=static_cast<int>(cr.x+8),cy=static_cast<int>(cr.y+cr.h*.72f);
        const auto first=panel.createComponentSnapshot(panel.getLocalBounds()).getPixelAt(cx,cy);
        bool blink=false;
        for(int i=0;i<12&&!blink;++i) {
            juce::MessageManager::getInstance()->runDispatchLoopUntil(60);
            blink=panel.createComponentSnapshot(panel.getLocalBounds()).getPixelAt(cx,cy)!=first;
        }
        check(blink,"Selected-only Capture blinks");saveImage(panel,folder,"selected-capture.png");
        check(ea::AutomationPanel::menuOptionsAt(&panel,{-1250,65}).getTargetScreenArea()==juce::Rectangle<int>(-1250,65,1,1),"Menu anchor follows cursor even on a monitor with negative coordinates");
        host.publish("version=2.2.3\n");
        for(const auto& kind:{"", "settings", "preview_menu", "paste_menu"}) {
            auto menu=panel.makePopupMenu(kind);
            juce::PopupMenu::MenuItemIterator item(menu,false);
            check(item.next()&&item.getItem().isSectionHeader&&item.getItem().itemID==0
                &&item.getItem().text=="EA Native Automation v2.2.3","All context menus display the running engine version without an actionable header");
        }
        for(const auto& kind:{"context","paste_menu"}) {
            auto sendMenu=panel.makePopupMenu(kind);
            std::set<int> ids;
            juce::PopupMenu::MenuItemIterator sendItem(sendMenu,true);
            while(sendItem.next()) if(sendItem.getItem().itemID>=500&&sendItem.getItem().itemID<=510) ids.insert(sendItem.getItem().itemID);
            check(ids.size()==10,"Copy/Paste and context menus expose ten separate send-copy commands");
        }
        host.publish("version=2.2.4\n");
        auto changedMenu=panel.makePopupMenu("");
        juce::PopupMenu::MenuItemIterator changedItem(changedMenu,false);
        check(changedItem.next()&&changedItem.getItem().text=="EA Native Automation v2.2.4","Menu version follows the connected script rather than a hard-coded UI version");
        host.publish("version=2.2.3\n");
        host.publish("preview=1\nscope=all\n");
        panel.setDockSide(-1);
        for(int percent:{50,75,100,125,150,175,200}) {
            const float scale=percent/100.f;panel.setUiScale(scale);panel.setSize(static_cast<int>(vertical.width*scale),static_cast<int>(std::round(vertical.height*scale)));
            click(panel,vertical,"manual_all",scale);check(std::string(host.bridge.next())=="write:all","Floating Manual hit target follows size preset");
        }
        host.publish("preview=1\npreview_suspended=0\ncapture=0\ncapture_selected=0\nscope=all\nmessage=\n");
        for(int percent:{50,75,100,125,150,175,200}) {
            const float ui=percent/100.f;
            for(int side:{0,2,4}) {
                checkStrip(panel,host,side,static_cast<int>(970*ui),static_cast<int>(40*ui),ui);
                checkStrip(panel,host,side,970,100,ui);
            }
            for(int side:{1,3}) {
                checkStrip(panel,host,side,static_cast<int>(88*ui),static_cast<int>(600*ui),ui);
                checkStrip(panel,host,side,220,600,ui);
            }
        }
        checkStrip(panel,host,2,970,40,1);saveImage(panel,folder,"fixed-row-one.png");
        checkStrip(panel,host,2,970,70,1);saveImage(panel,folder,"fixed-row-two.png");
        checkStrip(panel,host,1,88,600,1);saveImage(panel,folder,"fixed-column-one.png");
        checkStrip(panel,host,1,180,600,1);saveImage(panel,folder,"fixed-column-two.png");
        checkStrip(panel,host,0,970,40,1);
        juce::MouseWheelDetails wheel{};wheel.deltaY=-10;
        panel.mouseWheelMove(mouse(panel,100,15),wheel);check(stripBar(panel)->getCurrentRangeStart()>0,"Wheel scrolls horizontal overflow");
        panel.setSize(971,40);check(stripBar(panel)->getCurrentRangeStart()==0,"Docker divider resizing starts with the first controls rather than retaining a stale scroll offset");
        panel.setUiScale(1);panel.setDockSide(-1);panel.setSize(220,730);
        click(panel,vertical,"manual_all");check(std::string(host.bridge.next())=="write:all","Undocking restores the original floating arrangement");
        host.setUiPercent(75);check(host.uiPercent()==75,"Size preference persists through the host layer");
        for(unsigned mask=0;mask<=ea::AllSections;++mask) {
            host.setSectionMask(mask);panel.refresh();
            check(host.sectionMask()==mask,"Section visibility persists independently of automation state");
            checkStrip(panel,host,2,970,60,.5f);
            checkStrip(panel,host,1,100,1000,.5f);
            for(const auto& kind:{"context","settings"}) {
                auto menu=panel.makePopupMenu(kind);juce::PopupMenu::MenuItemIterator item(menu,true);
                unsigned found=0;
                while(item.next()) if(item.getItem().itemID>=600&&item.getItem().itemID<605) {
                    const auto bit=ea::sectionDefinitions()[static_cast<size_t>(item.getItem().itemID-600)].bit;
                    check(item.getItem().isTicked==((mask&bit)!=0),"Show sections menu checkmarks follow saved visibility");found|=bit;
                }
                check(found==ea::AllSections,"Both context and settings menus retain every section toggle even when hidden");
            }
        }
        host.setSectionMask(ea::AllSections);panel.refresh();
        for(const auto& section:ea::sectionDefinitions()) {
            const auto actionId=commandIds.at("EA_NATIVE_AUTOMATION_SHOW_"+std::string(section.id));
            check(host.handleAction(actionId)&&!(host.sectionMask()&section.bit),"Section shortcut hides its group");
            check(host.actionState(actionId)==0,"Hidden group shortcut state is unticked");
            check(std::string(host.bridge.next()).empty(),"Visibility never sends automation commands");
            host.handleAction(actionId);check(host.actionState(actionId)==1,"Section shortcut restores its group");
        }
        host.setSectionMask(0);host.handleAction(commandIds.at("EA_NATIVE_AUTOMATION_SHOW_ALL_SECTIONS"));
        check(host.sectionMask()==ea::AllSections,"Show all shortcut restores every section");
        host.save("visible_sections","invalid");check(host.sectionMask()==ea::AllSections,"Invalid visibility settings safely show all controls");
        host.setSectionMask(ea::AllSections);panel.refresh();
        host.setSectionMask(0);panel.refresh();
        checkStrip(panel,host,2,970,20,.5f);check(!stripBar(panel)->isVisible(),"The reported eight-control 50% row fits a 20-pixel Docker content height");
        saveImage(panel,folder,"compact-reported-row-50.png");
        checkStrip(panel,host,2,300,20,.5f);
        saveImage(panel,folder,"LCD-50-percent-1x.png",1);
        const auto lcd=panel.createComponentSnapshot(panel.getLocalBounds(),true,1);
        const auto join=control(ea::makePanelView(2,300,20,.5f,0).layout,"join");
        int top=lcd.getHeight(),bottom=-1,ink=0;
        for(int y=static_cast<int>(std::ceil(join.y*.5f+1));y<static_cast<int>((join.y+join.h)*.5f-1);++y)
            for(int x=static_cast<int>(std::ceil(join.x*.5f+2));x<static_cast<int>((join.x+join.w)*.5f-2);++x) {
                const auto colour=lcd.getPixelAt(x,y);
                if(colour.getRed()>185&&colour.getGreen()>185&&colour.getBlue()>185) {
                    top=std::min(top,y);bottom=std::max(bottom,y);++ink;
                }
            }
        check(bottom-top+1>=6&&ink>=12,"Real 1x compact label has a readable glyph height and solid foreground pixels");
        saveImage(panel,folder,"REAPER-font-50-percent-1x.png",1);
        checkStrip(panel,host,1,44,300,.5f);saveImage(panel,folder,"compact-reported-column-50.png");
        checkStrip(panel,host,2,970,28,ea::displayDockUiScale(0));saveImage(panel,folder,"compact-auto-row.png");
        host.setSectionMask(ea::AllSections);panel.refresh();
        checkStrip(panel,host,2,970,60,.5f);saveImage(panel,folder,"readable-row-small-preset.png");
        checkStrip(panel,host,1,100,1000,.5f);saveImage(panel,folder,"readable-column-small-preset.png");
        host.setSectionMask(ea::AllSections&~(ea::WriteEnableSection|ea::CopyPasteSection));panel.refresh();
        checkStrip(panel,host,2,1400,60,1);saveImage(panel,folder,"custom-sections-row.png");
        panel.setDockSide(-1);const auto compactFloating=ea::makeDockLayout(-1,0,0,1,host.sectionMask());
        panel.setSize(static_cast<int>(compactFloating.width),static_cast<int>(compactFloating.height));saveImage(panel,folder,"custom-sections-floating.png");
        host.setSectionMask(ea::AllSections);panel.refresh();
        for(const auto& definition:ea::actionCatalog()) if(definition.kind==ea::ActionKind::Engine) {
            check(host.handleAction(commandIds.at(definition.id)),"Native shortcut must be handled");
            check(std::string(host.bridge.next())==definition.command,"Every engine shortcut must queue the same command as its panel control");
        }
        host.publish("preview=1\npreview_suspended=1\nenabled_vol=1\nonstop_all=1\nscope=selected\nmode=3\nitems=1\n");
        for(const auto* id:{"PREVIEW","PREVIEW_SUSPEND","WRITE_ENABLE_VOLUME","WRITE_ON_STOP_ALL","SCOPE_SELECTED","MODE_3","ITEMS"})
            check(host.actionState(commandIds.at(std::string("EA_NATIVE_AUTOMATION_")+id))==1,"Action/toolbar toggles mirror published engine state");
        check(host.actionState(commandIds.at("EA_NATIVE_AUTOMATION_SCOPE_ALL"))==0,"Unselected track scope is not checked");
        const int previewAction=commandIds.at("EA_NATIVE_AUTOMATION_PREVIEW"),redraws=toolbarUpdates[previewAction];
        host.publish("preview=1\n");check(toolbarUpdates[previewAction]==redraws,"Unchanged engine state does not repeatedly refresh toolbars");
        host.publish("preview=0\nmode=\n");
        check(toolbarUpdates[previewAction]==redraws+1&&host.actionState(previewAction)==0,"Changed engine state refreshes its toolbar once");
        check(host.actionState(commandIds.at("EA_NATIVE_AUTOMATION_MODE_3"))==0,"Mixed track modes clear the mode radio state");

        // Exercise closed-panel shortcuts without creating a native window.
        // The fake Main_OnCommand records startup; connect is modelled on the next host tick.
        host.connect(false);
        const auto startsBeforeVisibility=engineStarts;
        host.handleAction(commandIds.at("EA_NATIVE_AUTOMATION_SHOW_SUSPEND"));
        check(engineStarts==startsBeforeVisibility&&host.actionState(commandIds.at("EA_NATIVE_AUTOMATION_SHOW_SUSPEND"))==0,"Visibility shortcut works with the engine closed without starting it");
        host.handleAction(commandIds.at("EA_NATIVE_AUTOMATION_SHOW_ALL_SECTIONS"));
        const auto resource=folder.getChildFile("test-resource");
        check(resource.getChildFile("UserPlugins/EA_Native_Automation").createDirectory().wasOk(),"Create mock installed resource");
        check(resource.getChildFile("UserPlugins/EA_Native_Automation/engine.lua").replaceWithText("-- Mock installed engine\n"),"Write mock installed engine");
        resourcePath=resource.getFullPathName().toStdString();
        const int beforeStarts=engineStarts;
        host.handleAction(commandIds.at("EA_NATIVE_AUTOMATION_WRITE_ALL"));
        host.handleAction(commandIds.at("EA_NATIVE_AUTOMATION_CAPTURE_SELECTED"));
        check(engineStarts==beforeStarts+1&&std::string(host.bridge.next()).empty(),"Closed-panel shortcuts start one engine and wait for connection");
        host.bridge.connected=true;host.tick();
        check(std::string(host.bridge.next())=="write:all"&&std::string(host.bridge.next())=="capture_selected","Waiting shortcuts dispatch in order after engine connection");
        host.tick();check(std::string(host.bridge.next()).empty(),"Waiting actions are not replayed on later host ticks");
        host.close();check(std::string(host.bridge.next())=="close","Closing clears queued actions and requests engine cleanup");host.connect(false);
        host.handleAction(commandIds.at("EA_NATIVE_AUTOMATION_COPY_ALL"));host.close();
        host.bridge.connected=true;host.tick();check(std::string(host.bridge.next()).empty(),"Closing during startup discards pending automation edits");host.connect(false);
        const auto installedResource=resourcePath;resourcePath=resource.getChildFile("missing").getFullPathName().toStdString();
        host.handleAction(commandIds.at("EA_NATIVE_AUTOMATION_PASTE_FILL"));
        host.bridge.connected=true;host.tick();check(std::string(host.bridge.next()).empty(),"Failed engine startup cannot replay stale edits later");host.connect(false);resourcePath=installedResource;
        std::cout<<"PASS: shortcut dispatch for every engine action, startup/close queue safety, toolbar state/change notifications, live theme accent, panel feedback, modifiers/blink, menus and dock hit testing\n";
        return 0;
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
