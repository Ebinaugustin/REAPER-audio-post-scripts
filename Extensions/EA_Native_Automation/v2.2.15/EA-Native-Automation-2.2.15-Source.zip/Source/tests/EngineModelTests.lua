-- Behavioral tests with a REAPER API model. Does not launch or alter REAPER.
local R, model = {}, {tracks={},master={guid='MASTER',envs={},fx={},selected=false,mode=1},selection={0,4},cursor=0,override=-1,play=0,pos=0,clock=1,autoadd=7,dialogs={},undos=0}
reaper=R;EA_AUTOMATION_TEST=true
local function selected() local t={};if model.master.selected then t[#t+1]=model.master end;for _,tr in ipairs(model.tracks) do if tr.selected then t[#t+1]=tr end end;return t end
local function sorted(p) table.sort(p,function(a,b) return a.t<b.t end);return p end
local function eval(points,t)
  if #points==0 then return 0 end
  local prev=points[1]
  for i=2,#points do local p=points[i];if t<p.t then local f=(t-prev.t)/(p.t-prev.t);if prev.s==1 then return prev.v end;return prev.v+(p.v-prev.v)*math.max(0,f) end;prev=p end
  return prev.v
end
local function envchunk(e)
  local s=('<%s\nACT %d -1\nVIS %d %d 1\nARM %d\nEGUID %s\n'):format(e.tag,e.active==false and 0 or 1,e.visible==false and 0 or 1,e.lane==false and 0 or 1,e.arm and 1 or 0,e.guid)
  for _,p in ipairs(e.points) do s=s..('PT %.17g %.17g %d 0 0 0 %.17g\n'):format(p.t,p.v,p.s or 0,p.z or 0) end
  for _,ai in ipairs(e.ais) do s=s..('POOLEDENVINST %d %.17g %.17g %.17g %.17g 0 0.5 1 0 0 0 0\n'):format(ai.pool,ai.pos,ai.len,ai.offset or 0,ai.rate or 1) end
  return s..'>\n'
end
function R.time_precise() return model.clock end
function R.ValidatePtr2(_,p,typ) return type(p)=='table' and not p.deleted end
function R.EnumProjects() return model end
function R.GetMasterTrack() return model.master end
function R.CountTracks() return #model.tracks end
function R.GetTrack(_,i) return model.tracks[i+1] end
function R.CountSelectedTracks2() return #selected() end
function R.GetSelectedTrack2(_,i) return selected()[i+1] end
function R.SetTrackSelected(tr,v) tr.selected=v end
function R.GetTrackGUID(tr) return tr.guid end
function R.CountTrackEnvelopes(tr) return #tr.envs end
function R.GetTrackEnvelope(tr,i) return tr.envs[i+1] end
function R.GetEnvelopeStateChunk(e) return true,envchunk(e) end
function R.GetSetEnvelopeInfo_String(e,key,v,write)
  if key=='GUID' then return true,e.guid end
  if key=='ARM' then if write then e.arm=v=='1' end;return true,e.arm and '1' or '0' end
  if key=='ACTIVE' then if write then e.active=v=='1' end;return true,e.active==false and '0' or '1' end
  if key=='VISIBLE' then if write then e.visible=v=='1' end;return true,e.visible==false and '0' or '1' end
  if key=='SHOWLANE' then if write then e.lane=v=='1' end;return true,e.lane==false and '0' or '1' end
  return false,''
end
function R.SetEnvelopeStateChunk(e,s)
  if model.refuse_chunks then error('Full envelope-state rewrite during Manual Write') end
  local points={}
  for t,v,shape in s:gmatch('\nPT ([%d.e+%-]+) ([%d.e+%-]+) (%d+)') do
    points[#points+1]={t=tonumber(t),v=tonumber(v),s=tonumber(shape),z=0}
  end
  e.points=points
  e.arm=s:match('\nARM (%d+)')=='1'
  e.active=s:match('\nACT (%d+)')=='1';e.visible=s:match('\nVIS (%d+)')=='1';e.lane=s:match('\nVIS %d+ (%d+)')=='1'
  local ais={}
  for pool,pos,len,off,rate in s:gmatch('POOLEDENVINST (%d+) ([%d.e+%-]+) ([%d.e+%-]+) ([%d.e+%-]+) ([%d.e+%-]+)') do
    local original;for _,a in ipairs(e.ais) do if a.pool==tonumber(pool) then original=a;break end end
    ais[#ais+1]={pool=tonumber(pool),pos=tonumber(pos),len=tonumber(len),offset=tonumber(off),rate=tonumber(rate),points=original and original.points or {}}
  end
  e.ais=ais;return true
end
function R.Envelope_GetParentTrack(e) return e.tr,e.fx or -1,e.param or -1 end
function R.GetEnvelopeInfo_Value(e,k) return k=='I_SEND_IDX' and (e.send and e.cat~=1 and e.send+1 or 0) or k=='I_HWOUT_IDX' and (e.send and e.cat==1 and e.send+1 or 0) or 0 end
function R.GetEnvelopeName(e) return true,e.name or e.tag end
function R.GetTrackSendInfo_Value(tr,cat,i,k)
  local s=(cat==1 and tr.hws or tr.sends or {})[i+1];if not s then return nil end
  if k:sub(1,6)=='P_ENV:' then
    local tag=k:sub(8)
    for _,env in ipairs(tr.envs) do if env.send==i and (env.cat or 0)==cat and env.tag:find(tag,1,true) then return env end end
    return nil
  end
  return s[k]
end
function R.SetTrackSendInfo_Value(tr,cat,i,k,v) (cat==1 and tr.hws or tr.sends)[i+1][k]=v;return true end
function R.GetTrackNumSends(tr,cat) return cat==0 and #(tr.sends or {}) or cat==1 and #(tr.hws or {}) or 0 end
local function ui_route(tr,index)
  local count=#(tr.hws or {})
  return index<count and tr.hws[index+1] or (tr.sends or {})[index-count+1]
end
function R.GetTrackSendUIVolPan(tr,index) local s=ui_route(tr,index);if not s then return false end;local u=s.ui or s;return true,u.D_VOL,u.D_PAN end
function R.GetTrackSendUIMute(tr,index) local s=ui_route(tr,index);if not s then return false end;return true,(s.ui or s).B_MUTE==1 end
function R.SetTrackSendUIVol(tr,index,v) local s=ui_route(tr,index);s.ui=s.ui or {};s.ui.D_VOL=v;s.D_VOL=v;model.send_edit=index;return true end
function R.SetTrackSendUIPan(tr,index,v) local s=ui_route(tr,index);s.ui=s.ui or {};s.ui.D_PAN=v;s.D_PAN=v;model.send_edit=index;return true end
function R.TrackFX_GetNamedConfigParm(tr,i,k) local f=tr.fx[i+1];if k=='fx_ident' then return true,f.id end;if k=='original_name' and f.original then return true,f.original end;return false,'' end
function R.TrackFX_GetFXName(tr,i) return true,tr.fx[i+1].id end
function R.TrackFX_GetFXGUID(tr,i) return tr.fx[i+1].guid end
function R.TrackFX_GetCount(tr) return #tr.fx end
function R.TrackFX_GetRecCount() return 0 end
function R.TrackFX_GetParamName(tr,i,p) local param=tr.fx[i+1].params[p+1];return param~=nil,param and param.name or '' end
function R.TrackFX_GetParamIdent(tr,i,p) return true,tostring(p) end
function R.TrackFX_GetParamFromIdent(tr,i,p) local index=tonumber(p);return index and index>=0 and index<#tr.fx[i+1].params and index or -1 end
function R.TrackFX_GetNumParams(tr,i) return #tr.fx[i+1].params end
function R.TrackFX_GetParam(tr,i,p) return tr.fx[i+1].params[p+1].value end
function R.TrackFX_SetParam(tr,i,p,v) tr.fx[i+1].params[p+1].value=v end
function R.GetFXEnvelope(tr,i,p,create)
  for _,e in ipairs(tr.envs) do if e.fx==i and e.param==p then return e end end
  return nil
end
function R.GetTrackEnvelopeByChunkName(tr,tag) for _,e in ipairs(tr.envs) do if '<'..e.tag==tag then return e end end end
function R.GetMediaTrackInfo_Value(tr,k)
  if k=='IP_TRACKNUMBER' then for i,t in ipairs(model.tracks) do if t==tr then return i end end;return 0 end
  if k=='I_AUTOMODE' then return tr.mode end
  if k:sub(1,6)=='P_ENV:' then for _,e in ipairs(tr.envs) do if e.guid==k:sub(7) then return e end end;return nil end
  return (tr.values or {})[k] or 0
end
function R.SetMediaTrackInfo_Value(tr,k,v) tr.values=tr.values or {};tr.values[k]=v end
function R.GetTrackUIVolPan(tr) local u=tr.ui or tr.values or {};return true,u.D_VOL or 0,u.D_PAN or 0 end
function R.GetTrackUIPan(tr)
  local u=tr.ui or tr.values or {};local mode=u.I_PANMODE or 5
  return true,mode==6 and u.D_DUALPANL or u.D_PAN,mode==6 and u.D_DUALPANR or u.D_WIDTH,mode
end
function R.GetTrackUIMute(tr) return true,(tr.ui or tr.values or {}).B_MUTE==1 end
function R.SetTrackUIVolume(tr,v,relative,done,gang) tr.values.D_VOL=v;tr.ui=tr.ui or {};tr.ui.D_VOL=v;model.track_edit={relative,done,gang} end
function R.SetTrackUIPan(tr,v,relative,done,gang) local u=tr.ui or tr.values;local key=u.I_PANMODE==6 and 'D_DUALPANL' or 'D_PAN';tr.values[key]=v;tr.ui=tr.ui or {};tr.ui[key]=v;model.track_edit={relative,done,gang} end
function R.SetTrackUIWidth(tr,v,relative,done,gang) local u=tr.ui or tr.values;local key=u.I_PANMODE==6 and 'D_DUALPANR' or 'D_WIDTH';tr.values[key]=v;tr.ui=tr.ui or {};tr.ui[key]=v;model.track_edit={relative,done,gang} end
function R.SetTrackUIMute(tr,v) tr.values.B_MUTE=v;tr.ui=tr.ui or {};tr.ui.B_MUTE=v end
function R.SetTrackAutomationMode(tr,mode)
  if model.mode_reveal and mode==5 then for _,e in ipairs(tr.envs) do e.visible=true;e.lane=true end end
  if model.mode_create_track==tr and mode==5 then
    local e={tr=tr,tag='VOLENV2',guid='AUTO-VOL-'..tr.guid,arm=true,active=true,visible=true,lane=true,points={{t=0,v=.6,s=0}},ais={}}
    tr.envs[#tr.envs+1]=e;model.created_envelope=e
  end
  if model.flush_track==tr and tr.mode==5 and mode~=5 then
    model.flush_track=nil
    for _,e in ipairs(tr.envs) do
      if e.native_latch then
        e.points={{t=0,v=.2,s=0},{t=5,v=e.native_latch,s=0},{t=5.0005,v=.2,s=0},{t=10,v=.2,s=0}}
      end
    end
  end
  tr.mode=mode
end
function R.GetGlobalAutomationOverride() return model.override end
function R.SetGlobalAutomationOverride(v) model.override=v end
function R.SNM_GetIntConfigVar() return model.autoadd end
function R.SNM_SetIntConfigVar(_,v) model.autoadd=v;model.autoadd_writes=(model.autoadd_writes or 0)+1 end
function R.Envelope_Evaluate(e,t)
  for _,ai in ipairs(e.ais) do if t>=ai.pos and t<ai.pos+ai.len then return 1,eval(ai.points,t) end end
  return 1,eval(e.points,t)
end
function R.GetEnvelopeScalingMode(e) return e.scaling or 0 end
function R.ScaleToEnvelopeMode(mode,v) return mode==1 and v*2 or v end
function R.ScaleFromEnvelopeMode(mode,v) return mode==1 and v/2 or v end
function R.GetEnvelopeUIState(e) return e.ui or 0 end
function R.CountEnvelopePoints(e) return #e.points end
function R.GetEnvelopePoint(e,i) local p=e.points[i+1];if not p then return false end;return true,p.t,p.v,p.s or 0,p.z or 0,false end
function R.CountAutomationItems(e) return #e.ais end
function R.CountEnvelopePointsEx(e,ai) return ai==-1 and #e.points or #e.ais[ai+1].points end
function R.GetEnvelopePointEx(e,ai,i) local p=(ai==-1 and e.points or e.ais[ai+1].points)[i+1];if not p then return false end;return true,p.t,p.v,p.s or 0,p.z or 0,false end
function R.InsertEnvelopePointEx(e,ai,t,v,s,z,selected) local list=ai==-1 and e.points or e.ais[ai+1].points;list[#list+1]={t=t,v=v,s=s,z=z,selected=selected};return true end
function R.DeleteEnvelopePointRangeEx(e,ai,a,b) local list=ai==-1 and e.points or e.ais[ai+1].points;for i=#list,1,-1 do if list[i].t>=a and list[i].t<b then table.remove(list,i) end end;return true end
function R.Envelope_SortPointsEx(e,ai) sorted(ai==-1 and e.points or e.ais[ai+1].points);return true end
function R.InsertAutomationItem(e,pool,pos,len) local idx=#e.ais;e.ais[#e.ais+1]={pool=1000+idx,pos=pos,len=len,points={},rate=1,offset=0};return idx end
local aikeys={D_POSITION='pos',D_LENGTH='len',D_PLAYRATE='rate',D_STARTOFFS='offset',D_POOL_ID='pool'}
function R.GetSetAutomationItemInfo(e,i,key,v,set) local a=e.ais[i+1];local k=aikeys[key] or key;if set then a[k]=v end;return a[k] or 0 end
function R.GetSet_LoopTimeRange(set,isloop,a,b)
  local key=isloop and 'loop' or 'selection'
  if set then model[key]={a,b} end
  return table.unpack(model[key] or {0,0})
end
function R.GetProjectLength() return 20 end
function R.GetCursorPosition() return model.cursor end
function R.GetPlayPosition() return model.pos end
function R.GetPlayState() return model.play end
function R.CountSelectedMediaItems() return 0 end
function R.Undo_BeginBlock2() model.undos=model.undos+1 end
function R.Undo_EndBlock2() model.undos=model.undos-1 end
function R.PreventUIRefresh() end
function R.UpdateArrange() end
function R.Main_OnCommand(cmd)
  model.command=cmd
  if cmd==42026 then
    for _,tr in ipairs(selected()) do for _,env in ipairs(tr.envs) do env.ui=(env.ui or 0) & ~2 end end
    return
  end
  if cmd~=42013 then return end
  if model.native_reveal then
    for _,tr in ipairs({model.master,table.unpack(model.tracks)}) do for _,e in ipairs(tr.envs) do e.visible=true;e.lane=true end end
  end
  if model.fail_native_write then error('Simulated host write failure') end
  model.native_writes=(model.native_writes or 0)+1
  if model.native_noop then return end
  for _,tr in ipairs({model.master,table.unpack(model.tracks)}) do
    for _,e in ipairs(tr.envs) do
      if e.arm and ((e.ui or 0) & 2)~=0 and e.native_latch~=nil then
        -- Model the host's INTERNAL latch, deliberately independent of its UI
        -- and stored trim reads. A native commit is an envelope edit, not a ride.
        local a,b=table.unpack(model.selection)
        local before,after=eval(e.points,a-1e-6),eval(e.points,b+1e-6)
        if model.native_dip then
          R.InsertEnvelopePointEx(e,-1,5,e.native_latch,0,0,false)
          R.InsertEnvelopePointEx(e,-1,5.0005,.2,0,0,false)
          R.Envelope_SortPointsEx(e,-1)
          goto continue_envelope
        end
        R.DeleteEnvelopePointRangeEx(e,-1,a-5e-7,b+5e-7)
        if a>0 then R.InsertEnvelopePointEx(e,-1,a-1e-6,before,1,0,false) end
        R.InsertEnvelopePointEx(e,-1,a,e.native_latch,1,0,false)
        R.InsertEnvelopePointEx(e,-1,b,e.native_latch,1,0,false)
        R.InsertEnvelopePointEx(e,-1,b+1e-6,after,0,0,false)
        R.Envelope_SortPointsEx(e,-1)
        ::continue_envelope::
      end
    end
  end
end
function R.ShowMessageBox(s,title,buttons)
  model.dialogs[#model.dialogs+1]=s
  model.last_dialog={text=s,title=title,buttons=buttons}
  if model.dialog_hook then model.dialog_hook(s,title,buttons) end
  return model.dialog_answer or 1
end
function R.SetExtState(section,key,value) model.ext=model.ext or {};model.ext[section..key]=value end
function R.GetOS() return 'Win64' end
local E=dofile(arg[1] or 'runtime/EA_Native_Automation/engine.lua')
local assertions,tests=0,0
local function eq(a,b,message) assertions=assertions+1;if a~=b then error((message or '')..': expected '..tostring(b)..', got '..tostring(a),2) end end
local function near(a,b,message) assertions=assertions+1;if math.abs(a-b)>1e-5 then error((message or '')..': expected '..b..', got '..a,2) end end
local function track(guid) local tr={guid=guid,envs={},fx={},values={D_VOL=0.6,D_PAN=.25,D_WIDTH=1,B_MUTE=0},selected=false,mode=1};model.tracks[#model.tracks+1]=tr;return tr end
local serial=0
local function envelope(tr,tag,points,fx,param)
  serial=serial+1;local e={tr=tr,tag=tag,guid='ENV'..serial,arm=true,points=sorted(points or {{t=0,v=0,s=0},{t=4,v=1,s=0}}),ais={},fx=fx,param=param};tr.envs[#tr.envs+1]=e;return e
end
local a,b=track('A'),track('B');a.selected=true
local pan=envelope(a,'PANENV2');local vol=envelope(a,'VOLENV2');local mute=envelope(a,'MUTEENV')
local dp=envelope(b,'PANENV2');local dv=envelope(b,'VOLENV2');local dm=envelope(b,'MUTEENV')
local function test(name,fn) tests=tests+1;fn();print('PASS '..name) end
test('native categories',function() eq(E._test.descriptor(a,pan).group,'pan');eq(E._test.descriptor(a,vol).group,'vol');eq(E._test.descriptor(a,mute).group,'mute') end)
test('ReaSurround and ordinary FX separation',function()
  a.fx={{id='VST: ReaSurround (Cockos)',guid='F1',params={{name='Input 1 X',value=.75}}},{id='EQ',guid='F2',params={{name='Gain',value=.2},{name='Object ID',value=.3}}}}
  local rs=envelope(a,'PARMENV',nil,0,0);local eqenv=envelope(a,'PARMENV',nil,1,0);local ob=envelope(a,'PARMENV',nil,1,1)
  eq(E._test.descriptor(a,rs).group,'pan');eq(E._test.descriptor(a,eqenv).group,'plugin');eq(E._test.descriptor(a,ob).group,'plugin');eq(E.enabled.objbus,nil)
end)
test('write protection preserves the automatic-envelope preference',function()
  E.toggle_group('vol');eq(vol.arm,false);eq(pan.arm,true);eq(model.autoadd,7)
  E.toggle_group('vol');eq(vol.arm,true);eq(model.autoadd,7)
end)
test('scope excludes unselected tracks',function() E.scope='selected';E.toggle_group('pan');eq(pan.arm,false);eq(dp.arm,true);E.toggle_group('pan');E.scope='all' end)
test('suspend restores previous global override',function() model.override=4;E.suspend();eq(model.override,5);E.suspend();eq(model.override,4);model.override=-1 end)
test('preview off restores track modes and no global override',function() model.override=2;E.preview_toggle();eq(a.mode,5);eq(model.override,-1);E.preview_toggle();eq(a.mode,1);eq(model.override,-1) end)
test('copy pan includes ReaSurround without volume or other FX',function() E.copy('pan');eq(#E.clipboard.tracks,1);eq(#E.clipboard.tracks[1].envs,2);eq(E.clipboard.duration,4) end)
test('copy all includes all six existing source envelopes',function() E.copy('all');eq(#E.clipboard.tracks[1].envs,6) end)
test('stretch pan to selection and preserve original underlying points',function()
  E.use_items=true
  E.copy('pan');b.fx={{id='VST: ReaSurround (Cockos)',guid='FB',params={{name='Input 1 X',value=0}}}};envelope(b,'PARMENV',nil,0,0)
  a.selected=false;b.selected=true;model.selection={10,18};E.paste('fit')
  eq(#dp.ais,1);eq(#dp.points,2);near(select(2,R.Envelope_Evaluate(dp,14)),.5);near(select(2,R.Envelope_Evaluate(dp,9)),1)
end)
test('fill partial repeat and preserve reset discontinuities',function()
  dp.ais={};model.selection={10,20};E.paste('fill');eq(#dp.ais,1)
  near(select(2,R.Envelope_Evaluate(dp,11)),.25);near(select(2,R.Envelope_Evaluate(dp,15)),.25);near(select(2,R.Envelope_Evaluate(dp,19)),.25);near(dp.ais[1].points[#dp.ais[1].points].v,.5)
end)
test('cursor paste uses original duration',function() dp.ais={};model.cursor=25;E.paste('cursor');near(dp.ais[1].pos,25);near(dp.ais[1].len,4);E.use_items=false end)
test('copy failure leaves earlier clipboard available',function() b.selected=false;local previous=E.clipboard;E.copy('all');eq(E.clipboard,previous);b.selected=true end)
test('no destination selection prevents a paste',function() b.selected=false;local old=#dp.ais;E.paste('fit');eq(#dp.ais,old);b.selected=true end)
test('paste requires selection and stopped playback',function() local old=#dp.ais;model.selection={0,0};E.paste('fit');eq(#dp.ais,old);model.play=1;E.paste('cursor');eq(#dp.ais,old);model.play=0 end)
test('matching FX identity instead of chain index',function()
  local rs=a.envs[4];local d=E._test.descriptor(a,rs)
  b.fx={{id='Other',guid='OTHER',params={{name='Other',value=0}}},{id='VST: ReaSurround (Cockos)',guid='RS2',params={{name='Input 1 X',value=.1}}}}
  b.envs[4].fx=1;eq(E._test.resolve(b,d,false),b.envs[4])
end)
test('missing plug-in is reported rather than mapped to unrelated FX',function()
  local d=E._test.descriptor(a,a.envs[5]);local env,why=E._test.resolve(b,d,false);eq(env,nil);eq(why:find('Missing FX')~=nil,true)
end)
test('send mute values use envelope unmuted polarity',function()
  a.sends={{P_DESTTRACK=b,I_DSTCHAN=0,I_SRCCHAN=0,B_MUTE=1,D_VOL=.8,D_PAN=.4}}
  local se=envelope(a,'AUXMUTEENV');se.send=0
  local h={tr=a,env=se,d=E._test.descriptor(a,se)};eq(h.d.group,'smute');near(E._test.live_value(h,0),0)
end)
test('crossing pooled automation items are split without changing pool',function()
  local e=envelope(b,'WIDTHENV2');e.ais={{pool=88,pos=0,len=10,offset=1,rate=2,points={{t=0,v=.1,s=0},{t=10,v=.9,s=0}}}}
  E._test.clear_ai_interval(e,3,7);eq(#e.ais,2);near(e.ais[1].len,3);near(e.ais[2].pos,7);near(e.ais[2].offset,15);eq(e.ais[2].pool,88)
end)
test('copy automation item composite is independent of the pool',function()
  local e=envelope(b,'PANENV');e.ais={{pool=5,pos=0,len=4,points={{t=0,v=.3,s=0},{t=4,v=.7,s=0}}}}
  local pts,baked=E._test.copy_curve(e,0,4);eq(baked,true);near(pts[1].v,.3);near(pts[#pts].v,.7);eq(#pts,2)
end)
test('manual all writes ordinary envelopes by default',function()
  E.scope='selected';model.selection={2,6};E.capture=nil;E.write('all');eq(#dv.ais,0);near(select(2,R.Envelope_Evaluate(dv,3)),.6);E.scope='all'
end)
test('captured punch writes only captured envelopes and restores others',function()
  E.scope='selected';E.capture={{tr=b,env=dv,d=E._test.descriptor(b,dv),value=.42}}
  local previous=dp.arm;E.punch_values();eq(b.mode,3);eq(dv.arm,true);eq(dp.arm,false)
  near(b.values.D_VOL,.42);E.end_punch();eq(b.mode,1);eq(dp.arm,previous);E.capture=nil;E.scope='all'
end)
test('auto match preserves selected scope and original track selection',function() E.scope='selected';E.match();eq(model.command,42026);eq(b.selected,true);eq(a.selected,false);E.scope='all' end)
test('write on stop commits a valid pass',function()
  E.scope='selected';E.onstop.all=true;model.selection={6,9};E.lastplay=1;E.lastpos=8
  E.pass_values={{tr=b,env=dv,d=E._test.descriptor(b,dv),value=.33}};E.poll()
  near(select(2,R.Envelope_Evaluate(dv,7)),.33);eq(E.join_saved.position,8);E.onstop={};E.scope='all'
end)
test('undo blocks remain balanced',function() eq(model.undos,0) end)
test('cleanup restores protected envelope arms without changing preferences',function() E.toggle_group('vol');eq(dv.arm,false);E.cleanup();eq(dv.arm,true);eq(model.autoadd,7) end)
for _,k in ipairs({'plugin','vol','svol','pan','span','mute','smute'}) do E.enabled[k]=true end
test('sampled flat source reduces to two endpoints with no default-value ramp',function()
  local e=envelope(a,'WIDTHENV2',{{t=0,v=.5,s=0},{t=4,v=.5,s=0}})
  e.ais={{pool=90,pos=0,len=4,points={{t=0,v=1,s=0},{t=4,v=1,s=0}}}}
  local pts=E._test.copy_curve(e,0,4)
  eq(#pts,2);near(pts[1].v,1);near(pts[2].v,1)
  local target=envelope(b,'WIDTHENV',{{t=0,v=.5,s=0},{t=30,v=.5,s=0}})
  E._test.replace_curve(target,10,18,{{t=10,v=pts[1].v,s=0},{t=18,v=pts[2].v,s=0}},0)
  eq(#target.ais,0);near(select(2,R.Envelope_Evaluate(target,17.9)),1)
  local inside=0;for _,p in ipairs(target.points) do if p.t>=10 and p.t<=18 then inside=inside+1;eq(p.selected,false) end end
  eq(inside,2);near(select(2,R.Envelope_Evaluate(target,19)),.5)
end)
test('constant repeat fill has only selection endpoints',function()
  local target=envelope(b,'VOLENV3',{{t=0,v=1,s=0},{t=30,v=1,s=0}})
  E.clipboard={duration=4,tracks={{envs={{d=E._test.descriptor(b,target),points={{t=0,v=1,s=0},{t=4,v=1,s=0}},scaling=0}}}}}
  a.selected=false;b.selected=true;model.selection={10,21};E.paste('fill')
  eq(#target.ais,0);local count=0;for _,p in ipairs(target.points) do if p.t>=10 and p.t<=21 then count=count+1;near(p.v,1) end end;eq(count,2)
  for t=10,20 do near(select(2,R.Envelope_Evaluate(target,t+.5)),1) end
end)
test('constant stretch has no dense points',function()
  local target=b.envs[#b.envs];model.selection={12,26};E.paste('fit')
  local count=0;for _,p in ipairs(target.points) do if p.t>=12 and p.t<=26 then count=count+1 end end;eq(count,2);eq(#target.ais,0)
end)
test('step automation remains a step during point reduction',function()
  local pts=E._test.compact_points({{t=0,v=0,s=1},{t=1,v=1,s=1},{t=2,v=1,s=1},{t=3,v=1,s=1}})
  eq(#pts,3);near(eval(pts,.5),0);near(eval(pts,1.5),1)
end)
test('repeat boundaries remain sharp when source endpoints differ',function()
  local target=envelope(b,'PANENV2',{{t=0,v=0,s=0},{t=40,v=0,s=0}})
  E.clipboard={duration=4,tracks={{envs={{d=E._test.descriptor(b,target),points={{t=0,v=0,s=0},{t=4,v=1,s=0}},scaling=0}}}}}
  model.selection={10,18};E.paste('fill')
  near(select(2,R.Envelope_Evaluate(target,13.9)),.975, 'End of first ramp retained')
  near(select(2,R.Envelope_Evaluate(target,14.0001)),.000025,'Next repeat resets immediately')
  near(select(2,R.Envelope_Evaluate(target,17.9)),.975,'Second ramp retained')
end)
test('renamed and spaced ReaSurround names still belong to PAN',function()
  a.fx[#a.fx+1]={id='opaque_fx_id',original='VST3: Rea Surround Pan (Cockos)',guid='RENAMED',params={{name='Object pan',value=.5}}}
  local env=envelope(a,'PARMENV',nil,#a.fx-1,0);eq(E._test.descriptor(a,env).group,'pan')
end)
-- Model full track chunks and receiver-owned send envelopes. The earlier
-- tests had only pre-existing native envelopes and missed the creation path.
function R.GetTrackStateChunk(tr)
  local rows={'<TRACK','NAME "'..tr.guid..'"','TRACKID '..tr.guid}
  for _,env in ipairs(tr.envs) do if env.send==nil and env.fx==nil then rows[#rows+1]=envchunk(env) end end
  for i,send in ipairs(tr.hws or {}) do
    rows[#rows+1]=('HWOUT %d 0 %.17g %.17g %d 0 0 %d %d -1 0 -1'):format(send.I_DSTCHAN,send.D_VOL,send.D_PAN,send.B_MUTE,send.I_SRCCHAN,send.I_DSTCHAN)
    for _,env in ipairs(tr.envs) do if env.send==i-1 and env.cat==1 then rows[#rows+1]=envchunk(env) end end
  end
  for source_index,source in ipairs(model.tracks) do
    for send_index,send in ipairs(source.sends or {}) do if send.P_DESTTRACK==tr then
      rows[#rows+1]=('AUXRECV %d 0 %.17g %.17g %d 0 0 %d %d -1 0 -1'):format(source_index-1,send.D_VOL,send.D_PAN,send.B_MUTE,send.I_SRCCHAN,send.I_DSTCHAN)
      for _,env in ipairs(source.envs) do if env.send==send_index-1 and (env.cat or 0)==0 then rows[#rows+1]=envchunk(env) end end
    end end
  end
  rows[#rows+1]='<FXCHAIN\n<PARMENV 0 0 1 0.5\nPT 0 0.5 0\n>\n>\n>'
  return true,table.concat(rows,'\n')..'\n'
end
function R.SetTrackStateChunk(tr,text)
  tr.last_chunk=text
  local depth,receive,collect,counts=0,nil,nil,{}
  local function commit(node)
    local owner,index,cat=tr,nil,0
    if node.tag:match('^AUX') then
      if not node.receive then error('Send envelope lacks a receive record') end
      owner,index=node.receive.owner,node.receive.index
    elseif node.tag:match('^HW') then index,cat=node.receive.index,1 end
    local existing
    for _,env in ipairs(owner.envs) do if env.tag==node.tag and env.send==index and (env.cat or 0)==cat then existing=env;break end end
    if not existing then
      local pts={}
      for t,v,s in node.text:gmatch('\nPT ([%d.e+%-]+) ([%d.e+%-]+) (%d+)') do pts[#pts+1]={t=tonumber(t),v=tonumber(v),s=tonumber(s)} end
      existing=envelope(owner,node.tag,pts);existing.send=index;existing.cat=cat
    end
    existing.active=node.text:match('\nACT (%d+)')=='1';existing.visible=node.text:match('\nVIS (%d+)')=='1'
    existing.arm=node.text:match('\nARM (%d+)')=='1'
  end
  for line in text:gmatch('[^\n]+') do
    local body=line:match('^%s*(.-)%s*$')
    if depth==1 then
      local source=body:match('^AUXRECV (%d+)')
      if source then
        local owner=model.tracks[tonumber(source)+1];counts[source]=(counts[source] or 0)+1
        local ordinal,index=0,nil
        for i,send in ipairs(owner.sends or {}) do if send.P_DESTTRACK==tr then ordinal=ordinal+1;if ordinal==counts[source] then index=i-1;break end end end
        receive={owner=owner,index=index}
      elseif body:match('^HWOUT ') then counts.hw=(counts.hw or 0)+1;receive={owner=tr,index=counts.hw-1}
      end
      local tag=body:match('^<([%w_]+)')
      if tag and tag~='FXCHAIN' then collect={tag=tag,text='',receive=receive} end
    end
    if collect then collect.text=collect.text..line..'\n' end
    if body:sub(1,1)=='<' then depth=depth+1 elseif body=='>' then depth=depth-1;if collect and depth==1 then commit(collect);collect=nil end end
  end
  return true
end
function R.CreateTrackSend() error('Paste must never create a send') end
local function select_only(tr) for _,t in ipairs(model.tracks) do t.selected=t==tr end end
local function route(bus) return {P_DESTTRACK=bus,I_SRCCHAN=0,I_DSTCHAN=0,D_VOL=.8,D_PAN=.2,B_MUTE=0} end
local function paste_from(source,dest,filter)
  select_only(source);model.selection={0,4};E.copy(filter or 'all')
  select_only(dest);model.selection={10,18};E.paste('fit')
end
local cs,cd,bus1,bus2=track('CROSS SOURCE'),track('CROSS DEST'),track('BUS ONE'),track('BUS TWO')
local cpan=envelope(cs,'PANENV2',{{t=0,v=-.6,s=0},{t=4,v=.4,s=0}})
local cvol=envelope(cs,'VOLENV2',{{t=0,v=.25,s=0},{t=4,v=.75,s=0}})
test('cross-track native pan and volume create active visible envelopes on a blank track',function()
  local dialogs=#model.dialogs;paste_from(cs,cd)
  local ep=R.GetTrackEnvelopeByChunkName(cd,'<PANENV2');local ev=R.GetTrackEnvelopeByChunkName(cd,'<VOLENV2')
  eq(ep~=nil,true);eq(ev~=nil,true);eq(ep.visible,true);eq(ep.active,true);eq(ev.visible,true);eq(ev.active,true)
  near(select(2,R.Envelope_Evaluate(ep,14)),-.1);near(select(2,R.Envelope_Evaluate(ev,14)),.5)
  near(select(2,R.Envelope_Evaluate(ev,9)),cd.values.D_VOL);near(select(2,R.Envelope_Evaluate(ep,9)),-cd.values.D_PAN)
  eq(#model.dialogs,dialogs,'Successful native paste opens no dialog');eq(#ep.ais,0)
end)
test('cross-track paste activates and reveals a hidden bypassed envelope',function()
  local ep=R.GetTrackEnvelopeByChunkName(cd,'<PANENV2');ep.visible=false;ep.active=false
  paste_from(cs,cd,'pan');eq(ep.visible,true);eq(ep.active,true);near(select(2,R.Envelope_Evaluate(ep,14)),-.1)
end)
local sendvol=envelope(cs,'AUXVOLENV',{{t=0,v=.2,s=0},{t=4,v=.6,s=0}});sendvol.send=0
local sendpan=envelope(cs,'AUXPANENV',{{t=0,v=-.4,s=0},{t=4,v=.2,s=0}});sendpan.send=0
local sendmute=envelope(cs,'AUXMUTEENV',{{t=0,v=1,s=1},{t=2,v=0,s=1},{t=4,v=1,s=1}});sendmute.send=0
cs.sends={route(bus1)};cd.sends={route(bus2),route(bus1)}
test('existing send bus match wins over its slot and creates send volume pan mute envelopes',function()
  local dialogs=#model.dialogs;paste_from(cs,cd)
  for _,tag in ipairs({'VOLENV','PANENV','MUTEENV'}) do
    eq(R.GetTrackSendInfo_Value(cd,0,0,'P_ENV:<'..tag),nil,'Unrelated earlier send unchanged')
    local env=R.GetTrackSendInfo_Value(cd,0,1,'P_ENV:<'..tag)
    eq(env~=nil,true);eq(env.visible,true);eq(env.active,true)
  end
  near(select(2,R.Envelope_Evaluate(R.GetTrackSendInfo_Value(cd,0,1,'P_ENV:<VOLENV'),14)),.4)
  near(select(2,R.Envelope_Evaluate(R.GetTrackSendInfo_Value(cd,0,1,'P_ENV:<PANENV'),14)),-.1)
  near(select(2,R.Envelope_Evaluate(R.GetTrackSendInfo_Value(cd,0,1,'P_ENV:<MUTEENV'),15)),0)
  eq(#cd.sends,2);eq(#model.dialogs,dialogs,'Successful send paste opens no dialog')
end)
test('different existing send target falls back to send slot without changing routing',function()
  local dest=track('SLOT DEST');dest.sends={route(bus2)};local dialogs=#model.dialogs
  paste_from(cs,dest)
  local env=R.GetTrackSendInfo_Value(dest,0,0,'P_ENV:<VOLENV');eq(env~=nil,true)
  near(select(2,R.Envelope_Evaluate(env,14)),.4);eq(dest.sends[1].P_DESTTRACK,bus2);eq(#dest.sends,1);eq(#model.dialogs,dialogs)
end)
test('missing existing sends report missing parameters once while native automation still pastes',function()
  local dest=track('NO SEND DEST');local dialogs=#model.dialogs;paste_from(cs,dest)
  eq(#(dest.sends or {}),0);eq(#model.dialogs,dialogs+1)
  eq(E.last_report:find('Missing existing send')~=nil,true)
  near(select(2,R.Envelope_Evaluate(R.GetTrackEnvelopeByChunkName(dest,'<VOLENV2'),14)),.5)
end)
test('two source sends cannot overwrite the same destination send when matching and slots differ',function()
  local src,dest=track('TWO SEND SOURCE'),track('TWO SEND DEST')
  src.sends={route(bus1),route(bus2)};dest.sends={route(bus2),route(track('OTHER BUS'))}
  local one=envelope(src,'AUXVOLENV',{{t=0,v=.2,s=0},{t=4,v=.2,s=0}});one.send=0
  local two=envelope(src,'AUXVOLENV',{{t=0,v=.7,s=0},{t=4,v=.7,s=0}});two.send=1
  local dialogs=#model.dialogs;paste_from(src,dest)
  near(select(2,R.Envelope_Evaluate(R.GetTrackSendInfo_Value(dest,0,0,'P_ENV:<VOLENV'),14)),.7)
  near(select(2,R.Envelope_Evaluate(R.GetTrackSendInfo_Value(dest,0,1,'P_ENV:<VOLENV'),14)),.2)
  eq(#model.dialogs,dialogs);eq(#dest.sends,2)
end)
test('hardware output automation creates an envelope on an existing hardware output only',function()
  local src,dest=track('HW SOURCE'),track('HW DEST');src.hws={route(nil)};dest.hws={route(nil)}
  local env=envelope(src,'HWVOLENV',{{t=0,v=.3,s=0},{t=4,v=.9,s=0}});env.send=0;env.cat=1
  paste_from(src,dest);local got=R.GetTrackSendInfo_Value(dest,1,0,'P_ENV:<VOLENV')
  eq(got~=nil,true);near(select(2,R.Envelope_Evaluate(got,14)),.6);eq(#dest.hws,1)
end)
test('real dual pan chunk tags paste onto another track',function()
  local src,dest=track('DUAL SOURCE'),track('DUAL DEST')
  envelope(src,'DUALPANENVL2',{{t=0,v=.9,s=0},{t=4,v=.5,s=0}})
  envelope(src,'DUALPANENV2',{{t=0,v=-.9,s=0},{t=4,v=-.5,s=0}})
  paste_from(src,dest,'pan')
  near(select(2,R.Envelope_Evaluate(R.GetTrackEnvelopeByChunkName(dest,'<DUALPANENVL2'),14)),.7)
  near(select(2,R.Envelope_Evaluate(R.GetTrackEnvelopeByChunkName(dest,'<DUALPANENV2'),14)),-.7)
end)
test('pre-FX pan volume width trim and mute parameters paste across tracks',function()
  local src,dest=track('MORE NATIVE SOURCE'),track('MORE NATIVE DEST')
  for _,tag in ipairs({'PANENV','VOLENV','WIDTHENV','WIDTHENV2','VOLENV3','MUTEENV'}) do
    envelope(src,tag,{{t=0,v=.2,s=0},{t=4,v=.8,s=0}})
  end
  local dialogs=#model.dialogs;paste_from(src,dest)
  for _,tag in ipairs({'PANENV','VOLENV','WIDTHENV','WIDTHENV2','VOLENV3','MUTEENV'}) do
    local env=R.GetTrackEnvelopeByChunkName(dest,'<'..tag);eq(env~=nil,true);near(select(2,R.Envelope_Evaluate(env,14)),.5)
  end
  eq(#model.dialogs,dialogs)
end)
test('multiple sends to the same bus respect channels and the correct receive record',function()
  local src,dest=track('CHANNEL SOURCE'),track('CHANNEL DEST')
  src.sends={route(bus1),route(bus1)};src.sends[2].I_SRCCHAN=2
  dest.sends={route(bus1),route(bus1)};dest.sends[1].I_SRCCHAN=2
  local one=envelope(src,'AUXVOLENV',{{t=0,v=.1,s=0},{t=4,v=.1,s=0}});one.send=0
  local two=envelope(src,'AUXVOLENV',{{t=0,v=.9,s=0},{t=4,v=.9,s=0}});two.send=1
  local dialogs=#model.dialogs;paste_from(src,dest)
  near(select(2,R.Envelope_Evaluate(R.GetTrackSendInfo_Value(dest,0,0,'P_ENV:<VOLENV'),14)),.9)
  near(select(2,R.Envelope_Evaluate(R.GetTrackSendInfo_Value(dest,0,1,'P_ENV:<VOLENV'),14)),.1)
  eq(dest.sends[1].I_SRCCHAN,2);eq(dest.sends[2].I_SRCCHAN,0);eq(#model.dialogs,dialogs)
end)
test('only missing FX parameters trigger a dialog and valid track volume still pastes',function()
  local src,dest=track('PARAM SOURCE'),track('PARAM DEST')
  src.fx={{id='TestFX',guid='SRCFX',params={{name='Gain',value=0},{name='Threshold',value=.5}}}}
  dest.fx={{id='TestFX',guid='DSTFX',params={{name='Gain',value=0}}}}
  envelope(src,'VOLENV2',{{t=0,v=.4,s=0},{t=4,v=.4,s=0}});envelope(src,'PARMENV',nil,0,1)
  local dialogs=#model.dialogs;paste_from(src,dest)
  eq(#model.dialogs,dialogs+1);eq(E.last_report,'Missing parameter: Threshold')
  near(select(2,R.Envelope_Evaluate(R.GetTrackEnvelopeByChunkName(dest,'<VOLENV2'),14)),.4)
  eq(model.undos,0,'Partial paste leaves Undo balanced')
end)
local manual=track('MANUAL-LATCHED')
local mv=envelope(manual,'VOLENV2',{{t=0,v=2,s=0},{t=10,v=2,s=0}});mv.scaling=1
local mp=envelope(manual,'PANENV2',{{t=0,v=0,s=0},{t=10,v=0,s=0}})
manual.ui={D_VOL=.35,D_PAN=-.7,D_WIDTH=.45,B_MUTE=0,I_PANMODE=5}
test('manual selection writes latched UI volume and pan rather than stored trims',function()
  select_only(manual);E.scope='selected';E.preview=true;E.capture=nil;E.use_items=false;model.selection={2,8};model.cursor=5
  E.write('all')
  near(select(2,R.Envelope_Evaluate(mv,3)),.7,'Fader-scaled latch at start')
  near(select(2,R.Envelope_Evaluate(mv,7)),.7,'Fader-scaled latch at end')
  near(select(2,R.Envelope_Evaluate(mp,3)),.7,'Left UI pan becomes positive envelope pan')
  near(select(2,R.Envelope_Evaluate(mp,7)),.7,'Held through selection')
  near(select(2,R.Envelope_Evaluate(mv,1)),2,'Outside volume preserved')
  near(manual.values.D_VOL,.6,'Stored trim unchanged by point write')
  eq(#mv.ais,0,'No items for manual write by default')
end)
test('all five manual write ranges hold the actual knob value',function()
  local ranges={all={2,8},start={2,5},['end']={5,8},punch={3,5},next={5,6}}
  E.firsttouch=3;mp.arm=false
  for _,which in ipairs({'all','start','end','punch','next'}) do
    mv.points={{t=0,v=2,s=0},{t=6,v=2,s=0},{t=10,v=2,s=0}};model.selection={2,8};model.cursor=5
    E.write(which)
    local range=ranges[which]
    near(select(2,R.Envelope_Evaluate(mv,(range[1]+range[2])/2)),.7,which..' interior')
    near(select(2,R.Envelope_Evaluate(mv,range[1]+.01)),.7,which..' start')
    near(select(2,R.Envelope_Evaluate(mv,range[2]-.01)),.7,which..' end')
  end
  mp.arm=true;E.firsttouch=nil
end)
test('manual write activates bypassed native envelopes without revealing their lanes',function()
  mv.active=false;mv.visible=false;E.write('all');eq(mv.active,true);eq(mv.visible,false)
end)
test('manual send pan and volume use UI values with hardware-output offset',function()
  manual.hws={route(cd)};manual.sends={route(cd)}
  manual.hws[1].ui={D_VOL=.91,D_PAN=.2,B_MUTE=0}
  manual.sends[1].ui={D_VOL=.28,D_PAN=-.6,B_MUTE=0}
  local sp=envelope(manual,'AUXPANENV',{{t=0,v=0,s=0},{t=10,v=0,s=0}});sp.send=0;sp.cat=0
  local sv=envelope(manual,'AUXVOLENV',{{t=0,v=1,s=0},{t=10,v=1,s=0}});sv.send=0;sv.cat=0;sv.scaling=1
  local hp=envelope(manual,'HWPANENV',{{t=0,v=0,s=0},{t=10,v=0,s=0}});hp.send=0;hp.cat=1
  model.selection={2,8};E.write('all')
  near(select(2,R.Envelope_Evaluate(sp,4)),.6);near(select(2,R.Envelope_Evaluate(sv,4)),.56)
  near(select(2,R.Envelope_Evaluate(hp,4)),-.2);eq(#manual.sends,1);eq(#manual.hws,1)
  E._test.set_live({tr=manual,env=sp,d=E._test.descriptor(manual,sp)},.3)
  near(manual.sends[1].D_PAN,-.3);eq(model.send_edit,1,'Send UI index skips hardware slot')
  E._test.set_live({tr=manual,env=hp,d=E._test.descriptor(manual,hp)},-.4)
  near(manual.hws[1].D_PAN,.4);eq(model.send_edit,0)
end)
test('capture and punch round trip native pan width and dual-pan UI controls',function()
  local wp=envelope(manual,'WIDTHENV2');near(E._test.live_value({tr=manual,env=wp,d=E._test.descriptor(manual,wp)},0),.45)
  E._test.set_live({tr=manual,env=mp,d=E._test.descriptor(manual,mp)},.8)
  near(manual.ui.D_PAN,-.8);eq(model.track_edit[3],3,'No selection or grouping side effects')
  local lp=envelope(manual,'DUALPANENVL2');local rp=envelope(manual,'DUALPANENV2')
  manual.ui.I_PANMODE=6;manual.ui.D_DUALPANL=-.9;manual.ui.D_DUALPANR=.65
  near(E._test.live_value({tr=manual,env=lp,d=E._test.descriptor(manual,lp)},0),.9)
  near(E._test.live_value({tr=manual,env=rp,d=E._test.descriptor(manual,rp)},0),-.65)
  E._test.set_live({tr=manual,env=rp,d=E._test.descriptor(manual,rp)},-.2);near(manual.ui.D_DUALPANR,.2)
  manual.ui.I_PANMODE=5
end)
test('failed UI reads fall back with correct pan polarity and preserve scaling',function()
  local old=R.GetTrackUIVolPan;R.GetTrackUIVolPan=function() return false end
  near(E._test.live_value({tr=manual,env=mp,d=E._test.descriptor(manual,mp)},0),-manual.values.D_PAN)
  near(E._test.live_value({tr=manual,env=mv,d=E._test.descriptor(manual,mv)},0),manual.values.D_VOL*2)
  R.GetTrackUIVolPan=old
end)
test('Suspend bypasses all track and take envelopes and preserves existing bypasses and points',function()
  select_only(manual);E.scope='selected';model.override=4;E.preview=false
  for _,key in ipairs({'plugin','vol','svol','pan','span','mute','smute'}) do E.enabled[key]=true end
  dm.active=false;dv.active=true
  local takeenv={tag='VOLENV',guid='TAKE-ENV',active=true,arm=false,points={{t=0,v=.4,s=0}},ais={}}
  R.CountMediaItems=function() return 1 end;R.GetMediaItem=function() return {} end
  R.CountTakes=function() return 1 end;R.GetTake=function() return {} end
  R.CountTakeEnvelopes=function() return 1 end;R.GetTakeEnvelope=function() return takeenv end
  E.suspend();eq(model.override,5);eq(dv.active,false,'Unselected track envelope bypassed');eq(dm.active,false);eq(takeenv.active,false)
  local fresh=envelope(b,'WIDTHENV2');E.enforce();eq(fresh.active,false,'New envelope bypassed during Suspend')
  dv.points[1].v=.432;model.override=2;E.enforce();eq(model.override,5,'Global bypass remains engaged')
  E.preview_toggle();eq(E.preview,false,'Preview cannot defeat Suspend')
  E.suspend();eq(model.override,4);eq(dv.active,true);eq(dm.active,false,'Previously bypassed envelope stays bypassed')
  eq(takeenv.active,true);eq(fresh.active,true);near(dv.points[1].v,.432,'Envelope points are never restored from stale chunks')
  R.CountMediaItems=nil;R.GetMediaItem=nil;R.CountTakes=nil;R.GetTake=nil;R.CountTakeEnvelopes=nil;R.GetTakeEnvelope=nil
  model.override=-1
end)
test('closing while suspended restores envelope activity and global override',function()
  E.suspend();eq(mv.active,false);E.cleanup();eq(mv.active,true);eq(model.override,-1);eq(E.suspended_override,nil)
end)
test('Suspend uses a precise ACT fallback when the ACTIVE API attribute is unavailable',function()
  local original=R.GetSetEnvelopeInfo_String
  R.GetSetEnvelopeInfo_String=function(env,key,value,set) if key=='ACTIVE' then return false,'' end;return original(env,key,value,set) end
  local points=#mv.points;E.suspend();eq(mv.active,false);E.suspend();eq(mv.active,true);eq(#mv.points,points)
  R.GetSetEnvelopeInfo_String=original
end)
test('selected-only Capture respects selection without changing panel scope and includes unarmed controls',function()
  select_only(manual);E.scope='all';mp.arm=false
  E.capture_values(true,true);eq(E.capture_selected,true);eq(E.scope,'all')
  local found=false
  for _,h in ipairs(E.capture) do eq(h.tr,manual,'Only selected source tracks captured');if h.env==mp then found=true end end
  eq(found,true,'Selected all-controls snapshot includes an unarmed pan envelope')
  manual.selected=false;E.capture_values(true,true);eq(E.capture,nil);eq(E.capture_selected,false)
  manual.selected=true;mp.arm=true
  E.scope='selected';E.capture_values(true);eq(E.capture_selected,false)
  local other=false;for _,h in ipairs(E.capture) do if h.tr==b then other=true end end;eq(other,true,'Alt/all capture spans the session')
  E.capture=nil
end)
test('successful Manual Write commits Preview values then exits Preview and restores per-track control',function()
  select_only(manual);E.scope='selected';E.capture=nil;E.preview=false;manual.mode=1;model.override=2;model.selection={2,8};model.cursor=5
  E.preview_toggle();eq(manual.mode,5);E.touched[mv.guid]=5
  local count=E.manual_write('all');eq(count>0,true);eq(E.preview,false);eq(manual.mode,1);eq(model.override,-1)
  near(select(2,R.Envelope_Evaluate(mv,3)),.7)
end)
test('a Manual Write without a range keeps uncommitted Preview values',function()
  E.preview_toggle();E.touched[mv.guid]=2;model.cursor=2;eq(E.manual_write('start'),0);eq(E.preview,true);E.preview_toggle();model.cursor=5
end)
local ab=track('PREVIEW A/B');ab.ui={D_VOL=.35,D_PAN=-.7,I_PANMODE=5}
local av=envelope(ab,'VOLENV2',{{t=0,v=2,s=0},{t=10,v=2,s=0}});av.scaling=1
local ap=envelope(ab,'PANENV2',{{t=0,v=0,s=0},{t=10,v=0,s=0}})
av.ui=2;ap.ui=2 -- Both controls were latched by the user before Preview A/B.
test('Preview A/B suspension reads existing automation without losing held values or writing points',function()
  select_only(ab);E.scope='selected';ab.mode=3;model.override=-1;model.cursor=5
  E.preview_toggle();E.preview_suspend()
  eq(E.preview,true);eq(type(E.preview_paused),'table');eq(ab.mode,1,'Auditioning cannot restore a writing mode')
  near(ab.ui.D_VOL,1,'Read fader-scaled original automation');near(ab.ui.D_PAN,0)
  eq(#av.points,2);eq(#ap.points,2);near(av.points[1].v,2)
  E.preview_suspend();eq(E.preview_paused,nil);eq(ab.mode,5);near(ab.ui.D_VOL,.35);near(ab.ui.D_PAN,-.7)
  E.preview_suspend();E.preview_toggle();eq(E.preview,false);eq(E.preview_paused,nil);eq(ab.mode,1);eq(model.override,-1)
  ab.mode=1
end)
test('Manual Write from suspended Preview commits held values and exits Preview',function()
  ab.ui.D_VOL=.42;ab.ui.D_PAN=.4;model.selection={2,8}
  E.preview_toggle();E.preview_suspend();E.punch_values();eq(E.punch,nil,'Paused Preview cannot punch accidentally')
  local count=E.manual_write('all');eq(count>0,true);eq(E.preview,false);eq(E.preview_paused,nil);eq(ab.mode,1)
  near(select(2,R.Envelope_Evaluate(av,3)),.84);near(select(2,R.Envelope_Evaluate(ap,3)),-.4)
end)
test('Preview A/B skips deleted envelopes and remains off when invoked outside Preview',function()
  E.preview_suspend();eq(E.preview,false);eq(E.preview_paused,nil)
  E.preview_toggle();E.preview_suspend();ap.deleted=true
  E.preview_suspend();eq(E.preview,true);eq(E.preview_paused,nil);ap.deleted=nil;E.preview_toggle()
end)
test('clearing latches while Preview is paused discards held values and cleanup restores modes',function()
  ab.mode=4;E.preview_toggle();E.preview_suspend();E.match();eq(#E.preview_paused.values,0)
  E.cleanup();eq(ab.mode,4);eq(E.preview,false);eq(E.preview_paused,nil);ab.mode=1
end)
local nt=track('NATIVE COMMIT');nt.ui={D_VOL=.98,D_PAN=.1};nt.sends={route(b)}
local nv=envelope(nt,'VOLENV2');nv.scaling=1;nv.native_latch=.42
local np=envelope(nt,'PANENV2');np.native_latch=.65
local ns=envelope(nt,'AUXPANENV');ns.send=0;ns.native_latch=-.37
local nf=envelope(nt,'PARMENV',nil,0,0);nf.native_latch=.81
nt.fx={{id='VST: ReaSurround (Cockos)',guid='NATIVE-RS',params={{name='X',value=.12}}}}
local outsider=envelope(b,'PANENV2');outsider.native_latch=.93
local function reset_native()
  select_only(nt);E.scope='selected';E.capture=nil;E.preview=false;E.preview_paused=nil
  E.use_items=false;E.touched={};E.firsttouch=nil;E.pass_start=nil
  E.enabled.pan=true;E.enabled.span=true;E.enabled.vol=true
  model.selection={2,8};model.loop={11,14};model.cursor=5;model.play=0;model.override=-1
  for _,e in ipairs({nv,np,ns,nf,outsider}) do
    e.points={{t=0,v=.2,s=0},{t=6,v=.2,s=0},{t=10,v=.2,s=0}}
    e.ais={};e.ui=2;e.arm=true;e.active=true;e.visible=true
  end
end
test('live native track volume pan send pan and ReaSurround commit INTERNAL latches, not UI trims',function()
  reset_native();nt.mode=1;E.preview_toggle();local calls=model.native_writes or 0
  eq(E.manual_write('all'),4)
  for _,e in ipairs({nv,np,ns,nf}) do
    for _,t in ipairs({2.01,3,5,7.99}) do near(select(2,R.Envelope_Evaluate(e,t)),e.native_latch,'Latched value throughout range') end
    near(select(2,R.Envelope_Evaluate(e,1)),.2);near(select(2,R.Envelope_Evaluate(e,9)),.2)
    eq(#e.ais,0);eq(#e.points,6,'Only boundary/return points and original outside points')
  end
  eq(model.native_writes,calls+1,'One native commit for a shared range')
  near(select(2,R.Envelope_Evaluate(outsider,4)),.2,'Unselected active track protected');eq(outsider.arm,true)
  eq(E.preview,false);eq(nt.mode,1);eq(model.override,-1)
  eq(model.selection[1],2);eq(model.selection[2],8);eq(model.loop[1],11);eq(model.loop[2],14)
  eq(nt.selected,true);eq(b.selected,false)
end)
test('all five native Manual Write ranges commit their complete interiors',function()
  local ranges={all={2,8},start={2,5},['end']={5,8},punch={3,5},next={5,6}}
  for _,which in ipairs({'all','start','end','punch','next'}) do
    reset_native();E.firsttouch=3
    eq(E.manual_write(which),4);local range=ranges[which]
    for _,e in ipairs({nv,np,ns,nf}) do
      near(select(2,R.Envelope_Evaluate(e,range[1]+.01)),e.native_latch,which..' start')
      near(select(2,R.Envelope_Evaluate(e,range[2]-.01)),e.native_latch,which..' end')
    end
    eq(model.selection[1],2);eq(model.selection[2],8)
  end
end)
test('native Manual Write protects disabled classes, unarmed envelopes and other tracks',function()
  reset_native();E.enabled.span=false;nf.arm=false
  eq(E.manual_write('all'),2)
  near(select(2,R.Envelope_Evaluate(ns,4)),.2);near(select(2,R.Envelope_Evaluate(nf,4)),.2)
  near(select(2,R.Envelope_Evaluate(outsider,4)),.2);eq(nf.arm,false);eq(ns.arm,true);eq(outsider.arm,true)
  E.enabled.span=true
end)
test('native punch and next ranges can differ per envelope without widening the write',function()
  reset_native();E.touched[nv.guid]=3;E.touched[np.guid]=4;E.firsttouch=2
  eq(E.manual_write('punch'),4)
  near(select(2,R.Envelope_Evaluate(nv,3.5)),nv.native_latch)
  near(select(2,R.Envelope_Evaluate(np,3.5)),.2);near(select(2,R.Envelope_Evaluate(np,4.5)),np.native_latch)
  reset_native();np.points[2].t=7
  eq(E.manual_write('next'),4)
  near(select(2,R.Envelope_Evaluate(nv,6.5)),.2);near(select(2,R.Envelope_Evaluate(np,6.5)),np.native_latch)
end)
test('native action failure restores arm states, selection, loop and Undo and keeps Preview',function()
  reset_native();E.preview_toggle();nf.arm=false;model.fail_native_write=true
  local ok,why=pcall(E.manual_write,'start');eq(ok,false);eq(why:find('Simulated host write failure')~=nil,true)
  eq(E.preview,true);eq(nv.arm,true);eq(nf.arm,false);eq(outsider.arm,true)
  eq(model.selection[1],2);eq(model.selection[2],8);eq(model.loop[1],11);eq(model.loop[2],14);eq(model.undos,0)
  model.fail_native_write=nil;E.preview_toggle()
end)
test('native whole-project write preserves an originally empty time selection',function()
  reset_native();model.selection={0,0};eq(E.manual_write('all'),4)
  near(select(2,R.Envelope_Evaluate(nv,15)),nv.native_latch)
  eq(model.selection[1],0);eq(model.selection[2],0);eq(model.loop[1],11);eq(model.loop[2],14)
end)
test('automation-item and captured writes retain their explicit point path',function()
  reset_native();E.use_items=true;local calls=model.native_writes or 0
  E.manual_write('all');eq(model.native_writes or 0,calls);eq(#nv.ais,1)
  reset_native();E.capture={{tr=nt,env=nv,d=E._test.descriptor(nt,nv),value=.17}}
  eq(E.manual_write('all'),1);eq(model.native_writes or 0,calls)
  near(select(2,R.Envelope_Evaluate(nv,4)),.17);E.capture=nil
  for _,e in ipairs({nv,np,ns,nf,outsider}) do e.ui=0 end
end)
test('Preview-exit write-buffer flush cannot replace the final Manual Write plateau',function()
  reset_native();nt.mode=1;E.preview_toggle();model.flush_track=nt;model.refuse_chunks=true
  eq(E.manual_write('all'),4);eq(model.flush_track,nil,'Exit mode transition actually flushed the pending host pass')
  for _,e in ipairs({nv,np,ns,nf}) do
    for _,t in ipairs({2.01,4,5.0002,7.99}) do near(select(2,R.Envelope_Evaluate(e,t)),e.native_latch) end
    eq(#e.points,6,'No duplicated provisional guard points')
    near(select(2,R.Envelope_Evaluate(e,1)),.2);near(select(2,R.Envelope_Evaluate(e,9)),.2)
  end
  eq(E.preview,false);eq(model.undos,0)
  model.refuse_chunks=nil;model.clock=model.clock+.1;eq(E.verify_manual_write(),true)
end)
test('a native cursor-only dip or no-op is replaced by the held UI snapshot across the selection',function()
  for _,kind in ipairs({'native_dip','native_noop'}) do
    reset_native();nt.mode=1;nt.ui.D_VOL=.21;nt.ui.D_PAN=-.65;nt.sends[1].D_PAN=.37;nt.fx[1].params[1].value=.81
    E.preview_toggle();model[kind]=true;eq(E.manual_write('all'),4);model[kind]=nil
    for _,e in ipairs({nv,np,ns,nf}) do
      near(select(2,R.Envelope_Evaluate(e,3)),e.native_latch)
      near(select(2,R.Envelope_Evaluate(e,7)),e.native_latch)
      eq(#e.points,6)
    end
    model.clock=model.clock+.1;eq(E.verify_manual_write(),true)
  end
end)
test('delayed host readback detects a curve overwritten after commit instead of reporting success',function()
  reset_native();nt.mode=1;E.preview_toggle();E.manual_write('all')
  nv.points={{t=0,v=.2,s=0},{t=5,v=.42,s=0},{t=5.0005,v=.2,s=0},{t=10,v=.2,s=0}}
  model.clock=model.clock+.1;eq(E.verify_manual_write(),false)
  eq(E.message:find('changed after commit')~=nil,true);eq(E.pending_write_check,nil)
end)
test('manual activation uses supported attributes without replacing the envelope state',function()
  reset_native();nv.active=false;nv.visible=false;nv.ui=0;np.ui=0;ns.ui=0;nf.ui=0;outsider.ui=0
  E.preview_toggle();for _,e in ipairs({nv,np,ns,nf}) do E.touched[e.guid]=5 end
  model.refuse_chunks=true;eq(E.manual_write('all'),4);model.refuse_chunks=nil
  eq(nv.active,true);eq(nv.visible,false);eq(E.preview,false)
end)
test('optional automation-item writes also finish Preview before installing the held curve',function()
  reset_native();nt.mode=1;E.preview_toggle();E.use_items=true;model.flush_track=nt
  eq(E.manual_write('all'),4);eq(E.preview,false);eq(model.flush_track,nil)
  near(select(2,R.Envelope_Evaluate(nv,3)),nt.ui.D_VOL*2);eq(#nv.ais,1)
  model.clock=model.clock+.1;eq(E.verify_manual_write(),true);E.use_items=false
  for _,e in ipairs({nv,np,ns,nf,outsider}) do e.ui=0 end
end)
local viewtrack=track('UNTOUCHED VOLUME PAN')
local uv=envelope(viewtrack,'VOLENV2');local up=envelope(viewtrack,'PANENV2')
local masterview=envelope(model.master,'MASTERPANENV2')
local function hide_views()
  nv.visible=false;nv.lane=false;np.visible=false;np.lane=true
  ns.visible=true;ns.lane=false;nf.visible=true;nf.lane=true
  uv.visible=false;uv.lane=true;up.visible=false;up.lane=false;uv.active=false
  masterview.visible=false;masterview.lane=false;outsider.visible=false
end
local function check_views()
  for _,e in ipairs({nv,np,uv,up,masterview,outsider}) do eq(e.visible,false,'Hidden native lane stays hidden') end
  eq(ns.visible,true);eq(nf.visible,true);eq(nv.lane,false);eq(np.lane,true)
  eq(ns.lane,false,'Visible inline envelope stays inline');eq(nf.lane,true)
  eq(uv.lane,true);eq(up.lane,false);eq(masterview.lane,false);eq(uv.active,false,'Unrelated bypass retained')
end
test('All Tracks Manual Write preserves hidden volume pan and master lanes despite native reveal side effects',function()
  reset_native();hide_views();E.scope='all';E.preview_toggle();model.native_reveal=true
  eq(E.manual_write('all'),5);model.native_reveal=nil
  check_views();near(select(2,R.Envelope_Evaluate(nv,4)),nv.native_latch)
  near(select(2,R.Envelope_Evaluate(np,4)),np.native_latch)
  model.clock=model.clock+.1;eq(E.verify_manual_write(),true);check_views()
end)
test('Capture and write-on-stop preserve hidden target and unrelated volume pan lanes',function()
  reset_native();hide_views();E.capture={{tr=nt,env=nv,d=E._test.descriptor(nt,nv),value=.17}}
  eq(E.manual_write('all'),1);check_views();near(select(2,R.Envelope_Evaluate(nv,4)),.17)
  E.capture=nil
  eq(E.write('all',{{tr=nt,env=np,d=E._test.descriptor(nt,np),value=.33}}),1)
  check_views();near(select(2,R.Envelope_Evaluate(np,4)),.33)
end)
test('failed native write restores every lane view within the balanced Undo block',function()
  reset_native();hide_views();E.preview_toggle();model.native_reveal=true;model.fail_native_write=true
  eq(pcall(E.manual_write,'all'),false);model.native_reveal=nil;model.fail_native_write=nil
  check_views();eq(model.undos,0);eq(E.preview,true);E.preview_toggle()
end)
test('host update readback restores deferred lane exposure without changing the written plateau',function()
  reset_native();hide_views();E.preview_toggle();E.manual_write('all')
  for _,e in ipairs({nv,np,uv,up,masterview}) do e.visible=true;e.lane=true end
  model.clock=model.clock+.1;eq(E.verify_manual_write(),true);check_views()
  near(select(2,R.Envelope_Evaluate(nv,4)),nv.native_latch)
end)
test('Preview with no latched controls never falls back to flattening every armed envelope',function()
  reset_native();hide_views();E.scope='all'
  for _,tr in ipairs({model.master,table.unpack(model.tracks)}) do for _,e in ipairs(tr.envs) do e.ui=0 end end
  E.preview_toggle();local before={};local calls=model.native_writes or 0
  for _,tr in ipairs({model.master,table.unpack(model.tracks)}) do for _,e in ipairs(tr.envs) do before[e]=envchunk(e) end end
  eq(E.manual_write('all'),nil);eq(model.native_writes or 0,calls);eq(E.preview,true)
  for e,chunk in pairs(before) do eq(envchunk(e),chunk,'No curve or lane view changed') end
  check_views();eq(E.message,'No latched Preview values to write');E.preview_toggle()
end)
test('All Tracks Preview writes only the latched volume instead of unrelated armed pan envelopes',function()
  reset_native();hide_views();E.scope='all'
  for _,tr in ipairs({model.master,table.unpack(model.tracks)}) do for _,e in ipairs(tr.envs) do e.ui=0 end end
  nv.ui=2;E.preview_toggle();local before={}
  for _,e in ipairs({np,ns,nf,uv,up,masterview,outsider}) do before[e]=envchunk(e) end
  eq(E.manual_write('all'),1);near(select(2,R.Envelope_Evaluate(nv,4)),nv.native_latch)
  for e,chunk in pairs(before) do eq(envchunk(e),chunk,'Unlatched curve and lane unchanged') end
  check_views()
end)
test('visibility API fallback updates current VIS fields and retains newly written points',function()
  reset_native();hide_views();E.preview_toggle();model.native_reveal=true
  local original=R.GetSetEnvelopeInfo_String
  R.GetSetEnvelopeInfo_String=function(e,key,value,set) if key=='VISIBLE' or key=='SHOWLANE' then return false,'' end;return original(e,key,value,set) end
  eq(E.manual_write('all'),4);R.GetSetEnvelopeInfo_String=original;model.native_reveal=nil
  check_views();near(select(2,R.Envelope_Evaluate(nv,4)),nv.native_latch)
  for _,e in ipairs({nv,np,ns,nf,outsider}) do e.ui=0 end
end)
test('entering All Tracks Preview preserves volume pan views across native mode changes',function()
  reset_native();hide_views();E.scope='all';model.mode_reveal=true
  E.preview_toggle();model.mode_reveal=nil;check_views()
  for _,e in ipairs({nv,np,uv,up,masterview}) do e.visible=true;e.lane=true end
  model.clock=model.clock+.1;E.verify_manual_write();check_views();E.preview_toggle()
end)
test('native volume envelopes auto-created on Preview entry are kept hidden',function()
  reset_native();hide_views();nt.mode=1;model.mode_create_track=nt
  E.preview_toggle();model.mode_create_track=nil
  local e=model.created_envelope;eq(e.visible,false);eq(e.active,true);eq(e.arm,true)
  e.visible=true;model.clock=model.clock+.1;E.verify_manual_write();eq(e.visible,false)
  E.preview_toggle();e.deleted=true;table.remove(nt.envs,#nt.envs);model.created_envelope=nil
  for _,env in ipairs({nv,np,ns,nf,outsider}) do env.ui=0 end
end)
test('empty Preview A/B holds no unrelated armed controls and preserves lane views',function()
  reset_native();hide_views();E.scope='all'
  for _,tr in ipairs({model.master,table.unpack(model.tracks)}) do for _,env in ipairs(tr.envs) do env.ui=0 end end
  E.preview_toggle();model.mode_reveal=true;E.preview_suspend();E.preview_suspend();model.mode_reveal=nil
  check_views();E.preview_suspend();eq(#E.preview_paused.values,0)
  eq(E.manual_write('all'),nil);eq(E.preview,true);check_views();E.preview_toggle()
end)
test('a subsequent Manual Write after Preview ends cannot target unrelated armed envelopes',function()
  reset_native();hide_views();E.scope='all';E.preview=false;E.capture=nil;E.touched={}
  for _,tr in ipairs({model.master,table.unpack(model.tracks)}) do for _,env in ipairs(tr.envs) do env.ui=0 end end
  local calls=model.native_writes or 0;local before={}
  for _,env in ipairs({nv,np,ns,nf,uv,up,masterview,outsider}) do before[env]=envchunk(env) end
  eq(E.manual_write('all'),nil);eq(E.message,'No latched or captured values to write');eq(model.native_writes or 0,calls)
  for env,text in pairs(before) do eq(envchunk(env),text,'No unrelated values or views were changed') end
  eq(model.undos,0)
end)
test('no-selection Manual Write prompts before any edit and Cancel preserves Preview and every curve',function()
  reset_native();hide_views();nt.mode=1;E.preview_toggle();model.selection={4,4};model.loop={11,14}
  local calls=model.native_writes or 0;local before={}
  for _,tr in ipairs({model.master,table.unpack(model.tracks)}) do for _,env in ipairs(tr.envs) do before[env]=envchunk(env) end end
  local capture=E.capture;local touched=E.touched
  model.dialog_answer=2
  model.dialog_hook=function(_,_,buttons)
    eq(buttons,1,'Native OK / Cancel choice');eq(E.preview,true);eq(model.undos,0)
    for env,text in pairs(before) do eq(envchunk(env),text,'Confirmation precedes every envelope edit') end
  end
  eq(E.manual_write('all'),0);model.dialog_hook=nil;model.dialog_answer=nil
  eq(model.native_writes or 0,calls);eq(E.preview,true);eq(nt.mode,5);eq(E.capture,capture);eq(E.touched,touched)
  eq(model.selection[1],4);eq(model.selection[2],4);eq(model.loop[1],11);eq(model.loop[2],14);eq(model.undos,0)
  for env,text in pairs(before) do eq(envchunk(env),text,'Cancel retains the original curve and view') end
  eq(model.last_dialog.title,'Automation: No time selection')
  eq(model.last_dialog.text:find('entire session',1,true)~=nil,true)
  eq(model.last_dialog.text:find('Selected tracks',1,true)~=nil,true)
  check_views();E.preview_toggle()
end)
test('OK confirms the complete session write while retaining an empty selection and loop bounds',function()
  reset_native();hide_views();nt.mode=1;E.preview_toggle();model.selection={0,0};model.dialog_answer=1
  local count=#model.dialogs;eq(E.manual_write('all'),4);model.dialog_answer=nil
  eq(#model.dialogs,count+1);eq(E.preview,false)
  for _,env in ipairs({nv,np,ns,nf}) do
    near(select(2,R.Envelope_Evaluate(env,.01)),env.native_latch)
    near(select(2,R.Envelope_Evaluate(env,19.99)),env.native_latch)
  end
  eq(model.selection[1],0);eq(model.selection[2],0);eq(model.loop[1],11);eq(model.loop[2],14);check_views()
end)
test('a time selection writes directly without a whole-session confirmation',function()
  reset_native();E.preview_toggle();local dialogs=#model.dialogs;model.dialog_answer=2
  eq(E.manual_write('all'),4);eq(#model.dialogs,dialogs);eq(E.preview,false)
  near(select(2,R.Envelope_Evaluate(nv,4)),nv.native_latch);model.dialog_answer=nil
end)
test('captured and paused Preview values are retained when the whole-session warning is cancelled',function()
  reset_native();E.capture={{tr=nt,env=nv,d=E._test.descriptor(nt,nv),value=.17}};model.selection={0,0}
  local captured=E.capture;model.dialog_answer=2;eq(E.manual_write('all'),0);eq(E.capture,captured);eq(E.preview,false)
  E.capture=nil;nt.mode=1;E.preview_toggle();E.preview_suspend();local paused=E.preview_paused
  eq(E.manual_write('all'),0);eq(E.preview,true);eq(E.preview_paused,paused);eq(model.undos,0)
  model.dialog_answer=nil;E.preview_toggle()
end)
test('whole-session warning covers optional automation items and treats any non-OK result as Cancel',function()
  for _,answer in ipairs({0,2,7}) do
    reset_native();E.preview_toggle();E.use_items=true;model.selection={0,0};model.dialog_answer=answer
    eq(E.manual_write('all'),0);eq(#nv.ais,0);eq(E.preview,true);eq(model.undos,0)
    model.dialog_answer=nil;E.preview_toggle()
  end
  E.use_items=false
end)
test('other Manual Write ranges and explicit write-on-stop values do not open the whole-session dialog',function()
  reset_native();model.selection={0,0};model.cursor=5;local dialogs=#model.dialogs;model.dialog_answer=2
  eq(E.manual_write('start'),4);eq(#model.dialogs,dialogs)
  eq(E.write('all',{{tr=nt,env=nv,d=E._test.descriptor(nt,nv),value=.19}}),1)
  eq(#model.dialogs,dialogs);near(select(2,R.Envelope_Evaluate(nv,15)),.19)
  model.dialog_answer=nil
end)

-- Send-slot copy uses actual normal-send indices, excluding hardware and later sends.
local slotSource=track('SEND COPY SOURCE');slotSource.sends={};slotSource.hws={route(bus2)}
local slotBuses={}
for index=1,12 do
  slotBuses[index]=track('SEND COPY BUS '..index)
  slotSource.sends[index]=route(slotBuses[index])
  for _,tag in ipairs({'AUXVOLENV','AUXPANENV','AUXMUTEENV'}) do
    local e=envelope(slotSource,tag,{{t=0,v=index/20,s=1},{t=4,v=index/20,s=1}});e.send=index-1
  end
end
envelope(slotSource,'VOLENV2');envelope(slotSource,'PANENV2')
local slotHardware=envelope(slotSource,'HWVOLENV');slotHardware.send=0;slotHardware.cat=1
test('send-slot copy includes all three parameters and excludes hardware track and other sends',function()
  select_only(slotSource);model.selection={0,4};E.copy('sends',1)
  eq(#E.clipboard.tracks,1);eq(#E.clipboard.tracks[1].envs,3)
  for _,item in ipairs(E.clipboard.tracks[1].envs) do eq(item.d.kind,'send');eq(item.d.cat,0);eq(item.d.send,0) end
end)
test('each send slot 1 through 10 copies only its volume pan and mute even when Write Enable is disabled',function()
  E.enabled.svol=false;E.enabled.span=false;E.enabled.smute=false
  for slot=1,10 do
    select_only(slotSource);model.selection={0,4};E.copy('sends',slot)
    eq(#E.clipboard.tracks[1].envs,3)
    for _,item in ipairs(E.clipboard.tracks[1].envs) do eq(item.d.send,slot-1);near(item.points[1].v,slot/20) end
  end
  E.enabled.svol=true;E.enabled.span=true;E.enabled.smute=true
end)
test('send ten copies paste using matching existing bus before slot fallback without creating routes',function()
  local destination=track('SEND COPY DESTINATION');destination.sends={route(slotBuses[10]),route(bus2)}
  select_only(slotSource);model.selection={0,4};E.copy('sends',10)
  local dialogs=#model.dialogs;select_only(destination);model.selection={10,18};E.use_items=false;E.paste('fit')
  eq(#destination.sends,2);eq(destination.sends[1].P_DESTTRACK,slotBuses[10]);eq(#model.dialogs,dialogs)
  for _,tag in ipairs({'VOLENV','PANENV','MUTEENV'}) do
    local e=R.GetTrackSendInfo_Value(destination,0,0,'P_ENV:<'..tag);eq(e~=nil,true);near(select(2,R.Envelope_Evaluate(e,14)),.5)
  end
  eq(R.GetTrackSendInfo_Value(destination,0,1,'P_ENV:<VOLENV'),nil)
end)
test('an empty send slot clears stale clipboard and never adds source sends or envelopes',function()
  local source=track('EMPTY SEND SLOT');source.sends={route(bus1)};envelope(source,'VOLENV2')
  select_only(source);E.copy('sends',10);eq(E.clipboard,nil);eq(#source.sends,1);eq(#source.envs,1)
end)
test('invalid direct send slots cannot change an existing clipboard',function()
  E.clipboard={duration=1,tracks={}};local prior=E.clipboard
  for _,slot in ipairs({0,11,-1,1.5}) do E.copy('sends',slot);eq(E.clipboard,prior) end
end)


test('Preview button forces every track and master to follow it regardless of selected-track scope',function()
  select_only(manual);E.scope='selected';E.preview=false;E.preview_paused=nil;model.override=4
  for i,tr in ipairs(model.tracks) do tr.mode=(i-1)%6 end
  model.master.mode=5
  E.preview_toggle();eq(E.preview,true);eq(E.scope,'selected');eq(model.override,-1)
  eq(model.master.mode,5)
  for _,tr in ipairs(model.tracks) do eq(tr.mode,5,'Every track follows Preview on') end
  E.preview_toggle();eq(E.preview,false);eq(model.override,-1);eq(model.master.mode,1)
  for _,tr in ipairs(model.tracks) do eq(tr.mode,1,'Every track follows Preview off instead of restoring Latch/Write') end
  eq(E.preview_modes,nil)
end)
test('turning off paused Preview forces all tracks Read even if external modes were changed',function()
  E.preview_toggle();E.preview_suspend();eq(E.preview,true)
  for _,tr in ipairs(model.tracks) do eq(tr.mode,1) end
  b.mode=5;model.master.mode=4;model.override=3
  E.preview_toggle();eq(b.mode,1);eq(model.master.mode,1);eq(model.override,-1);eq(E.preview_paused,nil)
end)
test('tracks added during Preview join Latch Preview and turn Read with the button',function()
  E.preview_toggle();local added=track('ADDED WHILE PREVIEW ON');added.mode=2;E.poll()
  eq(added.mode,5);eq(E.preview_modes.tracks[added],2)
  E.preview_toggle();eq(added.mode,1)
end)
test('tracks added during paused Preview are Read until Preview resumes',function()
  E.preview_toggle();E.preview_suspend();local added=track('ADDED DURING PREVIEW AB');added.mode=4;E.poll()
  eq(added.mode,1);eq(E.preview_modes.tracks[added],4)
  E.preview_suspend();eq(added.mode,5);eq(model.master.mode,5)
  E.preview_toggle();eq(added.mode,1);eq(model.master.mode,1)
end)
test('all-track Preview A/B holds unselected latched values while Manual Write still respects selected scope',function()
  local selectedTrack=track('PREVIEW SCOPE SELECTED');local unselectedTrack=track('PREVIEW SCOPE UNSELECTED')
  local se=envelope(selectedTrack,'VOLENV2',{{t=0,v=.2,s=0},{t=10,v=.2,s=0}})
  local ue=envelope(unselectedTrack,'VOLENV2',{{t=0,v=.3,s=0},{t=10,v=.3,s=0}})
  se.ui=2;ue.ui=2;selectedTrack.ui={D_VOL=.6};unselectedTrack.ui={D_VOL=.8}
  select_only(selectedTrack);E.scope='selected';E.capture=nil;model.selection={2,8}
  E.preview_toggle();E.preview_suspend()
  local found=false;for _,h in ipairs(E.preview_paused.values) do if h.env==ue then found=true end end
  eq(found,true,'A/B saves all previewed tracks, not only write scope')
  E.preview_suspend();near(unselectedTrack.ui.D_VOL,.8,'Unselected held value is restored')
  E.preview_suspend();eq(E.manual_write('all'),1)
  eq(E.preview,false);eq(selectedTrack.mode,1);eq(unselectedTrack.mode,1)
  near(select(2,R.Envelope_Evaluate(se,4)),.6);near(select(2,R.Envelope_Evaluate(ue,4)),.3,'Unselected automation is not written')
end)
test('cleanup still restores original modes when the panel closes while Preview remains active',function()
  select_only(manual);E.scope='selected';manual.mode=2;b.mode=4;model.master.mode=3;model.override=2
  E.preview_toggle();local added=track('PREVIEW CLEANUP NEW TRACK');added.mode=0;E.poll();eq(added.mode,5)
  E.cleanup();eq(manual.mode,2);eq(b.mode,4);eq(model.master.mode,3);eq(added.mode,0);eq(model.override,2)
  for _,tr in ipairs(model.tracks) do tr.mode=1 end;model.master.mode=1;model.override=-1
end)


test('Write Enable never changes automatic envelope preference in either initial state',function()
  E.cleanup();select_only(manual);E.scope='selected';E.enabled.vol=true
  for _,preference in ipairs({0,1,6,7,37}) do
    model.autoadd=preference;local writes=model.autoadd_writes or 0
    E.toggle_group('vol');eq(mv.arm,false)
    for _=1,4 do E.enforce() end
    eq(model.autoadd,preference);eq(model.autoadd_writes or 0,writes)
    E.toggle_group('vol');eq(mv.arm,true);eq(model.autoadd,preference)
  end
  model.autoadd=7
end)
test('user changes to automatic-envelope preference survive repeated protection passes and cleanup',function()
  E.enabled.vol=true;model.autoadd=7;E.toggle_group('vol');model.autoadd=14
  for _=1,4 do E.enforce() end
  eq(model.autoadd,14);E.cleanup();eq(model.autoadd,14);eq(mv.arm,true)
  E.enabled.vol=true;E.enforce();eq(model.autoadd,14);model.autoadd=7
end)
test('Suspend preserves user automatic-envelope changes while continuing to bypass envelopes',function()
  model.autoadd=7;local writes=model.autoadd_writes or 0;E.suspend();eq(mv.active,false)
  eq(model.autoadd,7);model.autoadd=6;E.enforce();eq(model.autoadd,6)
  E.suspend();eq(model.autoadd,6);eq(model.autoadd_writes or 0,writes)
  model.autoadd=7
end)
test('new protected envelopes are disarmed without disabling automatic envelope creation globally',function()
  local source=track('AUTO-ADD PREFERENCE');select_only(source);E.scope='selected';E.enabled.vol=false;model.autoadd=7
  E.enforce();local added=envelope(source,'VOLENV2');local points=#added.points
  E.enforce();eq(added.arm,false);eq(#added.points,points);eq(model.autoadd,7)
  E.cleanup();eq(added.arm,true);eq(model.autoadd,7);E.enabled.vol=true
end)
test('write protection works without SWS preference APIs',function()
  local getter,setter=R.SNM_GetIntConfigVar,R.SNM_SetIntConfigVar
  R.SNM_GetIntConfigVar=nil;R.SNM_SetIntConfigVar=nil
  select_only(manual);E.enabled.vol=true;E.toggle_group('vol');eq(mv.arm,false)
  E.cleanup();eq(mv.arm,true);eq(model.autoadd,7);E.enabled.vol=true
  R.SNM_GetIntConfigVar=getter;R.SNM_SetIntConfigVar=setter
end)
test('the complete engine scenario suite has never written a global preference',function()
  eq(model.autoadd_writes or 0,0)
end)

print(('RESULT: %d engine tests, %d assertions passed'):format(tests,assertions))
-- Exercise the production headless command loop rather than its test-only entry.
EA_AUTOMATION_TEST=nil
local pending,exit_handler,native_connected,published
local commands={'preview','preview_suspend','preview_suspend','group:plugin','write:all','copy:pan','paste:fit','capture_selected','items','scope_toggle','scope_toggle'}
function R.APIExists(name) return type(R[name])=='function' end
function R.GetExtState(section,key) return (model.ext or {})[section..key] or '' end
function R.DeleteExtState(section,key) model.ext[section..key]=nil end
function R.defer(fn) pending=fn end
function R.atexit(fn) exit_handler=fn end
function R.EA_Native_Connect(active) native_connected=active end
function R.EA_Native_NextCommand()
  local next=table.remove(commands,1) or ''
  if next=='write:all' then manual.envs[1].ui=2 end -- Human latched the volume control before pressing Write.
  return next
end
function R.EA_Native_Publish(packet) published={};for key,value in packet:gmatch('([^=\n]+)=([^\n]*)') do published[key]=value end end
select_only(manual);model.selection={2,8};model.play=0;manual.mode=1.0
R.SetExtState('EA_Compact_Automation','scope','selected')
R.SetExtState('EA_Compact_Automation','use_items','0')
dofile(arg[1] or 'runtime/EA_Native_Automation/engine.lua')
eq(native_connected,true,'Production engine connects to native interface');eq(type(pending),'function')
pending()
eq(published.version,'2.2.15','Running engine version is published for the right-click menu')
eq(published.preview,'0','Manual write exits Preview');eq(published.enabled_plugin,'0','Native protection state')
eq(published.capture_selected,'1','Native selected-only Capture blink state')
eq(published.items,'1','Native settings state');eq(published.scope,'selected','Native scope state')
eq(R.GetExtState('EA_Compact_Automation','scope'),'selected','Shortcut scope changes persist')
eq(published.mode,'1','Scoped automation mode is published for action radio states')
commands={'copy:send:1'};pending();eq(published.message:match('Copied (%d+) envelopes'),'2','Native send-slot command copies volume and pan')
local copiedMessage=published.message
commands={'copy:send:0','copy:send:11','copy:send:1.5','copy:sends'};pending();eq(published.message,copiedMessage,'Invalid and unrequested combined commands are ignored')
commands={'copy:send:10'};pending();eq(published.message,'No automation on send slot 10')
commands={'paste:fit'};pending();eq(published.message,'Copy automation first','Empty slot cannot reuse an earlier clipboard')
commands={'preview'};pending();eq(published.preview,'1');eq(model.master.mode,5)
for _,tr in ipairs(model.tracks) do eq(tr.mode,5,'Native Preview action enables every track') end
commands={'preview'};pending();eq(published.preview,'0');eq(model.master.mode,1);eq(model.override,-1)
for _,tr in ipairs(model.tracks) do eq(tr.mode,1,'Native Preview action disables every track') end
commands={'close'};pending();eq(native_connected,false,'Close disconnects native UI');eq(manual.mode,1,'Close restores preview mode')
eq(R.GetExtState('EA_Compact_Automation','native_engine_running'),'','Close clears running state')
exit_handler();eq(native_connected,false,'Cleanup is idempotent');eq(model.undos,0,'Headless edits balance Undo')
eq(model.autoadd_writes or 0,0,'Production commands and closing do not change global preferences')
print('PASS: production native command loop, state publication, close and restoration')
