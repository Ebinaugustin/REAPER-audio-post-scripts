#include "ActionCatalog.h"
#include "PanelModel.h"
#include <iostream>
#include <set>
#include <stdexcept>
static void check(bool value,const char* message) {if(!value) throw std::runtime_error(message);}
int main(int argc,char**) {
    try {
        std::set<std::string> ids,titles,commands,menus;
        for(const auto& action:ea::actionCatalog()) {
            check(action.id.rfind("EA_NATIVE_AUTOMATION_",0)==0,"Stable action ID prefix");
            check(action.title.rfind("EA: Automation - ",0)==0,"Discoverable action title");
            check(ids.insert(action.id).second,"Duplicate action ID");
            check(titles.insert(action.title).second,"Duplicate action title");
            if(action.kind==ea::ActionKind::Engine) {check(!action.command.empty(),"Engine action must carry a command");commands.insert(action.command);}
            if(action.kind==ea::ActionKind::Menu) menus.insert(action.command);
            if(argc>1) std::cout<<"| `_"<<action.id<<"` | "<<action.title<<" |\n";
        }
        for(const auto& control:ea::makeLayout(false).controls)
            check(commands.count(ea::commandFor(control.id))||menus.count(control.id),"Every panel control must have a shortcut action");
        for(const auto* range:{"start","all","end","punch","next"}) {
            check(commands.count(std::string("write:")+range)!=0,"Missing manual-write action");
            check(commands.count(std::string("onstop:")+range)!=0,"Missing Write-on-Stop action");
        }
        for(const auto* cmd:{"preview_suspend","capture_selected","capture_all","copy:enabled","paste:cursor","paste:fit","paste:fill","scope_toggle"})
            check(commands.count(cmd)!=0,"Missing menu/modifier shortcut action");
        check(ids.size()==104,"Expected existing 98 actions plus six section visibility commands");
        for(const auto& section:ea::sectionDefinitions()) check(ids.count("EA_NATIVE_AUTOMATION_SHOW_"+std::string(section.id))==1,"Missing visibility shortcut");
        check(ids.count("EA_NATIVE_AUTOMATION_SHOW_ALL_SECTIONS")==1,"Missing Show All shortcut");
        check(commands.count("copy:sends")==0,"No combined copy command requested");
        for(int slot=1;slot<=10;++slot)
            check(commands.count("copy:send:"+std::to_string(slot))!=0,"Missing individual send copy action");
        if(argc==1) std::cout<<"PASS: "<<ids.size()<<" unique stable actions cover every panel control, modifier and settings operation\n";
        return 0;
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
