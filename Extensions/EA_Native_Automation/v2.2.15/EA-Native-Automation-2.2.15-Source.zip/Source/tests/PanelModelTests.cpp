#include "PanelModel.h"
#include <iostream>
#include <stdexcept>
#include <set>
static void check(bool ok,const std::string& why) {if(!ok) throw std::runtime_error(why);}
int main() {
    try {
        for(auto mode:{0,1,2,3,4}) {
            const auto layout=mode<3?ea::makeLayout(mode>0,mode==2):ea::makeSingleLineLayout(mode==3);
            check(layout.controls.size()==30,"Every control is present");
            std::set<std::string> ids;
            for(size_t i=0;i<layout.controls.size();++i) {
                const auto& c=layout.controls[i];const auto r=c.bounds;
                check(ids.insert(c.id).second,"No duplicate control IDs");
                check(r.x>=0&&r.y>=0&&r.w>0&&r.h>0&&r.x+r.w<=layout.width&&r.y+r.h<=layout.height,"Control lies within layout: "+c.id);
                for(size_t j=0;j<i;++j) {
                    const auto q=layout.controls[j].bounds;
                    check(r.x>=q.x+q.w||q.x>=r.x+r.w||r.y>=q.y+q.h||q.y>=r.y+r.h,"No overlap: "+c.id+" and "+layout.controls[j].id);
                }
            }
            for(auto suffix:{"start","all","end","punch","next"}) {
                check(ids.count(std::string("manual_")+suffix)==1,"Manual icon exists");
                check(ids.count(std::string("stop_")+suffix)==1,"Stop icon exists");
            }
        }
        check(ea::commandFor("manual_all")=="write:all","Manual mapping");
        check(ea::commandFor("stop_next")=="onstop:next","Stop mapping");
        check(ea::commandFor("pan")=="group:pan","PAN mapping");
        check(ea::commandFor("paste_fill")=="paste:fill","Fill mapping");
        const auto vertical=ea::makeLayout(false);
        check(vertical.width==220&&vertical.height==730,"Readable 100% floating dimensions");
        for(const auto& c:vertical.controls)
            if(c.id.rfind("manual_",0)==0||c.id.rfind("stop_",0)==0)
                check(c.bounds.w>=59&&c.bounds.h>=32,"Readable write icon targets");
        check(ea::displayUiScale(50,1080)==.5f&&ea::displayUiScale(75,1080)==.75f&&ea::displayUiScale(200,1080)==2,"Explicit size presets");
        check(ea::displayUiScale(0,480)==.85f&&ea::displayUiScale(0,2160)==1.75f,"Automatic scale limits preserve readability");
        for(bool horizontal:{false,true}) {
            const auto strip=ea::makeSingleLineLayout(horizontal);
            check(strip.singleLine&&strip.headings.empty(),"Thin strips use no stacked section headings");
            for(size_t i=0;i<strip.controls.size();++i) {
                const auto& c=strip.controls[i];const auto& original=vertical.controls[i];
                check(c.id==original.id&&c.icon==original.icon&&c.tooltip==original.tooltip,"Reflow retains control identity, icons and full tooltips");
                check(horizontal?c.bounds.y==3:c.bounds.x==3,"All controls lie on exactly one axis");
                check(c.bounds.h>=26&&c.bounds.w>=26,"Thin layout keeps usable logical hit targets");
            }
        }
        for(unsigned mask=0;mask<=ea::AllSections;++mask) {
            for(int mode=0;mode<5;++mode) {
                const auto filtered=mode<3?ea::applySectionVisibility(ea::makeLayout(mode>0,mode==2),mask):ea::makeSingleLineLayout(mode==3,mask);
                size_t expected=0;
                for(const auto& c:vertical.controls) if(!ea::controlSection(c.id)||(ea::controlSection(c.id)&mask)) ++expected;
                check(filtered.controls.size()==expected,"Visibility removes only its requested controls");
                for(size_t i=0;i<filtered.controls.size();++i) {
                    const auto& c=filtered.controls[i];const auto r=c.bounds;
                    check(!ea::controlSection(c.id)||(ea::controlSection(c.id)&mask),"Hidden control is absent from layout and hit targets");
                    check(r.x>=0&&r.y>=0&&r.w>0&&r.h>0&&r.x+r.w<=filtered.width+.01f&&r.y+r.h<=filtered.height+.01f,"Filtered control fits: "+c.id);
                    for(size_t j=0;j<i;++j) {
                        const auto q=filtered.controls[j].bounds;
                        check(r.x>=q.x+q.w-.01f||q.x>=r.x+r.w-.01f||r.y>=q.y+q.h-.01f||q.y>=r.y+r.h-.01f,"No filtered overlap: "+c.id);
                    }
                }
                if(mask!=ea::AllSections&&mode==0) check(filtered.height<vertical.height,"Hiding a floating section closes the vertical gap");
            }
        }
        auto visible=[](const ea::PanelView& view) {
            int count=0;
            for(const auto& c:view.layout.controls) {
                const auto r=c.bounds;
                if(r.x*view.scale>=0&&r.y*view.scale>=0&&(r.x+r.w)*view.scale<=view.viewport.w+.01f&&(r.y+r.h)*view.scale<=view.viewport.h+.01f) ++count;
            }
            return count;
        };
        for(float ui:{.5f,.75f,1.f,1.25f,1.5f,1.75f,2.f}) {
            for(unsigned mask=0;mask<=ea::AllSections;++mask) {
                for(int side:{0,1,2,3,4}) {
                    const bool horizontal=side==0||side==2||side==4;
                    const auto baseline=ea::makePanelView(side,horizontal?600.f:88.f,horizontal?40.f:300.f,ui,mask);
                    for(float size:{40.f,70.f,100.f,220.f,400.f,900.f}) {
                        const auto view=ea::makePanelView(side,horizontal?600.f:size,horizontal?size:300.f,ui,mask);
                        check(view.layout.dockFlow,"Docks always use fixed-size toolbar flow");
                        check(view.scale==ui&&view.offsetX==0&&view.offsetY==0,"Every dock preset is honored without resizing zoom or centering");
                        check(view.layout.controls.size()==baseline.layout.controls.size(),"Resizing does not lose hidden-overflow controls");
                        for(size_t i=0;i<view.layout.controls.size();++i) {
                            const auto& c=view.layout.controls[i];const auto r=c.bounds,q=baseline.layout.controls[i].bounds;
                            check(c.id==baseline.layout.controls[i].id,"Reflow retains every control identity");
                            if(view.layout.horizontal==baseline.layout.horizontal) check(r.w==q.w&&r.h==q.h,"Every button retains its exact dimensions while Docker size changes");
                            for(size_t j=0;j<i;++j) {
                                const auto t=view.layout.controls[j].bounds;
                                check(r.x>=t.x+t.w-.01f||t.x>=r.x+r.w-.01f||r.y>=t.y+t.h-.01f||t.y>=r.y+r.h-.01f,"Flow controls never overlap");
                            }
                        }
                    }
                }
            }
            check(ea::makePanelView(-1,220*ui,730*ui,ui).scale==ui,"Floating presets retain their exact requested size");
        }
        check(visible(ea::makePanelView(2,970,70,1))>visible(ea::makePanelView(2,970,40,1)),"Dragging top/bottom divider reveals another row without enlargement");
        check(visible(ea::makePanelView(1,180,600,1))>visible(ea::makePanelView(1,88,600,1)),"Dragging side divider reveals another column without enlargement");
        for(int side:{0,1,2,3}) {
            int previous=0;
            for(float size=100;size<=1900;size+=10) {
                const auto view=ea::makePanelView(side,side%2==0?size:88,side%2==0?40:size,1);
                const int count=visible(view);check(count>=previous,"Growing the viewport reveals controls progressively");previous=count;
            }
        }
        check(ea::makePanelView(2,970,40,1).layout.singleLine,"Thin horizontal dock remains a single row");
        check(ea::makePanelView(1,88,600,1).layout.singleLine,"Thin vertical dock remains a single column");
        check(ea::displayDockUiScale(0)==.75f,"Auto dock size is a compact 75%, independent of monitor height");
        for(int percent:{50,75,100,125,150,175,200}) {
            const float ui=percent/100.f;
            check(ea::displayDockUiScale(percent)==ui,"Every explicit dock size remains exact");
            const auto horizontal=ea::dockMinimumSize(2,ui,900,40),verticalMin=ea::dockMinimumSize(1,ui,88,600);
            check(horizontal.h==34*ui&&verticalMin.w==88*ui,"Native minimum hint follows the compact preset");
        }
        const auto compact=ea::makePanelView(2,970,20,.5f,0);
        check(compact.scale==.5f&&compact.layout.controls.front().bounds.h*compact.scale==14,"Reported 50% dock has 14-pixel button height rather than a forced 28");
        check(visible(compact)==8&&!compact.scrollable,"Reported eight-control row fits a 20-pixel content strip");
        for(float density:{1.f,1.25f,1.5f,1.75f,2.f}) {
            for(float ui:{.5f,.75f,1.f,1.25f,1.5f,2.f}) {
                const float font=ea::pixelAlignedFontHeight(12,ui,density);
                check(font>=10,"Small presets retain a legible font instead of six-pixel text");
                check(std::abs(font*density-std::round(font*density))<.001f,"Font height aligns with physical pixels at each display scale");
                const auto r=ea::pixelAlignedRect({3.25f,1.5f,37.75f,14.25f},density);
                for(float edge:{r.x,r.y,r.x+r.w,r.y+r.h}) check(std::abs(edge*density-std::round(edge*density))<.001f,"Every rendered button edge lies on a physical pixel");
            }
        }
        std::cout<<"PASS: fixed button dimensions across divider changes, progressive row/column reveal, all masks/presets and original action mapping\n";return 0;
    } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}
}
