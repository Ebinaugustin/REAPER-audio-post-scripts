#include "AutomationPanel.h"
#include "ReaperHost.h"
#include <cmath>
namespace ea {
static juce::Rectangle<float> rect(Rect r) {return {r.x,r.y,r.w,r.h};}
static juce::Font uiFont(const ReaperHost& host,float height,int style=juce::Font::plain) {
    return host.reaperFont(height,(style&juce::Font::bold)!=0);
}
AutomationPanel::AutomationPanel(ReaperHost& h):host(h),layout(makeLayout(false)),theme(host.setting("theme","reaper")),tooltips(this,650) {
    addChildComponent(stripScroll);stripScroll.setAutoHide(false);stripScroll.addListener(this);
    setOpaque(true);setWantsKeyboardFocus(false);setSize(220,730);startTimerHz(10);
}
AutomationPanel::Palette AutomationPanel::palette() const {
    using C=juce::Colour;
    C bg;
    if(theme=="silver") bg=C(0xffe4e7ec);
    else if(theme=="graphite") bg=C(0xff242a2e);
    else if(theme=="midnight") bg=C(0xff111b2b);
    else if(theme=="warm") bg=C(0xff302c28);
    else if(theme=="classic") bg=C(0xff45484a);
    else bg=host.themeBackground();
    const auto accent=host.themeAccent();
    const bool light=bg.getPerceivedBrightness()>.6f;
    return {bg,light?bg.darker(.13f):bg.brighter(.11f),light?C(0xff171b20):C(0xffeef2f4),accent,bg.darker(.5f)};
}
bool AutomationPanel::active(const std::string& id) const {
    if(id=="settings") return host.bridge.flag("items");
    if(id=="scope") return false;
    if(id=="suspend") return host.bridge.flag("suspended");
    if(id.rfind("stop_",0)==0) return host.bridge.flag("onstop_"+id.substr(5));
    for(const auto& group:{"plugin","vol","svol","pan","span","mute","smute"})
        if(id==group) return host.bridge.flag("enabled_"+id);
    return host.bridge.flag(id=="punch_capture"?"punch":id);
}
static std::string readableLabel(const std::string& id,const std::string& full,const juce::Font& font,float width) {
    const auto fits=[&](const std::string& text) {return juce::GlyphArrangement::getStringWidth(font,juce::String(text))<=width;};
    if(fits(full)) return full;
    if(id=="scope"&&full!="ALL TRACKS"&&full!="SELECTED TRACKS"&&full!="SELECTED") return full;
    // Keep full names in tooltips. Abbreviate before any horizontal font compression.
    const std::map<std::string,std::vector<std::string>> names={
        {"suspend",{"SUSP","SUS"}},{"plugin",{"PLUG","FX"}},{"vol",{"VOL","V"}},{"svol",{"S VOL","SV"}},
        {"pan",{"PAN","P"}},{"span",{"S PAN","SP"}},{"mute",{"MUTE","MT"}},{"smute",{"S MUTE","SM"}},
        {"join",{"JOIN"}},{"match",{"MATCH","MTCH"}},{"capture",{"CAPT","CAP"}},
        {"copy_all",{"COPY","CPY"}},{"copy_pan",{"C PAN","PAN"}},{"paste_fill",{"FILL SEL","FILL"}},
        {"scope",{full=="SELECTED TRACKS"||full=="SELECTED"?"SELECTED":"ALL TRACKS",full=="SELECTED TRACKS"||full=="SELECTED"?"SEL":"ALL"}}
    };
    if(id=="preview") {
        for(const auto& text:full=="PREVIEW PAUSED"?std::vector<std::string>{"Paused","PAUSE"}:std::vector<std::string>{"Preview","PREV"}) if(fits(text)) return text;
    }
    const auto found=names.find(id);
    if(found!=names.end()) for(const auto& text:found->second) if(fits(text)) return text;
    return full; // drawText may truncate, but never shrinks or squashes the font.
}
static void drawPixelText(juce::Graphics& g,const juce::String& text,const juce::Font& font,juce::Rectangle<float> area,float pixels,bool centred=true) {
    const auto align=[&](float v) {return std::round(v*pixels)/pixels;};
    const float width=juce::GlyphArrangement::getStringWidth(font,text);
    const float x=align(area.getX()+(centred?std::max(0.f,(area.getWidth()-width)*.5f):0));
    const float baseline=align(area.getCentreY()+(font.getAscent()-font.getDescent())*.5f);
    juce::GlyphArrangement glyphs;
    glyphs.addCurtailedLineOfText(font,text,x,baseline,area.getWidth(),false);
    glyphs.draw(g);
}
void AutomationPanel::paint(juce::Graphics& g) {
    const auto p=palette();g.fillAll(p.bg);g.reduceClipRegion(contentArea.toNearestInt());
    const float pixels=std::max(.5f,g.getInternalContext().getPhysicalPixelScaleFactor());
    const auto snap=[&](juce::Rectangle<float> r) {return rect(pixelAlignedRect({r.getX(),r.getY(),r.getWidth(),r.getHeight()},pixels));};
    const auto screen=[&](Rect r) {return snap({r.x*scale+offsetX-scrollX*scale,r.y*scale+offsetY-scrollY*scale,r.w*scale,r.h*scale});};
    // Draw directly at the final display size: no UI-scale transform around glyphs.
    for(const auto& heading:layout.headings) {
        auto r=screen(heading.bounds);g.setColour(p.text.withAlpha(.75f));
        g.setFont(uiFont(host,pixelAlignedFontHeight(11.8f,scale,pixels,9.f)));
        drawPixelText(g,heading.text,g.getCurrentFont(),r,pixels,false);
        const float headingWidth=juce::GlyphArrangement::getStringWidth(g.getCurrentFont(),heading.text);
        const float textWidth=headingWidth+8*scale;
        g.setColour(p.text.withAlpha(.17f));
        if(r.getX()+textWidth<r.getRight()) g.drawLine(r.getX()+textWidth,r.getCentreY(),r.getRight(),r.getCentreY(),1.f/pixels);
    }
    for(const auto& control:layout.controls) {
        const auto r=screen(control.bounds);const bool down=(pressed==control.id&&hover==control.id)||(flash==control.id&&juce::Time::getMillisecondCounterHiRes()<flashUntil);
        const bool selected=active(control.id)&&!(control.id=="capture"&&host.bridge.flag("capture_selected")&&(juce::Time::getMillisecondCounter()/420)%2!=0);
        auto face=selected?(control.id=="preview"?(host.bridge.flag("preview_suspended")?juce::Colour(0xff867043):((juce::Time::getMillisecondCounter()/400)%2==0?juce::Colour(0xff24963e):juce::Colour(0xff164e28))):control.id=="capture"&&host.bridge.flag("capture_selected")?juce::Colour(0xffbb8830):p.accent):p.face;
        if(hover==control.id) face=face.brighter(.08f);
        if(down) face=face.darker(.22f);
        const float radius=std::max(1.f,4*scale),edge=std::max(1.f/pixels,.9f*scale);
        g.setColour(juce::Colours::black.withAlpha(.24f));g.fillRoundedRectangle(r.translated(0,std::max(1.f/pixels,1.5f*scale)),radius);
        g.setGradientFill(juce::ColourGradient(face.brighter(down?.03f:.22f),r.getCentreX(),r.getY(),face.darker(down?.09f:.16f),r.getCentreX(),r.getBottom(),false));
        g.fillRoundedRectangle(r,radius);
        {
            const juce::Graphics::ScopedSaveState glass(g);
            juce::Path clip;clip.addRoundedRectangle(r.reduced(std::max(.5f,scale)),radius*.85f);g.reduceClipRegion(clip);
            g.setGradientFill(juce::ColourGradient(juce::Colours::white.withAlpha(down?.08f:.24f),r.getCentreX(),r.getY(),juce::Colours::white.withAlpha(.015f),r.getCentreX(),r.getY()+r.getHeight()*.54f,false));
            g.fillRect(r.withHeight(r.getHeight()*.54f));
            g.setColour(p.accent.withAlpha(selected?.13f:.035f));g.fillRect(r.withTrimmedTop(r.getHeight()*.68f));
        }
        g.setColour(selected?face.brighter(.5f).withAlpha(.8f):p.edge);g.drawRoundedRectangle(r.reduced(edge*.5f),radius,edge);
        if(scale>=.75f) {
            g.setColour(juce::Colours::white.withAlpha(down?.06f:.14f));g.drawRoundedRectangle(r.reduced(1.3f*scale),radius*.8f,1.f/pixels);
        }
        auto content=snap(r.translated(down?std::max(1.f/pixels,scale):0,down?std::max(1.f/pixels,scale):0));
        g.setColour(selected?face.contrasting():p.text);
        if(!control.icon.empty()) {
            if(layout.dockFlow&&(control.id.rfind("manual_",0)==0||control.id.rfind("stop_",0)==0)) {
                const float badge=std::max(8.f,12*scale);
                g.setFont(uiFont(host,pixelAlignedFontHeight(10.f,scale,pixels,9.f),juce::Font::bold));
                drawPixelText(g,control.id.rfind("manual_",0)==0?"W":"S",g.getCurrentFont(),snap(content.withWidth(badge)),pixels);
                content.removeFromLeft(badge);
            }
            icon(g,control.icon,content,scale,pixels);
        } else {
            auto label=control.label;
            if(control.id=="preview"&&host.bridge.flag("preview_suspended")) label="PREVIEW PAUSED";
            if(control.id=="scope") {
                const auto message=host.bridge.text("message");
                label=message.empty()?(host.bridge.text("scope")=="selected"?"SELECTED TRACKS":"ALL TRACKS"):message;
            }
            const float base=layout.dockFlow?(control.id=="scope"?11.f:12.f):(control.id=="scope"?11.f:15.f);
            const auto font=uiFont(host,pixelAlignedFontHeight(base,scale,pixels),juce::Font::bold);
            g.setFont(font);
            const auto textArea=snap(content.reduced(std::max(1.f,2*scale),0));
            drawPixelText(g,readableLabel(control.id,label,font,textArea.getWidth()),font,textArea,pixels);
        }
    }
}
void AutomationPanel::resized() {
    const auto sections=host.sectionMask();
    const auto view=makePanelView(side,static_cast<float>(getWidth()),static_cast<float>(getHeight()),preferredScale,sections);
    if(side>=0||view.layout.horizontal!=layout.horizontal||sections!=currentSections) {scrollX=scrollY=0;hover.clear();pressed.clear();}
    currentSections=sections;layout=view.layout;scale=view.scale;contentArea=rect(view.viewport);offsetX=view.offsetX;offsetY=view.offsetY;
    stripScroll.setVisible(view.scrollable);
    if(view.scrollable) {stripScroll.setOrientation(!layout.horizontal);stripScroll.setBounds(rect(view.scrollbar).toNearestInt());}
    scrollX=juce::jlimit(0.f,std::max(0.f,layout.width-contentArea.getWidth()/scale),scrollX);
    scrollY=juce::jlimit(0.f,std::max(0.f,layout.height-contentArea.getHeight()/scale),scrollY);
    updateStripScroll();
    repaint();
}
void AutomationPanel::updateStripScroll() {
    if(!stripScroll.isVisible()) return;
    const bool horizontal=layout.horizontal;
    stripScroll.setRangeLimits(0,horizontal?layout.width:layout.height,juce::dontSendNotification);
    stripScroll.setCurrentRange(horizontal?scrollX:scrollY,(horizontal?contentArea.getWidth():contentArea.getHeight())/scale,juce::dontSendNotification);
    const auto p=palette();
    stripScroll.setColour(juce::ScrollBar::backgroundColourId,p.bg.darker(.15f));
    stripScroll.setColour(juce::ScrollBar::thumbColourId,p.text.withAlpha(.4f));
}
void AutomationPanel::scrollBarMoved(juce::ScrollBar*,double start) {
    if(layout.horizontal) scrollX=static_cast<float>(start);else scrollY=static_cast<float>(start);
    hover.clear();pressed.clear();repaint();
}
void AutomationPanel::setDockSide(int next) {if(side!=next) {side=next;scrollX=scrollY=0;resized();}}
void AutomationPanel::refresh() {theme=host.setting("theme","reaper");if(host.sectionMask()!=currentSections) resized();updateStripScroll();repaint();}
void AutomationPanel::showMenu(const std::string& kind) {menuPosition=juce::Desktop::getMousePosition();popup(kind);}
void AutomationPanel::setUiScale(float value) {if(std::abs(preferredScale-value)>.001f) {preferredScale=value;resized();}}
void AutomationPanel::timerCallback() {
    const auto p=palette();
    if(p.bg!=lastBackground||p.accent!=lastAccent) {updateStripScroll();repaint();}
    else if(host.bridge.flag("capture_selected")||(host.bridge.flag("preview")&&!host.bridge.flag("preview_suspended"))) repaint();
    lastBackground=p.bg;lastAccent=p.accent;
}
juce::String AutomationPanel::getTooltip() {
    if(hover=="scope"&&!host.bridge.text("message").empty()) return host.bridge.text("message");
    for(const auto& control:layout.controls) if(control.id==hover)
        return control.tooltip.empty()?juce::String(commandFor(control.id)):juce::String(control.tooltip);
    return {};
}
juce::Point<float> AutomationPanel::logical(juce::Point<float> p) const {return {(p.x-offsetX)/scale+scrollX,(p.y-offsetY)/scale+scrollY};}
std::string AutomationPanel::hit(juce::Point<float> p) const {
    if(!contentArea.contains(p)) return "";
    p=logical(p);for(const auto& c:layout.controls) if(rect(c.bounds).contains(p)) return c.id;return "";
}
void AutomationPanel::mouseMove(const juce::MouseEvent& e) {const auto next=hit(e.position);if(next!=hover) {hover=next;repaint();}}
void AutomationPanel::mouseExit(const juce::MouseEvent&) {hover.clear();repaint();}
void AutomationPanel::mouseDrag(const juce::MouseEvent& e) {mouseMove(e);}
void AutomationPanel::mouseDown(const juce::MouseEvent& e) {
    menuPosition=e.getScreenPosition();clickModifiers=e.mods;
    if(e.mods.isPopupMenu()) {pressed.clear();popup("context");return;}
    hover=hit(e.position);pressed=hover;repaint();
}
void AutomationPanel::mouseUp(const juce::MouseEvent& e) {
    menuPosition=e.getScreenPosition();
    const auto id=pressed;pressed.clear();hover=hit(e.position);repaint();
    if(!id.empty()&&id==hover&&!e.mods.isPopupMenu()) {
        flash=id;flashUntil=juce::Time::getMillisecondCounterHiRes()+90;
        const juce::Component::SafePointer<AutomationPanel> safe(this);
        juce::Timer::callAfterDelay(95,[safe] {if(safe) {safe->flash.clear();safe->repaint();}});
        activate(id);
    }
}
void AutomationPanel::mouseWheelMove(const juce::MouseEvent& e,const juce::MouseWheelDetails& wheel) {
    const float maxX=std::max(0.f,layout.width-contentArea.getWidth()/scale),maxY=std::max(0.f,layout.height-contentArea.getHeight()/scale);
    const float delta=std::abs(wheel.deltaX)>std::abs(wheel.deltaY)?wheel.deltaX:wheel.deltaY;
    if(maxX>0&&((layout.dockFlow&&layout.horizontal)||(!layout.dockFlow&&!e.mods.isShiftDown()))) scrollX=juce::jlimit(0.f,maxX,scrollX-delta*100);
    else scrollY=juce::jlimit(0.f,maxY,scrollY-delta*100);
    hover.clear();pressed.clear();updateStripScroll();
    repaint();
}
void AutomationPanel::activate(const std::string& id) {
    if(id=="preview_menu"||id=="paste_menu"||id=="settings"||id=="scope") {popup(id);return;}
    if(id=="capture") {
        if(clickModifiers.isCommandDown()||(clickModifiers.isAltDown()&&clickModifiers.isShiftDown())) host.enqueue("capture_selected");
        else host.enqueue(clickModifiers.isAltDown()?"capture_all":"capture");
        return;
    }
    if(id=="preview"&&clickModifiers.isCommandDown()) {host.enqueue("preview_suspend");return;}
    host.enqueue(commandFor(id));
}
juce::PopupMenu::Options AutomationPanel::menuOptionsAt(juce::Component* component,juce::Point<int> screen) {
    return juce::PopupMenu::Options().withTargetComponent(component).withTargetScreenArea({screen.x,screen.y,1,1});
}
juce::PopupMenu AutomationPanel::makePopupMenu(const std::string& kind) const {
    juce::PopupMenu menu;
    const auto version=host.bridge.text("version");
    menu.addSectionHeader(version.empty()?"EA Native Automation":"EA Native Automation v"+juce::String(version));
    auto sizes=[&] {
        juce::PopupMenu items;const int percentages[]={0,50,75,100,125,150,175,200};
        for(int i=0;i<8;++i) items.addItem(400+i,percentages[i]==0?"Auto (compact dock / display)":juce::String(percentages[i])+"%",true,host.uiPercent()==percentages[i]);
        items.addSeparator();items.addItem(0,"Docked buttons stay fixed while resizing",false);
        menu.addSubMenu("Window size",items);
    };
    auto sections=[&] {
        juce::PopupMenu items;int index=0;
        for(const auto& section:sectionDefinitions()) items.addItem(600+index++,section.label,true,(host.sectionMask()&section.bit)!=0);
        items.addSeparator();items.addItem(605,"Show all sections");menu.addSubMenu("Show sections",items);
    };
    auto sendCopies=[&] {
        juce::PopupMenu sends;
        for(int slot=1;slot<=10;++slot)
            sends.addItem(500+slot,"Copy send "+juce::String(slot)+" automation");
        menu.addSubMenu("Copy send automation",sends);
    };
    if(kind=="preview_menu") {menu.addItem(1,"Punch preview values");menu.addItem(2,"Capture all enabled values");menu.addItem(3,"Clear preview latches");menu.addItem(4,host.bridge.flag("preview_suspended")?"Resume Preview":"Suspend Preview (A/B)",host.bridge.flag("preview"));}
    else if(kind=="paste_menu") {menu.addItem(11,"Paste at edit cursor");menu.addItem(12,"Paste to selection (stretch)");menu.addItem(13,"Paste to selection (repeat / fill)");menu.addItem(14,"Copy write-enabled automation");sendCopies();}
    else if(kind=="settings") {
        menu.addItem(21,"Use automation items for write / paste",true,host.bridge.flag("items"));
        menu.addItem(22,"Run at startup",true,host.startup());
        sizes();sections();
    } else {
        menu.addItem(31,"All tracks",true,host.bridge.text("scope")!="selected");menu.addItem(32,"Selected tracks",true,host.bridge.text("scope")=="selected");
        menu.addSeparator();
        const char* positions[]={"Dock bottom","Dock left","Dock top","Dock right","Floating Docker"};
        for(int i=0;i<5;++i) menu.addItem(40+i,positions[i],true,host.dockSide()==i);
        menu.addItem(45,"Undock / floating panel",true,host.dockIndex()<0);
        juce::PopupMenu dockers;for(int i=0;i<16;++i) dockers.addItem(100+i,"Docker "+juce::String(i+1),true,host.dockIndex()==i);
        menu.addSubMenu("Choose Docker",dockers);
        juce::PopupMenu themes;
        const char* ids[]={"reaper","graphite","silver","midnight","warm","classic"};
        const char* names[]={"Follow REAPER theme","Graphite","Silver","Midnight","Warm graphite","Classic charcoal"};
        for(int i=0;i<6;++i) themes.addItem(200+i,names[i],true,theme==ids[i]);
        menu.addSubMenu("Theme",themes);
        sizes();sections();
        juce::PopupMenu modes;const char* modeNames[]={"Trim / Read","Read","Touch","Write","Latch","Latch Preview"};
        for(int i=0;i<6;++i) modes.addItem(300+i,modeNames[i]);menu.addSubMenu("Automation mode",modes);
        sendCopies();
        menu.addSeparator();menu.addItem(50,"Clear capture");menu.addItem(21,"Use automation items for write / paste",true,host.bridge.flag("items"));
        menu.addItem(22,"Run at startup",true,host.startup());menu.addItem(51,"Close");
    }
    return menu;
}
void AutomationPanel::popup(const std::string& kind) {
    auto menu=makePopupMenu(kind);
    const juce::Component::SafePointer<AutomationPanel> safe(this);
    menu.showMenuAsync(menuOptionsAt(this,menuPosition),[safe](int choice) {
        if(!safe||choice==0) return;
        auto& panel=*safe;auto& host=panel.host;
        const std::map<int,std::string> commands={{1,"punch_preview"},{2,"capture_all"},{3,"match"},{4,"preview_suspend"},{11,"paste:cursor"},{12,"paste:fit"},{13,"paste:fill"},{14,"copy:enabled"},{21,"items"},{31,"scope:all"},{32,"scope:selected"},{50,"clear_capture"}};
        const auto it=commands.find(choice);if(it!=commands.end()) host.enqueue(it->second);
        else if(choice>=600&&choice<605) host.setSectionMask(host.sectionMask()^sectionDefinitions()[static_cast<size_t>(choice-600)].bit);
        else if(choice==605) host.setSectionMask(AllSections);
        else if(choice>=501&&choice<=510) host.enqueue("copy:send:"+std::to_string(choice-500));
        else if(choice==22) host.setStartup(!host.startup());
        else if(choice>=40&&choice<=44) host.dockSide(choice-40);
        else if(choice==45) host.undock();else if(choice==51) host.close();
        else if(choice>=100&&choice<116) host.dock(choice-100);
        else if(choice>=200&&choice<206) {
            const char* ids[]={"reaper","graphite","silver","midnight","warm","classic"};
            panel.theme=ids[choice-200];host.save("theme",panel.theme);panel.repaint();
        } else if(choice>=300&&choice<306) host.enqueue("mode:"+std::to_string(choice-300));
        else if(choice>=400&&choice<408) {const int values[]={0,50,75,100,125,150,175,200};host.setUiPercent(values[choice-400]);}
    });
}
void AutomationPanel::icon(juce::Graphics& g,const std::string& kind,juce::Rectangle<float> r,float uiScale,float pixels) {
    const float glyphWidth=kind=="down"?8.f:kind=="gear"?13.f:kind=="punchdown"?12.f:25.f;
    const float glyphHeight=kind=="down"?5.f:14.f,padding=std::max(1.f,3*uiScale);
    const float fit=std::min({1.35f*uiScale,std::max(1.f,r.getWidth()-2*padding)/glyphWidth,std::max(1.f,r.getHeight()-2*padding)/glyphHeight});
    const float stroke=std::max(1.f/pixels,1.15f*fit);
    const float phase=static_cast<int>(std::round(stroke*pixels))%2?.5f:0;
    const auto align=[&](float v) {return (std::round(v*pixels-phase)+phase)/pixels;};
    const float x=align(r.getCentreX()),y=align(r.getCentreY());
    const auto line=[&](float ax,float ay,float bx,float by) {g.drawLine(align(x+ax*fit),align(y+ay*fit),align(x+bx*fit),align(y+by*fit),stroke);};
    const auto arrow=[&](float centre,float direction) {g.drawArrow({align(x+(centre-direction*5)*fit),y,align(x+(centre+direction*5)*fit),y},stroke,std::max(2.f/pixels,5*fit),std::max(2.f/pixels,5*fit));};
    if(kind=="start") {line(-10,-6,-10,6);arrow(0,-1);}
    else if(kind=="end") {line(10,-6,10,6);arrow(0,1);}
    else if(kind=="all") {line(-12,-6,-12,6);line(12,-6,12,6);arrow(-4,-1);arrow(4,1);}
    else if(kind=="punch") {arrow(-3,-1);g.fillEllipse(x+5*fit,y-2*fit,4*fit,4*fit);}
    else if(kind=="next") {g.fillEllipse(x-9*fit,y-2*fit,4*fit,4*fit);arrow(3,1);}
    else if(kind=="down") {juce::Path path;path.startNewSubPath(align(x-3*fit),align(y-fit));path.lineTo(x,align(y+2*fit));path.lineTo(align(x+3*fit),align(y-fit));g.strokePath(path,juce::PathStrokeType(std::max(1.f/pixels,1.5f*fit)));}
    else if(kind=="punchdown") {g.drawArrow({x,align(y-5*fit),x,align(y+3*fit)},stroke,std::max(2.f/pixels,5*fit),std::max(2.f/pixels,5*fit));line(-5,5,5,5);line(-5,3,-5,5);line(5,3,5,5);}
    else if(kind=="gear") {
        juce::Path path;
        for(int i=0;i<32;++i) {const float a=i*juce::MathConstants<float>::twoPi/32,radius=(i%4<2?5.8f:4.5f)*fit;
            if(i==0) path.startNewSubPath(x+std::cos(a)*radius,y+std::sin(a)*radius);else path.lineTo(x+std::cos(a)*radius,y+std::sin(a)*radius);}
        path.closeSubPath();path.setUsingNonZeroWinding(false);path.addEllipse(x-2*fit,y-2*fit,4*fit,4*fit);g.fillPath(path);
    }
}
}
