#include "NativeWindow.h"
#include "ReaperHost.h"
#include "AutomationPanel.h"
#include <stdexcept>
#if !JUCE_WINDOWS
 #include "../WDL/swell/swell-dlggen.h"
#endif
#if JUCE_LINUX
 #include <gdk/gdkx.h>
#endif
namespace ea {
static const char* identity="EACompactAutomationNative";
#if !JUCE_WINDOWS
static void createEmptyDialog(HWND,int) {} // SWELL invokes this callback unconditionally.
#endif
#if JUCE_LINUX
static GdkWindow* nativeGdkWindow(HWND hwnd) {
    // Docked SWELL children share an ancestor's OS window.
    for(int depth=0;hwnd&&depth<64;++depth,hwnd=GetParent(hwnd))
        if(auto* window=static_cast<GdkWindow*>(SWELL_GetOSWindow(hwnd,"GdkWindow"))) return window;
    return nullptr;
}
#endif
static void storeWindow(HWND hwnd,NativeWindow* window) {
   #if JUCE_WINDOWS
    SetWindowLongPtr(hwnd,GWLP_USERDATA,reinterpret_cast<LONG_PTR>(window));
   #else
    SetWindowLong(hwnd,GWL_USERDATA,reinterpret_cast<LONG_PTR>(window));
   #endif
}
static NativeWindow* fetchWindow(HWND hwnd) {
   #if JUCE_WINDOWS
    return reinterpret_cast<NativeWindow*>(GetWindowLongPtr(hwnd,GWLP_USERDATA));
   #else
    return reinterpret_cast<NativeWindow*>(GetWindowLong(hwnd,GWL_USERDATA));
   #endif
}
NativeWindow::NativeWindow(ReaperHost& owner):host(owner),panel(std::make_unique<AutomationPanel>(owner)) {
    try {create();
        const int saved=juce::String(host.setting("dock","-1")).getIntValue();
        if(saved>=0&&saved<16) dock(saved);else fitFloating(false);
        ShowWindow(handle,SW_SHOW);sync();
    } catch(...) {
        panel->removeFromDesktop();if(handle) {storeWindow(handle,nullptr);DestroyWindow(handle);handle=nullptr;}throw;
    }
}
NativeWindow::~NativeWindow() {
    if(!handle) return;
    const int index=dockIndex();host.save("dock",std::to_string(index));
    if(index<0) {
        RECT r{};GetWindowRect(handle,&r);host.save("x",std::to_string(r.left));host.save("y",std::to_string(r.top));
    }
    panel->removeFromDesktop();
    DockWindowRemove(handle);storeWindow(handle,nullptr);DestroyWindow(handle);handle=nullptr;
}
void NativeWindow::create() {
   #if JUCE_WINDOWS
    // Native dialog host is what REAPER docks. JUCE is its child, never the Docker itself.
    struct alignas(4) Template {
        DLGTEMPLATE dialog{};WORD menu=0,windowClass=0;WCHAR title[11]=L"Automation";
    } resource;
    resource.dialog.style=WS_POPUP|WS_CAPTION|WS_SYSMENU|WS_CLIPCHILDREN|DS_CENTER;
    resource.dialog.cx=100;resource.dialog.cy=350;
    handle=CreateDialogIndirectParam(host.moduleInstance(),&resource.dialog,host.mainWindow(),dialogProc,reinterpret_cast<LPARAM>(this));
   #else
    static SWELL_DialogResourceIndex resource={MAKEINTRESOURCE(100),"Automation",SWELL_DLG_WS_NOAUTOSIZE,createEmptyDialog,220,730,nullptr};
    handle=SWELL_CreateDialog(&resource,MAKEINTRESOURCE(100),host.mainWindow(),dialogProc,reinterpret_cast<LPARAM>(this));
   #endif
    if(!handle) throw std::runtime_error("Cannot create the native REAPER window.");
}
void NativeWindow::attach() {
    void* parent=nullptr;
   #if JUCE_WINDOWS
    parent=handle;
   #elif JUCE_MAC
    // SWELL's content HWND is an NSView, which JUCE's Cocoa peer can embed in.
    parent=GetDlgItem(handle,0);
   #elif JUCE_LINUX
    auto* gdkWindow=nativeGdkWindow(handle);
    if(!gdkWindow||!GDK_IS_X11_WINDOW(gdkWindow))
        throw std::runtime_error("The native panel requires REAPER's X11/XWayland backend on Linux.");
    parent=reinterpret_cast<void*>(gdk_x11_window_get_xid(gdkWindow));
   #endif
    if(parent!=embeddedParent||!panel->getPeer()) {
        panel->removeFromDesktop();panel->addToDesktop(0,parent);embeddedParent=parent;
        oldWidth=oldHeight=oldX=oldY=-1;
    }
    panel->setVisible(true);
}
void NativeWindow::sync() {
    if(!handle) return;
    if(const auto* display=currentDisplay()) {
        // Fitting during the native move loop can snap a window back across a
        // DPI boundary. Let the user finish moving before fitting/scaling it.
        if(!sizing&&!moving&&dockIndex()<0&&(displayArea!=display->userArea||std::abs(displayScale-display->scale)>.001)) {fitFloating(true);return;}
        if(!moving) panel->setUiScale(dockIndex()>=0?displayDockUiScale(host.uiPercent()):displayUiScale(host.uiPercent(),static_cast<float>(display->userArea.getHeight())));
    }
   #if JUCE_LINUX
    attach(); // A Docker move may destroy/recreate the previous native parent.
    panel->setVisible(IsWindowVisible(handle)!=0);
   #endif
    RECT client{};GetClientRect(handle,&client);
    int width=std::max(1,static_cast<int>(std::abs(client.right-client.left)));
    int height=std::max(1,static_cast<int>(std::abs(client.bottom-client.top)));
    int x=0,y=0;
   #if JUCE_WINDOWS
    // Win32 client rectangles use physical pixels; JUCE child bounds use DIPs.
    const double dpi=panel->getPeer()?panel->getPeer()->getPlatformScaleFactor():1.0;
    width=std::max(1,static_cast<int>(std::round(width/dpi)));
    height=std::max(1,static_cast<int>(std::round(height/dpi)));
   #endif
   #if JUCE_LINUX
    auto* gdkWindow=nativeGdkWindow(handle);
    if(gdkWindow) {
        POINT origin{0,0};ClientToScreen(handle,&origin);int ox=0,oy=0;gdk_window_get_origin(gdkWindow,&ox,&oy);
        x=static_cast<int>(origin.x)-ox;y=static_cast<int>(origin.y)-oy;
    }
   #endif
    panel->setDockSide(dockSide());
    if(width!=oldWidth||height!=oldHeight||x!=oldX||y!=oldY) {
        panel->setBounds(x,y,width,height);oldWidth=width;oldHeight=height;oldX=x;oldY=y;
    }
}
void NativeWindow::dock(int index) {
    panel->removeFromDesktop();embeddedParent=nullptr;
    DockWindowRemove(handle);Dock_UpdateDockID(identity,index);
    DockWindowAddEx(handle,"Automation",identity,true);DockWindowActivate(handle);
    ShowWindow(handle,SW_SHOW);attach();sync();
}
void NativeWindow::undock() {
    panel->removeFromDesktop();embeddedParent=nullptr;
    // Recreate the top-level native host. Docker removal can leave a hidden child
    // or Cocoa content view attached to the old parent, even after ShowWindow.
    DockWindowRemove(handle);
    storeWindow(handle,nullptr);DestroyWindow(handle);handle=nullptr;
    oldWidth=oldHeight=oldX=oldY=-1;displayScale=0;displayArea={};
    create();fitFloating(false);
}
const juce::Displays::Display* NativeWindow::currentDisplay() const {
    RECT r{};if(handle) GetWindowRect(handle,&r);
    const auto rect=juce::Rectangle<int>(static_cast<int>(r.left),static_cast<int>(r.top),static_cast<int>(r.right-r.left),static_cast<int>(r.bottom-r.top));
    return juce::Desktop::getInstance().getDisplays().getDisplayForRect(rect,
       #if JUCE_WINDOWS
        true
       #else
        false
       #endif
    );
}
void NativeWindow::fitFloating(bool keepPosition) {
    const juce::ScopedValueSetter<bool> guard(sizing,true);
    int x=juce::String(host.setting("x","200")).getIntValue();
    int y=juce::String(host.setting("y","120")).getIntValue();
    if(keepPosition) {RECT r{};GetWindowRect(handle,&r);x=static_cast<int>(r.left);y=static_cast<int>(r.top);}
    const auto& displays=juce::Desktop::getInstance().getDisplays();
    // For a moved window use its largest monitor overlap, rather than the top
    // left corner which may still sit on the old monitor after crossing over.
    const auto* display=keepPosition?currentDisplay():displays.getDisplayForPoint({x,y},
       #if JUCE_WINDOWS
        true
       #else
        false
       #endif
    );
    if(!display) display=displays.getPrimaryDisplay();
    const auto area=display?display->userArea:juce::Rectangle<int>(0,0,1280,800);
    const float ui=displayUiScale(host.uiPercent(),static_cast<float>(area.getHeight()));
    panel->setUiScale(ui);
    const auto layout=makeDockLayout(-1,0,0,ui,host.sectionMask());
    const int contentWidth=std::max(60,std::min(static_cast<int>(std::round(layout.width*ui)),area.getWidth()-24));
    const int contentHeight=std::max(80,std::min(static_cast<int>(std::round(layout.height*ui)),area.getHeight()-56));
    displayArea=area;displayScale=display?display->scale:1;
   #if JUCE_WINDOWS
    const DWORD style=WS_POPUP|WS_CAPTION|WS_SYSMENU|WS_CLIPCHILDREN;
    SetWindowLongPtr(handle,GWL_STYLE,style);
    SetWindowLongPtr(handle,GWL_EXSTYLE,WS_EX_TOOLWINDOW);
    SetWindowLongPtr(handle,GWLP_HWNDPARENT,reinterpret_cast<LONG_PTR>(host.mainWindow()));
    RECT rect{0,0,static_cast<LONG>(std::round(contentWidth*displayScale)),static_cast<LONG>(std::round(contentHeight*displayScale))};
    using AdjustForDpi=BOOL(WINAPI*)(LPRECT,DWORD,BOOL,DWORD,UINT);
    const auto adjust=reinterpret_cast<AdjustForDpi>(GetProcAddress(GetModuleHandleW(L"user32.dll"),"AdjustWindowRectExForDpi"));
    if(adjust) adjust(&rect,style,FALSE,WS_EX_TOOLWINDOW,static_cast<UINT>(std::round(96*displayScale)));
    else AdjustWindowRectEx(&rect,style,FALSE,WS_EX_TOOLWINDOW);
    const auto work=displays.logicalToPhysical(area,display);
    const int width=static_cast<int>(rect.right-rect.left),height=static_cast<int>(rect.bottom-rect.top);
    x=juce::jlimit(work.getX()+6,std::max(work.getX()+6,work.getRight()-width-6),x);
    y=juce::jlimit(work.getY()+6,std::max(work.getY()+6,work.getBottom()-height-6),y);
    SetWindowPos(handle,HWND_TOP,x,y,width,height,SWP_FRAMECHANGED|SWP_NOACTIVATE|SWP_SHOWWINDOW);
   #else
    x=juce::jlimit(area.getX()+6,std::max(area.getX()+6,area.getRight()-contentWidth-6),x);
    y=juce::jlimit(area.getY()+6,std::max(area.getY()+6,area.getBottom()-contentHeight-30),y);
    SetWindowPos(handle,nullptr,x,y,contentWidth,contentHeight,SWP_NOZORDER|SWP_NOACTIVATE);
   #endif
    ShowWindow(handle,SW_SHOW);attach();sync();
}
void NativeWindow::applyUiScale() {
    if(dockIndex()<0) fitFloating(true);
    else {panel->setUiScale(displayDockUiScale(host.uiPercent()));sync();}
}
int NativeWindow::dockIndex() const {bool floating=false;return handle?DockIsChildOfDock(handle,&floating):-1;}
int NativeWindow::dockSide() const {const int index=dockIndex();return index>=0?DockGetPosition(index):-1;}
void NativeWindow::refresh() {if(panel) panel->refresh();}
void NativeWindow::showMenu(const std::string& kind) {if(panel) panel->showMenu(kind);}
INT_PTR NativeWindow::dialogProc(HWND hwnd,UINT message,WPARAM,LPARAM lparam) {
    if(message==WM_INITDIALOG) {storeWindow(hwnd,reinterpret_cast<NativeWindow*>(lparam));return 1;}
    auto* window=fetchWindow(hwnd);
    if(!window) return 0;
    // Handle context requests forwarded from the dock tab/native wrapper as well
    // as the JUCE panel's mouse events. Leave REAPER's other Docker messages alone.
    if(message==WM_CONTEXTMENU) {window->showMenu("context");return 1;}
    if(message==WM_GETMINMAXINFO&&lparam&&window->dockIndex()>=0) {
        const auto minimum=dockMinimumSize(window->dockSide(),displayDockUiScale(window->host.uiPercent()),
            static_cast<float>(window->panel->getWidth()),static_cast<float>(window->panel->getHeight()));
        double dpi=1;
       #if JUCE_WINDOWS
        if(auto* peer=window->panel->getPeer()) dpi=peer->getPlatformScaleFactor();
       #endif
        auto* limits=reinterpret_cast<MINMAXINFO*>(lparam);
        limits->ptMinTrackSize.x=static_cast<LONG>(std::ceil(minimum.w*dpi));
        limits->ptMinTrackSize.y=static_cast<LONG>(std::ceil(minimum.h*dpi));
        return 1;
    }
   #if JUCE_WINDOWS
    if(message==WM_ENTERSIZEMOVE) {window->moving=true;return 0;}
    if(message==WM_EXITSIZEMOVE) {
        window->moving=false;
        if(window->dockIndex()<0) {
            window->fitFloating(true);
            RECT r{};GetWindowRect(hwnd,&r);
            window->host.save("x",std::to_string(r.left));window->host.save("y",std::to_string(r.top));
        }
        return 0;
    }
   #endif
    if(message==WM_CLOSE) {window->host.close();return 1;}
    if(message==WM_SIZE) {window->sync();return 0;}
    return 0;
}
}
