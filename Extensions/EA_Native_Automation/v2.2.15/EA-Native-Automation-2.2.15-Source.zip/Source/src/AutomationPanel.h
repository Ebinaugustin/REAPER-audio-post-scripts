#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "PanelModel.h"
namespace ea {
class ReaperHost;
class AutomationPanel final : public juce::Component, public juce::TooltipClient, private juce::Timer, private juce::ScrollBar::Listener {
public:
    explicit AutomationPanel(ReaperHost&);
    void paint(juce::Graphics&) override;
    void resized() override;
    void mouseMove(const juce::MouseEvent&) override;
    void mouseExit(const juce::MouseEvent&) override;
    void mouseDown(const juce::MouseEvent&) override;
    void mouseUp(const juce::MouseEvent&) override;
    void mouseDrag(const juce::MouseEvent&) override;
    void mouseWheelMove(const juce::MouseEvent&,const juce::MouseWheelDetails&) override;
    void setDockSide(int side);
    void refresh();
    void showMenu(const std::string&);
    juce::PopupMenu makePopupMenu(const std::string&) const;
    void setUiScale(float);
    juce::String getTooltip() override;
    static juce::PopupMenu::Options menuOptionsAt(juce::Component*,juce::Point<int>);
private:
    ReaperHost& host;
    Layout layout;
    int side=-1;
    float scale=1,offsetX=0,offsetY=0,scrollX=0,scrollY=0;
    float preferredScale=1;
    unsigned currentSections=AllSections;
    juce::Point<int> menuPosition;
    juce::ModifierKeys clickModifiers;
    std::string hover,pressed,theme,flash;
    double flashUntil=0;
    juce::TooltipWindow tooltips;
    juce::ScrollBar stripScroll{false};
    juce::Rectangle<float> contentArea;
    struct Palette {juce::Colour bg,face,text,accent,edge;};
    juce::Colour lastBackground,lastAccent;
    Palette palette() const;
    juce::Point<float> logical(juce::Point<float>) const;
    std::string hit(juce::Point<float>) const;
    bool active(const std::string&) const;
    void activate(const std::string&);
    void popup(const std::string&);
    void timerCallback() override;
    void scrollBarMoved(juce::ScrollBar*,double) override;
    void updateStripScroll();
    static void icon(juce::Graphics&,const std::string&,juce::Rectangle<float>,float,float);
};
}
