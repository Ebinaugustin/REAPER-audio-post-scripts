#pragma once
#include <string>
#include <vector>
namespace ea {
struct Rect { float x,y,w,h; };
struct Control {
    std::string id,label,icon,tooltip;
    Rect bounds;
};
struct Heading { std::string text; Rect bounds; };
struct Layout { float width,height; bool horizontal; std::vector<Control> controls; std::vector<Heading> headings; bool singleLine=false,dockFlow=false; };
Layout makeLayout(bool horizontal, bool shallow = false);
enum Section : unsigned {SuspendSection=1,WriteEnableSection=2,ManualWriteSection=4,WriteOnStopSection=8,CopyPasteSection=16,AllSections=31};
struct SectionDefinition {const char* id;const char* label;unsigned bit;};
inline const std::vector<SectionDefinition>& sectionDefinitions() {
    static const std::vector<SectionDefinition> sections={{"SUSPEND","Suspend",SuspendSection},{"WRITE_ENABLE","Write Enable",WriteEnableSection},
        {"MANUAL_WRITE","Manual Write",ManualWriteSection},{"WRITE_ON_STOP","Write on Stop",WriteOnStopSection},{"COPY_PASTE","Copy / Paste",CopyPasteSection}};
    return sections;
}
unsigned controlSection(const std::string& id);
Layout applySectionVisibility(Layout,unsigned sections);
Layout makeSingleLineLayout(bool horizontal,unsigned sections=AllSections);
Layout makeDockLayout(int side,float width,float height,float preferredScale,unsigned sections=AllSections);
struct PanelView {Layout layout;float scale,offsetX,offsetY;Rect viewport,scrollbar;bool scrollable;};
PanelView makePanelView(int side,float width,float height,float preferredScale,unsigned sections=AllSections);
std::string commandFor(const std::string& id);
float displayUiScale(int percent,float workAreaHeight);
float displayDockUiScale(int percent);
Rect dockMinimumSize(int side,float scale,float width,float height);
float pixelAlignedFontHeight(float baseHeight,float scale,float pixelsPerUnit,float minimum=11.f);
Rect pixelAlignedRect(Rect bounds,float pixelsPerUnit);
}
