#define REAPERAPI_IMPLEMENT
#include "ReaperHost.h"
#include "NativeWindow.h"
#include <stdexcept>
namespace ea {
ReaperHost* activeHost=nullptr;
static const char* settingsSection="EA_Native_Automation";
static const char* dockIdentity="EACompactAutomationNative";
static bool actionHook(int command,int) {
    if(!activeHost) return false;
    try {return activeHost->handleAction(command);}
    catch(const std::exception& e) {activeHost->error(e.what());}
    return true;
}
static int toggleHook(int command) {return activeHost?activeHost->actionState(command):-1;}
static void timerHook() {if(activeHost) activeHost->tick();}
static void nativeOpen() {if(activeHost) try {activeHost->open();} catch(const std::exception& e) {activeHost->error(e.what());}}
static void nativeConnect(bool active) {if(activeHost) try {activeHost->connect(active);} catch(const std::exception& e) {activeHost->error(e.what());activeHost->bridge.requestClose();}}
static const char* nativeNext() {return activeHost ? activeHost->bridge.next():"close";}
static void nativePublish(const char* packet) {if(activeHost) activeHost->publish(packet);}
static void* openVar(void**,int) {nativeOpen();return nullptr;}
static void* connectVar(void** a,int n) {if(n>0) nativeConnect(reinterpret_cast<intptr_t>(a[0])!=0);return nullptr;}
static void* nextVar(void**,int) {return const_cast<char*>(nativeNext());}
static void* publishVar(void** a,int n) {if(n>0) nativePublish(static_cast<const char*>(a[0]));return nullptr;}
static const char openDef[]="void\0\0\0Open the JUCE automation panel.";
static const char connectDef[]="void\0bool\0active\0Connect or disconnect the automation engine.";
static const char nextDef[]="const char*\0\0\0Read the next bounded automation command.";
static const char publishDef[]="void\0const char*\0state\0Publish automation button state to the native UI.";
struct ApiEntry {const char* name;void* function;void* vararg;const char* definition;};
static const ApiEntry apis[]={
    {"EA_Native_Open",reinterpret_cast<void*>(nativeOpen),reinterpret_cast<void*>(openVar),openDef},
    {"EA_Native_Connect",reinterpret_cast<void*>(nativeConnect),reinterpret_cast<void*>(connectVar),connectDef},
    {"EA_Native_NextCommand",reinterpret_cast<void*>(nativeNext),reinterpret_cast<void*>(nextVar),nextDef},
    {"EA_Native_Publish",reinterpret_cast<void*>(nativePublish),reinterpret_cast<void*>(publishVar),publishDef}};
ReaperHost::ReaperHost(REAPER_PLUGIN_HINSTANCE i,reaper_plugin_info_t& r):instance(i),info(r) {}
ReaperHost::~ReaperHost() {shutdown();}
bool ReaperHost::initialise() {
    if(REAPERAPI_LoadAPI(info.GetFunc)!=0) return false;
    activeHost=this;
    command=info.Register("command_id",const_cast<char*>("EACompactAutomationNative"));
    if(command<=0) return false;
    action.accel.cmd=static_cast<WORD>(command);
    action.desc="EA: Native Automation (JUCE) - toggle panel";
    registerApis(true);
    info.Register("gaccel",&action);info.Register("hookcommand",reinterpret_cast<void*>(actionHook));
    info.Register("toggleaction",reinterpret_cast<void*>(toggleHook));
    info.Register("timer",reinterpret_cast<void*>(timerHook));
    registered=true;
    actions.reserve(actionCatalog().size());
    for(const auto& definition:actionCatalog()) {
        const int id=info.Register("command_id",const_cast<char*>(definition.id.c_str()));
        if(id<=0) {shutdown();return false;}
        actions.push_back({id,&definition,{}});
        auto& registeredAction=actions.back();
        registeredAction.accel.accel.cmd=static_cast<WORD>(id);
        registeredAction.accel.desc=definition.title.c_str();
        info.Register("gaccel",&registeredAction.accel);
    }
    refreshActions();return true;
}
void ReaperHost::registerApis(bool add) {
    const std::string prefix=add?"":"-";
    for(const auto& api:apis) {
        info.Register((prefix+"API_"+api.name).c_str(),api.function);
        info.Register((prefix+"APIdef_"+api.name).c_str(),const_cast<char*>(api.definition));
        info.Register((prefix+"APIvararg_"+api.name).c_str(),api.vararg);
    }
}
void ReaperHost::shutdown() {
    if(registered) {
        info.Register("-timer",reinterpret_cast<void*>(timerHook));
        info.Register("-toggleaction",reinterpret_cast<void*>(toggleHook));
        info.Register("-hookcommand",reinterpret_cast<void*>(actionHook));
        for(auto& item:actions) info.Register("-gaccel",&item.accel);
        info.Register("-gaccel",&action);registerApis(false);registered=false;
    }
    actions.clear();pendingActions.clear();
    bridge.requestClose();window.reset();
    if(activeHost==this) activeHost=nullptr;
}
void ReaperHost::tick() {
    if(inTick) return;
    const juce::ScopedValueSetter<bool> guard(inTick,true);
    try {
        if(startupPending) {startupPending=false;if(startup()) open();}
        if(starting && std::chrono::steady_clock::now()-started>std::chrono::seconds(5)) {
            starting=false;pendingActions.clear();error("The automation engine did not connect. Check the installed engine.lua and close the older automation panel.");
        }
        if(window) window->sync();
        if(bridge.connected&&!bridge.closing&&!pendingActions.empty()) {
            const auto waiting=std::move(pendingActions);pendingActions.clear();
            for(const auto* definition:waiting) performAction(*definition);
        }
       #if JUCE_LINUX
        // REAPER owns the GTK loop; service JUCE's separate X11 queue briefly.
        if(window) juce::MessageManager::getInstance()->runDispatchLoopUntil(1);
       #endif
    } catch(const std::exception& e) {error(e.what());close();}
}
void ReaperHost::open() {
    if(bridge.connected||starting) return;
    const auto path=juce::File(juce::String::fromUTF8(GetResourcePath())).getChildFile("UserPlugins/EA_Native_Automation/engine.lua");
    if(!path.existsAsFile()) {error("Install EA_Native_Automation/engine.lua alongside the extension in REAPER's UserPlugins folder.");return;}
    const auto script=path.getFullPathName();
    const int id=AddRemoveReaScript(true,0,script.toRawUTF8(),true);
    if(id<=0) {error("Cannot register the automation engine action.");return;}
    starting=true;started=std::chrono::steady_clock::now();Main_OnCommand(id,0);
}
void ReaperHost::close() {pendingActions.clear();if(bridge.connected) bridge.requestClose();else {starting=false;window.reset();}refreshActions();}
void ReaperHost::connect(bool active) {
    starting=false;
    if(active) {
        bridge.reset();bridge.connected=true;
        window=std::make_unique<NativeWindow>(*this);
    } else {window.reset();bridge.reset();pendingActions.clear();}
    RefreshToolbar2(0,command);
    refreshActions();
}
void ReaperHost::publish(const char* packet) {bridge.publish(packet);if(window) window->refresh();refreshActions();}
bool ReaperHost::visible() const {return window&&window->isVisible();}
void ReaperHost::enqueue(const std::string& command) {if(bridge.connected) bridge.push(command);}
bool ReaperHost::handleAction(int id) {
    if(id==command) {if(visible()||starting) close();else open();return true;}
    for(const auto& item:actions) if(item.command==id) {
        const auto& definition=*item.definition;
        if(definition.kind==ActionKind::Open) {open();return true;}
        if(definition.kind==ActionKind::Close) {close();return true;}
        if(definition.kind==ActionKind::Startup||definition.kind==ActionKind::Theme||definition.kind==ActionKind::Scale||definition.kind==ActionKind::Section) {performAction(definition);return true;}
        if(bridge.closing) return true;
        if(bridge.connected) performAction(definition);
        else {
            if(pendingActions.size()>=256) {error("Too many pending automation actions. Wait for the panel to open.");return true;}
            pendingActions.push_back(&definition);open();
            if(!starting&&!bridge.connected) pendingActions.clear();
        }
        return true;
    }
    return false;
}
void ReaperHost::performAction(const ActionDefinition& definition) {
    switch(definition.kind) {
        case ActionKind::Engine: enqueue(definition.command);break;
        case ActionKind::Open: open();break;
        case ActionKind::Close: close();break;
        case ActionKind::Menu: if(window) window->showMenu(definition.command);break;
        case ActionKind::Startup: setStartup(!startup());break;
        case ActionKind::Scale: setUiPercent(definition.value);break;
        case ActionKind::Theme: save("theme",definition.command);if(window) window->refresh();break;
        case ActionKind::Dock: dock(definition.value);break;
        case ActionKind::Side: dockSide(definition.value);break;
        case ActionKind::Undock: undock();break;
        case ActionKind::Section: setSectionMask(definition.value?sectionMask()^static_cast<unsigned>(definition.value):AllSections);break;
    }
    refreshActions();
}
int ReaperHost::definitionState(const ActionDefinition& definition) const {
    if(definition.toggle.empty()) return -1;
    if(definition.kind==ActionKind::Startup) return startup()?1:0;
    if(definition.kind==ActionKind::Section) return (sectionMask()&static_cast<unsigned>(definition.value))?1:0;
    if(definition.kind==ActionKind::Scale) return uiPercent()==definition.value?1:0;
    if(definition.kind==ActionKind::Theme) return setting("theme","reaper")==definition.command?1:0;
    if(definition.kind==ActionKind::Dock) return visible()&&dockIndex()==definition.value?1:0;
    if(definition.kind==ActionKind::Side) return visible()&&dockIndex()>=0&&dockSide()==definition.value?1:0;
    if(definition.kind==ActionKind::Undock) return visible()&&dockIndex()<0?1:0;
    const auto equal=definition.toggle.find('=');
    if(equal!=std::string::npos) {
        const auto key=definition.toggle.substr(0,equal),value=definition.toggle.substr(equal+1);
        if(!bridge.connected&&key=="scope") {
            const auto saved=GetExtState("EA_Compact_Automation","scope");
            return std::string(saved&&*saved?saved:"all")==value?1:0;
        }
        return bridge.connected&&bridge.text(key)==value?1:0;
    }
    if(!bridge.connected&&definition.toggle=="items") {const auto value=GetExtState("EA_Compact_Automation","use_items");return value&&std::string(value)=="1"?1:0;}
    return bridge.connected&&bridge.flag(definition.toggle)?1:0;
}
int ReaperHost::actionState(int id) const {
    if(id==command) return visible()?1:0;
    for(const auto& item:actions) if(item.command==id) return definitionState(*item.definition);
    return -1;
}
void ReaperHost::refreshActions() {
    for(auto& item:actions) {
        const int state=definitionState(*item.definition);
        if(state!=item.lastState) {item.lastState=state;RefreshToolbar2(0,item.command);}
    }
}
void ReaperHost::dock(int index) {if(window&&index>=0&&index<16) {window->dock(index);save("dock",std::to_string(index));}}
void ReaperHost::dockSide(int side) {
    if(window&&dockIndex()>=0&&DockGetPosition(dockIndex())==side) return;
    for(int i=0;i<16;++i) if(DockGetPosition(i)==side) {dock(i);return;}
    error("No Docker is assigned to this side. Assign one using REAPER's native Docker tab menu, then choose the side again.");
}
void ReaperHost::undock() {if(window) {window->undock();save("dock","-1");}}
int ReaperHost::uiPercent() const {return juce::String(setting("ui_percent","0")).getIntValue();}
void ReaperHost::setUiPercent(int percent) {
    if(percent!=0&&percent!=50&&percent!=75&&percent!=100&&percent!=125&&percent!=150&&percent!=175&&percent!=200) return;
    save("ui_percent",std::to_string(percent));if(window) window->applyUiScale();refreshActions();
}
int ReaperHost::dockIndex() const {return window?window->dockIndex():-1;}
unsigned ReaperHost::sectionMask() const {
    const auto text=setting("visible_sections","31");
    try {size_t end=0;const auto value=std::stoul(text,&end);return end==text.size()?static_cast<unsigned>(value)&AllSections:AllSections;}
    catch(...) {return AllSections;}
}
void ReaperHost::setSectionMask(unsigned sections) {
    save("visible_sections",std::to_string(sections&AllSections));
    if(window) {window->refresh();window->applyUiScale();}
}
int ReaperHost::dockSide() const {return window?window->dockSide():-1;}
bool ReaperHost::startup() const {return setting("run_at_startup")=="1";}
void ReaperHost::setStartup(bool enabled) {save("run_at_startup",enabled?"1":"0");}
std::string ReaperHost::setting(const char* key,const char* fallback) const {
    const auto value=GetExtState(settingsSection,key);return value&&*value?value:fallback;
}
void ReaperHost::save(const char* key,const std::string& value) {SetExtState(settingsSection,key,value.c_str(),true);refreshActions();}
juce::Colour ReaperHost::themeBackground() const {
    const int col=GetThemeColor("col_main_bg",0);int r=40,g=43,b=48;
    if(col!=-1) ColorFromNative(col,&r,&g,&b);
    return juce::Colour::fromRGB(static_cast<juce::uint8>(r),static_cast<juce::uint8>(g),static_cast<juce::uint8>(b));
}
juce::Colour ReaperHost::themeAccent() const {
    // REAPER has no single accent token. Its enabled-toolbar colour is the
    // closest semantic match; monochrome toolbar themes use highlight colours.
    juce::Colour neutral;bool found=false;
    for(const auto* key:{"col_toolbar_text_on","col_main_resize2","genlist_selbg","col_tl_bgsel","col_seltrack"}) {
        const int native=GetThemeColor(key,0);if(native==-1) continue;
        int r=0,g=0,b=0;ColorFromNative(native,&r,&g,&b);
        const auto colour=juce::Colour::fromRGB(static_cast<juce::uint8>(r),static_cast<juce::uint8>(g),static_cast<juce::uint8>(b));
        if(!found) {neutral=colour;found=true;}
        if(colour.getSaturation()>=.12f&&colour.getBrightness()>=.12f) return colour;
    }
    return found?neutral:themeBackground().withSaturation(0.f).contrasting(.45f);
}
juce::Font ReaperHost::reaperFont(float height,bool medium) const {
    if(!fontsLoaded) {
        fontsLoaded=true;
        using ExePath=const char*(*)();
        const auto getExe=reinterpret_cast<ExePath>(info.GetFunc("GetExePath"));
        const char* path=getExe?getExe():nullptr;
        if(path&&*path) {
            const juce::File executableFolder(juce::String::fromUTF8(path));
            const std::vector<juce::File> roots={executableFolder,executableFolder.getChildFile("Resources"),
                executableFolder.getParentDirectory().getChildFile("Resources"),executableFolder.getParentDirectory()};
            const auto load=[&](const char* name) -> juce::Typeface::Ptr {
                for(const auto& root:roots) for(const auto* sub:{"Plugins","plugins","Fonts","fonts",""}) {
                    const auto file=(*sub?root.getChildFile(sub):root).getChildFile(name);
                    if(!file.existsAsFile()) continue;
                    juce::MemoryBlock data;
                    if(file.loadFileAsData(data)&&data.getSize()>0&&data.getSize()<8*1024*1024)
                        if(auto face=juce::Typeface::createSystemTypefaceFor(data.getData(),data.getSize())) return face;
                }
                return {};
            };
            regularFont=load("Inter-Regular.ttf");mediumFont=load("Inter-Medium.ttf");
        }
    }
    const auto face=medium?(mediumFont?mediumFont:regularFont):(regularFont?regularFont:mediumFont);
    if(face) return juce::Font(juce::FontOptions(face).withHeight(height));
   #if JUCE_WINDOWS
    const char* family="Segoe UI";
   #elif JUCE_MAC
    const char* family="Helvetica Neue";
   #else
    const char* family="DejaVu Sans";
   #endif
    return juce::Font(juce::FontOptions(family,height,juce::Font::plain));
}
void ReaperHost::error(const std::string& message) const {ShowMessageBox(message.c_str(),"EA Native Automation",0);}
}
