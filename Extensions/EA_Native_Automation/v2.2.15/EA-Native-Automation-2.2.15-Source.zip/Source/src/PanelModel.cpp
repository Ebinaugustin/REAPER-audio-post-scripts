#include "PanelModel.h"
#include <array>
#include <algorithm>
#include <cmath>
namespace ea {
float displayUiScale(int percent,float workAreaHeight) {
    return percent>0 ? std::clamp(percent/100.f,.5f,2.f) : std::clamp(workAreaHeight/900.f,.85f,1.75f);
}
float displayDockUiScale(int percent) {
    // A compact toolbar default, with every explicit preset honored exactly.
    return percent>0?std::clamp(percent/100.f,.5f,2.f):.75f;
}
float pixelAlignedFontHeight(float baseHeight,float scale,float pixelsPerUnit,float minimum) {
    pixelsPerUnit=std::max(.5f,pixelsPerUnit);
    return std::ceil(std::max(minimum,baseHeight*scale)*pixelsPerUnit)/pixelsPerUnit;
}
Rect pixelAlignedRect(Rect r,float pixelsPerUnit) {
    pixelsPerUnit=std::max(.5f,pixelsPerUnit);
    const auto snap=[&](float v) {return std::round(v*pixelsPerUnit)/pixelsPerUnit;};
    const float x=snap(r.x),y=snap(r.y);
    return {x,y,std::max(1.f/pixelsPerUnit,snap(r.x+r.w)-x),std::max(1.f/pixelsPerUnit,snap(r.y+r.h)-y)};
}
Rect dockMinimumSize(int side,float scale,float width,float height) {
    const bool horizontal=side==0||side==2||(side==4&&width>height*1.4f);
    scale=std::clamp(scale,.5f,2.f);
    return {0,0,(horizontal?32.f:88.f)*scale,(horizontal?34.f:32.f)*scale};
}
static Layout readable(Layout l) {
    const float sx=l.horizontal?1.5f:220.f/140.f;
    const float sy=l.horizontal?1.4f:730.f/524.f;
    l.width*=sx;l.height*=sy;
    for(auto& c:l.controls) {auto& r=c.bounds;r={r.x*sx,r.y*sy,r.w*sx,r.h*sy};}
    for(auto& heading:l.headings) {
        auto& r=heading.bounds;
        if(!l.horizontal&&heading.text=="MANUAL WRITE") r.y+=6;
        r={r.x*sx,r.y*sy,r.w*sx,r.h*sy};
    }
    return l;
}
std::string commandFor(const std::string& id) {
    if (id.rfind("manual_",0)==0) return "write:"+id.substr(7);
    if (id.rfind("stop_",0)==0) return "onstop:"+id.substr(5);
    for (const auto& group : {"plugin","vol","svol","pan","span","mute","smute"})
        if (id==group) return "group:"+id;
    if (id=="copy_all") return "copy:all";
    if (id=="copy_pan") return "copy:pan";
    if (id=="paste_fill") return "paste:fill";
    if (id=="punch_capture") return "punch";
    return id;
}
Layout makeLayout(bool horizontal, bool shallow) {
    Layout l{horizontal ? (shallow ? 954.f : 666.f) : 140.f, horizontal ? (shallow ? 84.f : 140.f) : 472.f, horizontal,{},{}};
    auto add=[&](std::string id,std::string label,Rect r,std::string icon="",std::string tip="") {
        if(tip.empty()) {
            if(id=="plugin") tip="Write-enable other plug-in parameter automation";
            else if(id=="vol") tip="Write-enable track volume automation";
            else if(id=="svol") tip="Write-enable send volume automation";
            else if(id=="pan") tip="Write-enable track pan and all ReaSurround / ReaSurroundPan automation";
            else if(id=="span") tip="Write-enable send pan automation";
            else if(id=="mute") tip="Write-enable track mute automation";
            else if(id=="smute") tip="Write-enable send mute automation";
            else if(id=="preview") tip="Toggle Latch Preview; Ctrl/Cmd-click suspends/resumes it for A/B comparison; turning it off restores per-track automation control";
            else if(id=="preview_menu") tip="Preview punch, capture all and clear latches";
            else if(id=="capture") tip="Capture current values; Ctrl/Cmd-click captures selected tracks (blinking). Alt/Option captures all; Alt/Option+Shift captures selected tracks";
            else if(id=="punch_capture") tip="Punch captured values into automation during playback";
            else if(id=="join") tip="Automatically rejoin writing when playback resumes";
            else if(id=="match") tip="Clear latches and return to underlying automation";
            else if(id=="copy_all") tip="Copy all source automation; use the time selection to limit its range";
            else if(id=="copy_pan") tip="Copy track pan and ReaSurround / ReaSurroundPan automation";
            else if(id=="paste_fill") tip="Repeat copied automation to fill the time selection";
            else if(id=="paste_menu") tip="Paste at cursor, stretch to selection, repeat fill or copy enabled automation";
            else if(id=="settings") tip="Automation items and run at startup";
            else if(id=="scope") tip="Choose all tracks or selected tracks";
            else if(id.rfind("manual_",0)==0||id.rfind("stop_",0)==0) {
                const auto range=id.substr(id.rfind('_')+1);
                const std::string prefix=id.rfind("stop_",0)==0?"On stop: ":"Manual write: ";
                if(range=="start") tip=prefix+"current values from range start to play/edit position";
                else if(range=="all") tip=prefix+"current values across the time selection, otherwise project range";
                else if(range=="end") tip=prefix+"current values from play/edit position to range end";
                else if(range=="punch") tip=prefix+"current values from first touch/punch position to play/edit position";
                else if(range=="next") tip=prefix+"current values from play/edit position to the next automation point";
            }
        }
        l.controls.push_back({std::move(id),std::move(label),std::move(icon),std::move(tip),r});
    };
    add("suspend","SUSPEND",{8,8,124,21},"","Bypass all track envelopes and automation writing; click again to restore their previous states");
    l.headings.push_back({"WRITE ENABLE",{8,34,124,14}});
    add("plugin","PLUG IN",{8,52,124,22});
    const std::array<const char*,6> ids{"vol","svol","pan","span","mute","smute"};
    const std::array<const char*,6> names{"VOL","S VOL","PAN","S PAN","MUTE","S MUTE"};
    for (int i=0;i<6;++i) add(ids[i],names[i],{8.f+(i%2)*64.f,80.f+(i/2)*25.f,60,21});
    const std::array<const char*,5> ranges{"start","all","end","punch","next"};
    for (int section=0;section<2;++section) {
        const float y=162.f+section*84.f;
        l.headings.push_back({section==0 ? "MANUAL WRITE":"WRITE ON STOP",{8,y-15,124,14}});
        for (int i=0;i<5;++i) {
            const float x=i<3 ? 8.f+i*43.f : 29.f+(i-3)*43.f;
            add(std::string(section==0 ? "manual_":"stop_")+ranges[i],"",{x,y+(i<3 ? 5.f:33.f),38,23},ranges[i]);
        }
    }
    add("join","AUTO JOIN",{8,306,124,21});add("match","AUTO MATCH",{8,332,124,21});
    add("preview","PREVIEW",{8,358,99,21});add("preview_menu","",{111,358,21,21},"down");
    add("capture","CAPTURE",{8,384,99,21});add("punch_capture","",{111,384,21,21},"punchdown");
    l.headings.push_back({"COPY / PASTE",{8,410,124,14}});
    add("copy_all","COPY ALL",{8,429,124,21});add("copy_pan","COPY PAN",{8,455,124,21});
    add("paste_fill","FILL SELECTION",{8,481,103,21});add("paste_menu","",{115,481,17,21},"down");
    // Footer occupies a separate short row; width stays compact.
    if (!horizontal) { l.height=524;add("scope","ALL TRACKS",{8,508,103,15});add("settings","",{115,506,17,17},"gear");return readable(l); }
    l.headings.clear();
    for (auto& c:l.controls) {
        const auto id=c.id;
        if (id=="suspend"||id=="join"||id=="match") c.bounds={8,8.f+(id=="suspend"?0:id=="join"?27:54),124,22};
        else if (id=="preview"||id=="capture") c.bounds={8,89.f+(id=="capture"?27:0),99,22};
        else if(id=="preview_menu"||id=="punch_capture") c.bounds={111,89.f+(id=="punch_capture"?27:0),21,22};
        else if(id=="plugin") c.bounds={148,27,124,22};
        else {
            int index=-1;for(int i=0;i<6;++i) if(id==ids[i]) index=i;
            if(index>=0) c.bounds={148.f+(index%2)*64.f,55.f+(index/2)*27.f,60,22};
            else if(id.rfind("manual_",0)==0||id.rfind("stop_",0)==0) {
                const bool stop=id.rfind("stop_",0)==0;int i=0;while(i<5 && c.icon!=ranges[i]) ++i;
                const float base=stop?420.f:288.f;
                c.bounds={base+(i<3?i*42.f:20.f+(i-3)*42.f),27.f+(i<3?0:29),38,24};
            } else if(id=="copy_all") c.bounds={552,27,106,22};
            else if(id=="copy_pan") c.bounds={552,55,106,22};
            else if(id=="paste_fill") c.bounds={552,83,81,22};
            else if(id=="paste_menu") c.bounds={637,83,21,22};
        }
    }
    l.headings={{"WRITE ENABLE",{148,7,124,14}},{"MANUAL WRITE",{288,7,122,14}},
        {"WRITE ON STOP",{420,7,122,14}},{"COPY / PASTE",{552,7,106,14}}};
    add("scope","ALL TRACKS",{288,115,238,18});add("settings","",{638,115,20,18},"gear");
    if(shallow) {
        // Translate the preview/capture pair and clipboard into independent groups.
        for(auto& c:l.controls) {
            auto& r=c.bounds;
            if(c.id=="suspend"||c.id=="join"||c.id=="match") continue;
            if(c.id=="preview"||c.id=="capture"||c.id=="preview_menu"||c.id=="punch_capture") {r.x+=140;r.y-=81;}
            else if(c.id=="scope") r={148,63,100,15};
            else if(c.id=="settings") r={262,62,20,18};
            else if(c.id=="plugin") r={288,27,58,22};
            else {
                int i=-1;for(int j=0;j<6;++j) if(c.id==ids[j]) i=j;
                if(i>=0) r={352.f+(i/2)*64.f,27.f+(i%2)*27.f,60,22};
                else if(c.id.rfind("manual_",0)==0||c.id.rfind("stop_",0)==0) r.x+=264;
                else if(c.id=="copy_all") r={816,27,62,22};
                else if(c.id=="copy_pan") r={882,27,64,22};
                else if(c.id=="paste_fill") r={816,55,105,22};
                else if(c.id=="paste_menu") r={925,55,21,22};
            }
        }
        l.headings={{"WRITE ENABLE",{288,7,256,14}},{"MANUAL WRITE",{552,7,122,14}},
            {"WRITE ON STOP",{684,7,122,14}},{"COPY / PASTE",{816,7,130,14}}};
    }
    return readable(l);
}
unsigned controlSection(const std::string& id) {
    if(id=="suspend") return SuspendSection;
    if(id.rfind("manual_",0)==0) return ManualWriteSection;
    if(id.rfind("stop_",0)==0) return WriteOnStopSection;
    if(id=="copy_all"||id=="copy_pan"||id=="paste_fill"||id=="paste_menu") return CopyPasteSection;
    for(const auto* group:{"plugin","vol","svol","pan","span","mute","smute"}) if(id==group) return WriteEnableSection;
    return 0;
}
static unsigned headingSection(const std::string& text) {
    if(text=="WRITE ENABLE") return WriteEnableSection;
    if(text=="MANUAL WRITE") return ManualWriteSection;
    if(text=="WRITE ON STOP") return WriteOnStopSection;
    if(text=="COPY / PASTE") return CopyPasteSection;
    return 0;
}
static bool sectionEnd(const std::string& id) {
    return id=="suspend"||id=="smute"||id=="manual_next"||id=="stop_next"||id=="punch_capture";
}
Layout applySectionVisibility(Layout l,unsigned sections) {
    sections&=AllSections;if(sections==AllSections) return l;
    l.controls.erase(std::remove_if(l.controls.begin(),l.controls.end(),[&](const Control& c) {const auto bit=controlSection(c.id);return bit&&!(sections&bit);}),l.controls.end());
    l.headings.erase(std::remove_if(l.headings.begin(),l.headings.end(),[&](const Heading& h) {return !(sections&headingSection(h.text));}),l.headings.end());
    if(l.singleLine) {
        float cursor=3;
        for(auto& c:l.controls) {
            if(l.horizontal) c.bounds.x=cursor;else c.bounds.y=cursor;
            cursor+=(l.horizontal?c.bounds.w:c.bounds.h)+3+(sectionEnd(c.id)?5:0);
        }
        if(l.horizontal) l.width=cursor;else l.height=cursor;
        return l;
    }
    // Repack whole sections while retaining each section's familiar internal arrangement.
    auto group=[](const Control& c) {
        const auto bit=controlSection(c.id);
        if(bit==SuspendSection) return 0;
        if(bit==WriteEnableSection) return 1;
        if(bit==ManualWriteSection) return 2;
        if(bit==WriteOnStopSection) return 3;
        if(bit==CopyPasteSection) return 5;
        return c.id=="scope"||c.id=="settings"?6:4;
    };
    float cursor=l.horizontal?12.f:11.f;
    float bottom=0;
    for(int index=0;index<7;++index) {
        // In horizontal layouts Suspend shares a column with Preview/Capture/Join/Match.
        if(l.horizontal&&index==4) continue;
        std::vector<Rect*> members;
        for(auto& c:l.controls) {
            const int which=group(c);
            if(which==index||(l.horizontal&&index==0&&which==4)) {
                if(l.horizontal&&index==6) c.bounds=c.id=="scope"?Rect{0,11,142,26}:Rect{148,11,26,26};
                members.push_back(&c.bounds);
            }
        }
        for(auto& h:l.headings) {
            const auto bit=headingSection(h.text);
            if((index==1&&bit==WriteEnableSection)||(index==2&&bit==ManualWriteSection)||(index==3&&bit==WriteOnStopSection)||(index==5&&bit==CopyPasteSection)) members.push_back(&h.bounds);
        }
        if(members.empty()) continue;
        float start=1e9f,end=0;
        for(auto* r:members) {start=std::min(start,l.horizontal?r->x:r->y);end=std::max(end,l.horizontal?r->x+r->w:r->y+r->h);}
        for(auto* r:members) {if(l.horizontal) r->x+=cursor-start;else r->y+=cursor-start;bottom=std::max(bottom,r->y+r->h);}
        cursor+=end-start+(l.horizontal?14.f:8.f);
    }
    if(l.horizontal) {l.width=cursor-2;l.height=bottom+11;}else l.height=cursor+3;
    return l;
}
Layout makeSingleLineLayout(bool horizontal,unsigned sections) {
    // Reuse the same identities, vector icons, commands and full tooltips.
    auto l=makeLayout(false);
    l.horizontal=horizontal;l.singleLine=true;l.headings.clear();
    float cursor=3;
    for(auto& c:l.controls) {
        float width=70;
        if(c.id=="plugin") width=64;
        else if(c.id=="vol"||c.id=="pan") width=38;
        else if(c.id=="svol"||c.id=="span"||c.id=="mute") width=44;
        else if(c.id=="smute") width=52;
        else if(c.id.rfind("manual_",0)==0||c.id.rfind("stop_",0)==0) width=48;
        else if(c.id=="join") width=74;
        else if(c.id=="match") width=84;
        else if(c.id=="preview") width=100;
        else if(c.id=="copy_all"||c.id=="copy_pan") width=72;
        else if(c.id=="paste_fill") width=112;
        else if(c.id=="scope") width=118;
        else if(!c.icon.empty()) width=26;
        if(!horizontal) {
            // Short labels keep a narrow column useful; full descriptions remain in tooltips.
            if(c.id=="paste_fill") c.label="FILL SEL";
            else if(c.id=="plugin") c.label="PLUG IN";
        }
        c.bounds=horizontal?Rect{cursor,3,width,28}:Rect{3,cursor,82,26};
        cursor+=(horizontal?width:26)+3;
        // Extra separation replaces the stacked section headings in a thin strip.
        if(sectionEnd(c.id)) cursor+=5;
    }
    l.width=horizontal?cursor:88;
    l.height=horizontal?34:cursor;
    return applySectionVisibility(std::move(l),sections);
}
static Layout dockFlow(bool horizontal,float width,float height,unsigned sections) {
    auto l=makeSingleLineLayout(horizontal,sections);
    l.dockFlow=true;
    const float gap=3,pad=3;
    float x=pad,y=pad,right=0,bottom=0;
    int lane=0;
    const int lanes=std::max(1,static_cast<int>(std::floor(((horizontal?height:width)-2*pad+gap)/(horizontal?31.f:85.f))));
    for(auto& c:l.controls) {
        auto& r=c.bounds;
        if(horizontal) {
            if(x>pad&&x+r.w+pad>width&&lane+1<lanes) {x=pad;y+=31;++lane;}
            r.x=x;r.y=y;x+=r.w+gap+(sectionEnd(c.id)?5:0);
        } else {
            if(y>pad&&y+r.h+pad>height&&lane+1<lanes) {y=pad;x+=85;++lane;}
            r.x=x;r.y=y;y+=r.h+gap+(sectionEnd(c.id)?5:0);
        }
        right=std::max(right,r.x+r.w);bottom=std::max(bottom,r.y+r.h);
    }
    l.width=right+pad;l.height=bottom+pad;l.singleLine=lane==0;
    return l;
}
Layout makeDockLayout(int side,float width,float height,float preferredScale,unsigned sections) {
    if(side<0) return applySectionVisibility(makeLayout(false),sections);
    const float scale=std::clamp(preferredScale,.5f,2.f);
    const bool horizontal=side==0||side==2||(side==4&&width>height*1.4f);
    return dockFlow(horizontal,width/scale,height/scale,sections);
}
PanelView makePanelView(int side,float width,float height,float preferredScale,unsigned sections) {
    width=std::max(1.f,width);height=std::max(1.f,height);
    PanelView view{makeDockLayout(side,width,height,preferredScale,sections),side<0?preferredScale:std::clamp(preferredScale,.5f,2.f),0,0,{0,0,width,height},{0,0,0,0},false};
    if(side>=0) {
        const bool horizontal=view.layout.horizontal;
        const float length=horizontal?view.layout.width:view.layout.height,available=horizontal?width:height;
        view.scrollable=length*view.scale>available+.5f;
        if(view.scrollable) {
            const float cross=horizontal?height:width;
            const float bar=std::max(1.f,std::round(std::min(3.f,cross*.16f)));
            if(horizontal) {view.viewport.h=std::max(1.f,height-bar);view.scrollbar={0,height-bar,width,bar};}
            else {view.viewport.w=std::max(1.f,width-bar);view.scrollbar={width-bar,0,bar,height};}
            view.layout=dockFlow(horizontal,view.viewport.w/view.scale,view.viewport.h/view.scale,sections);
        }
        // Docker dragging reveals/reflows controls. It never changes button size or centering.
    } else view.offsetX=std::max(0.f,(width-view.layout.width*view.scale)*.5f);
    return view;
}
}
