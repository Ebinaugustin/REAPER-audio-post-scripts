#pragma once
#include <string>
#include <vector>
#include "PanelModel.h"

namespace ea {
enum class ActionKind {Engine,Open,Close,Menu,Startup,Scale,Theme,Dock,Side,Undock,Section};
struct ActionDefinition {
    std::string id,title,command,toggle;
    ActionKind kind;
    int value=0;
};
// IDs are stable across releases, platforms and REAPER resource locations.
inline const std::vector<ActionDefinition>& actionCatalog() {
    static const auto actions=[] {
        std::vector<ActionDefinition> out;
        auto add=[&](const std::string& id,const std::string& title,const std::string& command="",const std::string& toggle="",ActionKind kind=ActionKind::Engine,int value=0) {
            out.push_back({"EA_NATIVE_AUTOMATION_"+id,"EA: Automation - "+title,command,toggle,kind,value});
        };
        add("OPEN","Open panel","","",ActionKind::Open);
        add("CLOSE","Close panel","","",ActionKind::Close);
        add("SUSPEND","Toggle Suspend (bypass envelopes)","suspend","suspended");
        const char* groups[]={"plugin","vol","svol","pan","span","mute","smute"};
        const char* ids[]={"PLUGIN","VOLUME","SEND_VOLUME","PAN","SEND_PAN","MUTE","SEND_MUTE"};
        const char* names[]={"plug-ins","track volume","send volume","track pan and ReaSurround","send pan","track mute","send mute"};
        for(int i=0;i<7;++i) add("WRITE_ENABLE_"+std::string(ids[i]),"Toggle Write Enable: "+std::string(names[i]),"group:"+std::string(groups[i]),"enabled_"+std::string(groups[i]));
        const char* ranges[]={"start","all","end","punch","next"};
        const char* rangeIds[]={"START","ALL","END","PUNCH","NEXT"};
        const char* rangeNames[]={"to range start","across selection / project range","to range end","from first touch / punch","to next breakpoint"};
        for(int i=0;i<5;++i) {
            add("WRITE_"+std::string(rangeIds[i]),"Manual write: "+std::string(rangeNames[i]),"write:"+std::string(ranges[i]));
            add("WRITE_ON_STOP_"+std::string(rangeIds[i]),"Toggle Write on Stop: "+std::string(rangeNames[i]),"onstop:"+std::string(ranges[i]),"onstop_"+std::string(ranges[i]));
        }
        add("AUTO_JOIN","Toggle Auto Join","join","join");
        add("AUTO_MATCH","Auto Match / clear preview latches","match");
        add("PREVIEW","Toggle Preview","preview","preview");
        add("PREVIEW_SUSPEND","Suspend / resume Preview (A/B)","preview_suspend","preview_suspended");
        add("PREVIEW_PUNCH","Punch preview values","punch_preview","punch");
        add("CAPTURE","Capture current values","capture","capture");
        add("CAPTURE_ALL","Capture all enabled values on all tracks","capture_all");
        add("CAPTURE_SELECTED","Capture enabled values on selected tracks","capture_selected","capture_selected");
        add("CAPTURE_PUNCH","Punch captured values","punch","punch");
        add("CAPTURE_CLEAR","Clear captured values","clear_capture");
        add("COPY_ALL","Copy all automation","copy:all");
        add("COPY_PAN","Copy pan automation (including ReaSurround)","copy:pan");
        add("COPY_ENABLED","Copy write-enabled automation","copy:enabled");
        for(int slot=1;slot<=10;++slot)
            add("COPY_SEND_"+std::to_string(slot),"Copy send "+std::to_string(slot)+" automation (volume / pan / mute)","copy:send:"+std::to_string(slot));
        add("PASTE_CURSOR","Paste automation at edit cursor","paste:cursor");
        add("PASTE_STRETCH","Paste automation: stretch to time selection","paste:fit");
        add("PASTE_FILL","Paste automation: repeat / fill time selection","paste:fill");
        add("SCOPE_ALL","Use all tracks","scope:all","scope=all");
        add("SCOPE_SELECTED","Use selected tracks","scope:selected","scope=selected");
        add("SCOPE_TOGGLE","Toggle all / selected track scope","scope_toggle","scope=selected");
        add("ITEMS","Toggle automation items for write / paste","items","items");
        add("STARTUP","Toggle Run at startup","","startup",ActionKind::Startup);
        const char* modes[]={"Trim / Read","Read","Touch","Write","Latch","Latch Preview"};
        for(int i=0;i<6;++i) add("MODE_"+std::to_string(i),"Set scoped automation mode: "+std::string(modes[i]),"mode:"+std::to_string(i),"mode="+std::to_string(i));
        for(int percent:{0,50,75,100,125,150,175,200})
            add("SIZE_"+std::to_string(percent),"Set panel size: "+(percent==0?std::string("Auto"):std::to_string(percent)+"%"),"","scale",ActionKind::Scale,percent);
        const char* themes[]={"reaper","graphite","silver","midnight","warm","classic"};
        const char* themeNames[]={"Follow REAPER","Graphite","Silver","Midnight","Warm graphite","Classic charcoal"};
        for(int i=0;i<6;++i) add("THEME_"+std::to_string(i),"Set panel style: "+std::string(themeNames[i]),themes[i],"theme",ActionKind::Theme);
        const char* sides[]={"bottom","left","top","right","floating Docker"};
        for(int i=0;i<5;++i) add("DOCK_SIDE_"+std::to_string(i),"Dock panel: "+std::string(sides[i]),"","side",ActionKind::Side,i);
        for(int i=0;i<16;++i) add("DOCKER_"+std::to_string(i+1),"Move panel to Docker "+std::to_string(i+1),"","dock",ActionKind::Dock,i);
        add("UNDOCK","Undock / float panel","","undock",ActionKind::Undock);
        add("MENU_PANEL","Show panel menu","context","",ActionKind::Menu);
        add("MENU_PREVIEW","Show Preview menu","preview_menu","",ActionKind::Menu);
        add("MENU_PASTE","Show Copy / Paste menu","paste_menu","",ActionKind::Menu);
        add("MENU_SETTINGS","Show settings menu","settings","",ActionKind::Menu);
        add("MENU_SCOPE","Show track-scope menu","scope","",ActionKind::Menu);
        for(const auto& section:sectionDefinitions())
            add("SHOW_"+std::string(section.id),"Show / hide section: "+std::string(section.label),"","section",ActionKind::Section,static_cast<int>(section.bit));
        add("SHOW_ALL_SECTIONS","Show all panel sections","","",ActionKind::Section,0);
        return out;
    }();
    return actions;
}
}
