# Native automation architecture

The interface and dedicated REAPER integration are compiled C++. The existing automation engine remains Lua and runs without a graphics window. This is a native extension with a Lua backend, rather than a complete C++ rewrite of the engine.

| Layer | Responsibility |
|---|---|
| `AutomationPanel` | JUCE drawing, six themes, vector icons, glass-style gradients, press feedback, cursor menus, Capture blinking, reflow and scrolling. |
| `PanelModel` | Platform-independent control/action identity and vertical/horizontal/shallow and single-row/single-column layout geometry. |
| `NativeWindow` | REAPER-compatible native dialog; embedded JUCE child; Win32, Cocoa/SWELL and GTK/X11 adapters; docking, floating-wrapper recreation on undock, monitor fitting and DPI adaptation. |
| `ReaperHost` | Validate imported APIs, register the native action and Lua bridge functions, saved dock/size preferences, startup, theme colours, main-thread message handling and extension teardown. |
| `NativeBridge` | Bounded FIFO of data commands and state publication. Close discards pending edits. No arbitrary code is evaluated. |
| `engine.lua` | Envelope matching, native/send/FX values, write gates, preview/capture/punch, manual/on-stop writes, copy/stretch/repeat, ReaSurround classification, existing-send matching and Undo. |

The native frontend never calls automation APIs from JUCE worker threads. Button callbacks queue commands; REAPER's deferred Lua engine executes them in its normal scripting context and publishes the resulting states. Native host/window calls run on REAPER's UI thread. Linux services JUCE's separate X11 event queue through a short, guarded REAPER timer.

Suspend snapshots envelope activation by project and envelope GUID, then bypasses existing track/master/take envelopes and newly encountered envelopes until released. The engine uses the activation attribute when available, with a precise state-chunk fallback. Manual Write commits values before leaving Preview. Selected-track Capture publishes a separate flag for the native blinking indicator and does not change persistent track scope.

Preview suspension retains a separate held-value snapshot while affected tracks audition automation in Read mode. Resume validates envelope pointers/GUIDs, restores Latch Preview and reapplies enabled held values. Manual Write uses that snapshot while paused. The native indicator distinguishes paused Preview from active green Preview. The Windows adapter defers monitor fitting until `WM_EXITSIZEMOVE`, using monitor overlap so a titlebar drag can cross DPI boundaries freely.

Normal close waits for the engine to restore preview/punch modes, arms and temporary protection before destroying the window. Extension removal makes the engine stop when its APIs disappear. REAPER shutdown also invokes the engine's exit handler. A running older panel blocks engine startup, preventing simultaneous automation-mode controllers.

Startup is an extension preference. The extension's first host timer opens the panel when enabled; no startup file is edited. The optional Lua launcher calls the native extension and opens it idempotently.

`ActionCatalog.h` defines 104 stable named actions. The native host registers each with `command_id` and `gaccel` in the Main section, dispatches them through the existing command bridge or native window/settings layer, and reports toolbar states through `toggleaction`. The original panel toggle keeps its prior ID. Engine actions requested before connection wait in a bounded queue; a host timer dispatches them once connected. Failed startup, close and shutdown discard that queue. Accelerator records and their description strings have stable storage until unregistration, including partial-registration failure cleanup. State-change caching prevents repeated toolbar refreshes for identical published state.

The host resolves the current accent from live `GetThemeColor` values using `ColorFromNative` on every platform. Enabled-toolbar text is preferred; coloured resize/selection highlights provide fallbacks. No theme files are rewritten or unpacked by the extension. All panel styles share the host accent; their background palettes remain selectable. A short UI timer detects theme-colour changes even when engine state is unchanged.

JUCE and REAPER's host APIs provide the shared core. Dock integration uses separate native adapters, so cross-platform source support does not imply identical window decorations or live verification on every platform. Linux currently requires X11 or XWayland, not a pure Wayland backend. There is no VST, AU or audio-processing component.

The native `visible_sections` bit mask persists five independent display sections. `PanelModel` filters controls/headings and repacks each layout; `NativeWindow` refits floating content. `makePanelView` enforces a readable dock scale independently of small floating presets and fits button geometry to the strip cross axis. Section actions and menus update native preferences only; no Lua automation command or global REAPER preference is changed.

Version 2.2.10 uses fixed-size dock flow. The viewport determines visible rows/columns; button dimensions/font scale do not depend on Docker dimensions. makePanelView reserves a slim scrollbar for primary-axis overflow and anchors content at the upper-left. Floating layouts remain separate. NativeWindow now handles WM_CONTEXTMENU delivered to its own native dialog and opens the same cursor-anchored menu as the JUCE panel; no shared REAPER window is hooked.

Version 2.2.11 removes the 100% dock floor. displayDockUiScale uses 75% for Auto and preserves every explicit preset. NativeWindow chooses this separately from floating monitor adaptation and reports compact WM_GETMINMAXINFO hints only while docked, converting logical dimensions to Win32 physical pixels when needed. No parent Docker bounds or user preferences are changed.

Version 2.2.12 draws faces, glyphs and icons directly at final component size, without an additional UI-scale graphics transform around text. Pixel density supplies geometry/baseline alignment and a minimum icon stroke. Font size has a legible lower bound independent of button geometry; measured label aliases replace horizontal compression at small sizes. The layout, hit testing and action identities are unchanged.

Version 2.2.13 embeds original narrow seven-row glyph masks in CompactPixelFont.h. Small presets measure labels using these same masks and draw solid physical-pixel cells without font filtering. Other text retains the platform-font path; unsupported glyphs fall back safely. No layout or action identities change.

Version 2.2.14 replaces the custom pixel font with cached Inter typefaces loaded from REAPER application resources. GetExePath is optional and font failure falls back to the platform family. Font resources remain in REAPER; no font files are distributed by this package. The Preview indicator paints from published state and the UI clock, with green active blinking, amber A/B suspension and dark off state; it does not generate bridge commands.

Version 2.2.15 removes the separate Preview lamp and its label-space reservation. The published active state drives alternating bright/dim green across the entire button face. Off and A/B-paused faces remain steady. The existing UI timer repaints; no bridge command or automation state change is generated.
