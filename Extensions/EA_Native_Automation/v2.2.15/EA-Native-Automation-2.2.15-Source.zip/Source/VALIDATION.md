# Version 2.2.15 Preview button checks

- Compiled the Windows extension and passed actual DLL mock-host/API/104-action registration and bridge checks.
- Production JUCE tests observe both bright/dim green phases across the whole Preview face. Matching samples on both sides verify no separate dot remains, including the previous dot position. Off and A/B-paused faces stay steady, and blinking queues no automation commands.
- Existing REAPER Inter font loading/fallback, geometry/presets, all section masks, actions/menus, Capture blink, modifiers, themes, feedback and queue-safety checks remain passing.
- All 104 engine-model scenarios / 1,393 core assertions and production command-loop checks passed. Lua only changes version markers and makes zero global-preference writes.
- No live REAPER process, project or preferences were modified. Live REAPER/LCD confirmation, native Docker flag/minimum behavior and macOS/Linux compilation/live checks remain pending. Earlier track volume/pan Manual Write reports remain separate known issues.

# Version 2.2.14 REAPER fonts and Preview indicator checks

- Read the locally installed Default_7.0 theme's font settings, confirming Inter and Inter Medium; no user theme/settings files were changed. Official REAPER 7.78 release notes also identify Inter as the new default theme family.
- Recompiled all five extension translation units, reusing eight unchanged pinned JUCE dependency objects. The actual Windows DLL passed mock-host API loading, 104-action registration/coverage and bridge safety tests.
- Production JUCE font checks load REAPER's actual Inter-Regular.ttf and Inter-Medium.ttf through a scratch application-folder fixture, verify the Inter family and lack of synthetic bold, and verify safe platform fallback with missing font files or a missing optional GetExePath API. Fixture font files are outside the distributable package.
- Native Preview lamp checks observe both bright and dim green phases, verify steady off and amber A/B states, and confirm no automation commands are queued by the indicator. Existing Preview/Capture modifiers, Capture blink, themes, press/cancel, menus, section masks, presets, scrolling and shortcut safety checks remain passing.
- The actual 300×20 1× output is included as Source/previews/REAPER-font-50-percent-1x.png. This does not claim a live LCD/REAPER test. Geometry/preset/action mapping checks continue to pass with unchanged compact button dimensions.
- All 104 engine-model scenarios / 1,393 core assertions and production command-loop checks passed; Lua only changes version markers and continues making zero global preference writes.
- No live REAPER process/project/preferences, OS fonts, display settings or theme files were modified. Native Docker flag/minimum behavior and macOS/Linux compilation/live checks remain pending. Earlier native track volume/pan Manual Write reports remain separate known issues.

# Version 2.2.13 pixel-typeface checks

- Recompiled all five extension translation units, reusing eight unchanged pinned JUCE dependency objects. The production Windows DLL passed mock-host API loading, 104-action registration/coverage and bridge safety tests.
- Glyph checks cover every standard control label, headings, digits and common punctuation; verify mask cells stay inside measured glyph bounds, lowercase maps consistently to uppercase, unsupported Unicode selects font fallback, and all standard horizontal labels fit in full at 50%.
- The actual JUCE component's unscaled 1× capture verifies exactly seven rows of foreground glyphs and no antialiased intermediate foreground cells on the compact AUTO JOIN label. Source/previews/Pixel-font-50-percent-1x.png is the actual 300×20 raster output. This does not claim a live LCD/display test.
- Existing geometry, fixed-size divider reveal, all section masks/presets, tooltips, original button/shortcut dispatch, menus, themes, press feedback, Preview/Capture state and startup/close safety checks remain passing.
- All 104 engine-model scenarios / 1,393 core assertions and production command-loop checks passed. Lua differs only in version markers and continues making zero global preference writes.
- No live REAPER process, project, preferences, display settings or OS fonts were changed. Windows live confirmation remains with the user; native Docker flag/minimum behavior and macOS/Linux compilation/live tests remain pending. Earlier track volume/pan Manual Write reports remain separate known issues.

# Version 2.2.12 compact rendering checks

- Recompiled all five native translation units, reusing eight unchanged pinned JUCE dependency objects. The actual Windows DLL passed mock-host API loading, 104-action registration/coverage and command bridge tests.
- Geometry checks retain exact compact button dimensions/presets, fixed-size divider reveal, all section masks and original commands. New checks verify minimum label font height and physical-pixel edge alignment at 1×, 1.25×, 1.5×, 1.75× and 2× OS densities.
- The actual production JUCE panel passed an unscaled 1× render check: a 50% compact label has at least six rows of bright glyph pixels and a solid foreground footprint in the existing 14-pixel button height. The native 300×20 capture is in Source/previews/LCD-50-percent-1x.png. This checks the raster output, without claiming a live LCD/display test.
- Existing native theme accent, green/paused Preview, press/cancel, Capture modifiers/blinking, menus, all visibility masks, scrolling, floating/docked hit testing, 104 actions and startup/close queue checks remain passing.
- All 104 engine scenarios / 1,393 core assertions and production command-loop checks passed; Lua only changes version markers and continues making zero global-preference writes.
- No live REAPER process, project, preferences, display settings or themes were modified. Actual LCD/REAPER confirmation remains with the user. Docker minimum/flag behavior and macOS/Linux compilation/live testing remain unverified here. Earlier native track volume/pan Manual Write reports remain separate known issues.

# Version 2.2.11 compact sizing checks

- Recompiled all five native translation units, reusing eight unchanged pinned JUCE dependency objects. The production Windows DLL passed mock-host API loading, 104-action registration/coverage and bridge checks.
- Geometry and production JUCE tests verify exact 50–200% scales, the compact 75% Auto default, unchanged button dimensions while dragging, all section masks, original action dispatch and existing theme/feedback/menu/shortcut checks. The reported eight-control 50% row fits 20 pixels of content height without overflow; native minimum geometry follows the selected preset. Actual component renders are included in Source/previews.
- Native minimum hints compile into the production dialog callback, but actual REAPER Docker/tab/flag constraints have not been exercised live. REAPER owns the shared Docker and other tabs may impose additional minimums.
- All 104 engine-model scenarios / 1,393 core assertions and production command-loop checks passed. Lua differs only by version markers and makes zero global preference writes.
- The live EA native preferences were read only to identify the saved 50% size and hidden sections; no live preferences, projects or REAPER process were modified. macOS/Linux compilation and live platform testing remain pending. Earlier native track volume/pan Manual Write reports remain separate known issues.

# Version 2.2.10 fixed-size Docker checks

- Recompiled all five native extension translation units with MSVC 19.44, reusing eight unchanged pinned JUCE dependency objects. The actual Windows DLL passed mock-host loading/API/104-action registration and command bridge tests.
- Geometry checks verify unchanged button dimensions through divider changes, all presets, all 32 section masks and all dock sides, no overlaps, fixed upper-left anchoring, progressive element reveal as viewports grow, additional rows/columns, original floating dimensions and original action mapping.
- The production JUCE component passed hit testing, tooltips and original action dispatch across single/multiple rows and columns, all size presets, every section mask, scrollbar/wheel access, first-control restoration after resizing, unchanged floating presets, section menus/actions, theme feedback and existing shortcut/queue safety checks. Source/previews contains renders of this exact component.
- All 104 engine-model scenarios / 1,393 core assertions and production native command-loop assertions passed; the Lua engine only changes version markers and continues making zero global-preference writes.
- Native WM_CONTEXTMENU handling is compiled into the production dialog callback. Actual REAPER-generated tab/flag messages, Docker dragging and monitor behavior have not been exercised in live REAPER and require the user's confirmation. The extension handles its own content window, without intercepting the shared REAPER Docker. Reference for forwarded content-window context handling: https://github.com/reaper-oss/sws/blob/master/sws_wnd.cpp
- No REAPER process/project/preferences were opened or modified by these checks. macOS/Linux compilation and live platform checks remain pending. Previous native track volume/pan Manual Write reports remain separate known issues.

# Version 2.2.9 readability and visibility checks

- Recompiled all five native extension translation units with MSVC 19.44, reusing eight unchanged pinned JUCE dependency objects. The actual Windows DLL passed mock-host loading, API registration, 104-action registration/coverage and bridge safety checks.
- Geometry checks cover five layouts and all 32 section combinations: retained identities, only requested controls removed, no overlap/out-of-bounds controls, closed gaps, original command mapping, exact floating presets, and docked minimum scale and cross-axis fitting at every preset.
- Production JUCE checks cover every compact tooltip/hit target and original action across dock sides/presets, all 32 visibility masks in a row and column, menu checkmarks, saved visibility, six visibility actions and toolbar states, invalid-setting fallback, and changing visibility without starting the engine or queuing automation commands. Existing theme/press/blink/modifier/scroll/shortcut tests remain passing. Native interface renders are in Source/previews.
- All 104 engine-model scenarios / 1,393 core assertions and the production Lua command-loop assertions passed, including zero writes to global envelope preferences. The engine differs from 2.2.8 only in version markers.
- No live REAPER process, user project or preferences were changed by these checks. Live REAPER docking/monitor testing remains with the user; macOS/Linux compilation and live platform testing remain pending. Previous native track volume/pan Manual Write reports remain separate known issues.

# Version 2.2.8 compact docking checks

- Recompiled all five extension translation units with MSVC 19.44, reusing eight unchanged pinned JUCE dependency objects. The actual Windows DLL passed mock-host loading, API/98-action registration, bridge and action tests.
- Layout checks cover all 30 controls in five layouts, no overlaps, unchanged identities/icons/tooltips/action mapping, automatic thin-dock selection on all four sides and floating Docker orientation, across every size preset from 50% to 200%.
- The production JUCE panel passed compact tooltip/hit testing and original action dispatch for every control at every preset, top/bottom/left/right/floating Docker orientations, draggable scrollbar endpoints, complete rows/columns without scrollbars, wheel/trackpad and Shift+wheel, and restoring normal hit targets after undocking. Existing theme accent, button feedback, modifier/blink, menu and shortcut tests also passed.
- Engine checks retain all 104 model scenarios / 1,393 core assertions plus production command-loop assertions, including zero global preference writes. This change only updates the Lua version marker; the automation behavior is unchanged from 2.2.7.
- Native interface renders are included in Source/previews. No REAPER process, user preferences or live project was opened or modified. Live REAPER docking confirmation is still the user's test; macOS/Linux compilation and live platform testing remain pending. Earlier native track volume/pan Manual Write reports remain separate known issues.

# Version 2.2.7 automatic-envelope preference checks

- Passed 104 engine-model scenarios / 1,393 core assertions, plus production native command-loop assertions. The complete test run and production commands make zero global-preference writes.
- New cases verify preserved initial enabled/disabled choices and unrelated flag bits, manual preference changes during repeated Write Enable protection, preservation after cleanup and Suspend, new-envelope gating without a preference change, and operation without SWS preference APIs.
- Existing send-copy, Preview synchronization, Manual Write and envelope-view checks remain passing. Retains the exact previously tested 2.2.5 native DLL and all 98 actions.
- No REAPER process or live user preferences were modified by these checks. Live REAPER confirmation remains the user's test; macOS/Linux compilation and live platform testing remain pending. Earlier native track volume/pan Manual Write reports remain separate known issues.

# Version 2.2.6 Preview synchronization checks

- Passed 98 engine-model scenarios / 1,350 core assertions, plus production native command-loop assertions. No REAPER process was opened or modified.
- New cases cover mixed original modes (including Write/Latch/Latch Preview), selected-track scope, Master, paused Preview, external mode/override changes, tracks added while Preview is active or paused, all-track A/B value restoration, selected-scope Manual Write and panel-close restoration.
- Production command-loop checks verify that both Preview command transitions publish the correct button state and change every track and Master, with no global override after Preview off.
- Retains the exact previously tested 2.2.5 Windows native DLL, its 98 actions and menu integration. This is a Lua engine hotfix within the native package.
- Live REAPER confirmation remains the user's test. macOS/Linux compilation and live platform tests remain pending. The earlier native volume/pan Manual Write and lane-visibility reports are not claimed resolved by this update.

# Version 2.2.5 send-copy checks

- Passed 92 engine-model scenarios / 1,194 core assertions, plus the production native command-loop checks. Includes separate slots 1–10, send volume/pan/mute, excluded hardware/other slots, existing-bus priority, unchanged routing, invalid command rejection and empty-slot clipboard clearing.
- Recompiled all five extension translation units with MSVC 19.44, reusing unchanged object files for pinned JUCE dependencies. No REAPER process was opened or modified.
- Passed the actual Windows DLL's mock-host load/API/action-registration test, 98-action coverage, layout/bridge checks and the production JUCE component checks. Both Copy/Paste and context menus contain exactly ten per-slot copy choices.
- Native command-loop checks dispatch Copy Send 1, reject invalid/combined commands, and verify that Copy Send 10 on an empty slot prevents pasting stale data.
- macOS/Linux sources are updated; compilation and live REAPER testing remain pending. Earlier native volume/pan Manual Write and envelope-visibility reports are not claimed fixed by this change.

# Validation of the delivered package

## Version 2.2.4 no-selection confirmation

- 87 engine scenarios / 1,096 core assertions plus the production command-loop check pass. Six new scenarios verify that the native OK/Cancel dialog appears before any Undo/edit, Cancel retains all original curves/views/Preview/Capture, OK fills the complete project range, existing selections avoid the alert, optional items and non-OK responses are handled, and other ranges/on-stop remain unchanged.
- The updated regression fixture run against the previous 2.2.3 engine fails because it writes four envelopes instead of cancelling without edits.
- All five CTest targets pass against the updated engine. The Windows native DLL is reused unchanged from 2.2.3; the confirmation uses REAPER’s cross-platform ShowMessageBox API. Installer tests verify the real new payload in scratch resource folders. No live REAPER session was controlled or modified here. macOS/Linux sources include the same engine update; those native targets remain uncompiled/unverified here.

## Version 2.2.3 visibility and version-menu checks

- 81 engine scenarios / 838 core assertions plus the production command-loop check pass. The previous engine fails the updated hidden-lane assertion.
- Regression scenarios cover All Tracks writes with hidden volume/pan and master lanes, inline versus separate lanes, visible lanes, hidden unrelated/bypassed envelopes, explicit Capture, write-on-stop, native action failure, deferred host exposure, no-latch Preview, one latched volume among many armed controls, the visibility-attribute fallback retaining fresh point data, Preview entry/A-B mode transitions and auto-created native lanes, and a repeated Manual Write after Preview ends.
- Actual JUCE context menus are inspected offscreen for a non-actionable version header in the main, settings, Preview and Paste menus, and for updates following the connected engine version. All five CTest targets and the production-host/UI fixture pass.
- The Windows x64 native extension is rebuilt for the menu change. macOS/Linux adapters use the same standard JUCE/Lua code but remain uncompiled/unverified here. Installer tests use scratch folders and its real embedded release payload.
- Read-only inspection of the installed engine receipt and latest ManualWrite diagnostic confirmed v2.2.2 and a verified held curve. Source inspection found that the common envelope preparation helper explicitly requested VISIBLE=1 during writes. No live REAPER project, track visibility or automation was changed here.

## Version 2.2.2 engine hotfix

- 70 engine scenarios / 500 core assertions plus the production command-loop check pass. The fixture now applies PT records when loading envelope chunks, rather than silently retaining stale points.
- New checks simulate a native write-buffer flush on Preview exit, native cursor-only dips/no-ops, delayed overwrite detection, attribute-only lane activation, and optional item writes. They verify the full held range and original outside values, no duplicated guards and balanced Undo. The previous 2.2.1 engine fails the Preview-exit flush regression.
- These are simulated failure conditions; the exact live host cause of the user’s dip is not yet confirmed. The delivered engine records the requested range, source/held values, UI flags, current modes, samples and nearby points to ManualWrite-diagnostics.txt after a real Manual Write. Only the latest operation is retained; no media or full FX/project state is logged.
- The native C++ sources and compiled Windows DLL are unchanged from 2.2.1. All five CTest targets pass with this updated engine fixture, and the updated installer is checked using its real embedded payload in scratch directories. The actual user REAPER project has not been controlled or modified here.
- macOS/Linux use the same engine source update; their native build kits remain uncompiled/unverified here.

## Version 2.2.1 Manual Write checks

- Lua engine model: 65 scenarios / 426 core assertions plus the production command-loop check. Seven new scenarios model host-internal latch values independently from UI/stored trim reads and verify volume, normal pan, send pan and ReaSurround commits throughout each interval.
- Ran the new regression fixture against the previous v2.2 engine: it fails on the held value (expected 0.42, old path writes 1.96); the updated engine passes. This checks the code-path change, not a live reproduction.
- Verified all five write ranges, protected/unarmed envelopes, unselected tracks, per-envelope punch/next ranges, restoration after native action failure, whole-project writes with no original time selection, and separate automation-item/Capture paths.
- Built the Windows x64 extension and ran all five CTest targets. Installer tests use its actual embedded release payload and scratch resource folders only.
- The native command and its workflow were checked against REAPER’s SDK and official user guide. The reported host behavior has not been reproduced in a live REAPER session here; this release switches the live commit to the native path the user reports working. Live validation remains for the user. macOS/Linux sources include the same engine fix but remain uncompiled/unverified here.

## Version 2.2 shortcut-action checks

- Compiled the updated Windows x64 extension with the local Microsoft toolchain described below. All five CTest targets passed: panel layouts, native bridge, action catalogue, actual DLL registration/unload and Lua engine model.
- Verified 88 unique stable action IDs covering every panel control, modifier operation, menu and setting. The actual DLL registers all 88 plus the original panel toggle in the Main section, with correct descriptions. Partial-registration failure unregisters every previously added accelerator/API; normal unload also removes all entries. Unknown REAPER actions are not consumed.
- Verified startup, size and style actions and their toggle/radio states with the panel closed in the DLL fixture.
- Passed the offscreen production-host/UI integration check for every engine action's exact command, single engine startup for multiple waiting shortcuts, ordered dispatch after connection, no replay on subsequent ticks, close/failed-startup cancellation and toolbar refreshes only when state changes. Engine state, track-scope radio states and mixed-mode clearing are checked.
- The production headless Lua loop also checks persistent scope-toggle commands and integer mode publication when the host returns a floating-point automation mode. The retained automation model still passes 58 tests / 290 core assertions.
- Rechecked Lua syntax and Windows DLL imports. Only Windows system libraries are required; there is no separate JUCE or Visual C++ runtime DLL dependency.

These are automated checks against a host model and the production binary/component. No REAPER session was opened. Assigning and using shortcuts inside your actual REAPER installation remains a live host check. macOS/Linux source adapters and build kits are updated but remain uncompiled/unverified here.

## Completed locally on Windows x64

- Compiled the production extension with Microsoft C/C++ 19.44.35229, Windows SDK 10.0.26100.0, JUCE 8.0.12 and CMake 4.4. Release build, static C/C++ runtime.
- Loaded the resulting DLL in a separate mock-host executable. Confirmed the exported `ReaperPluginEntry`, required-host-API validation, native action and four Lua bridge APIs, engine-action dispatch, duplicate-open protection and complete unregistering on unload. No REAPER process was opened.
- Checked the DLL's imports: Windows system libraries only; no separate JUCE or Visual C++ runtime DLL is needed by this build.
- Passed layout/action tests for all 30 controls in vertical, horizontal and shallow layouts, including bounds, overlap, larger write-button targets and automatic scale limits.
- Passed bridge tests for FIFO ordering, state parsing, bounded capacity and close discarding queued edits.
- Passed 58 automation-engine model tests / 290 core assertions. These cover automation writing/scaling, pan polarity, copy/stretch/repeat boundaries, compacted points, cross-track native envelopes, existing-send matching, ReaSurround classification and cleanup. New cases verify all-track/take envelope bypass, envelopes added during Suspend, restoration of previously bypassed envelopes, activation-attribute fallback, selected-track Capture without changing scope, unarmed envelope capture and Manual Write exiting Preview only after a successful write. Preview A/B tests cover Read-mode auditioning without point writes, held-value restoration, Manual Write from paused Preview, deleted-envelope handling, latch clearing and cleanup restoring original modes.
- Passed the production headless command-loop test: engine connect, Preview/write/copy/paste/settings commands, state publication, close, restored modes, balanced Undo and idempotent cleanup.
- Passed an offscreen test of the actual production JUCE component. Confirmed glass-style drawing, green Preview, visible pressed feedback, release-triggered actions, cancellation when dragging off a button, Capture modifier commands and timed blinking, cursor menu anchoring including negative screen coordinates, saved size preferences, 50–200% presets and correct click targets in horizontal, shallow and scrolling dock layouts. The `previews` PNGs are actual JUCE renders, not generated design concepts.
- Checked Lua syntax for the engine and launcher.
- Version 2.1.1 checks also cover the live enabled-toolbar accent, green-to-purple changes without reopening the panel in all six styles, neutral-toolbar highlight fallback, missing-token selection fallback and monochrome/no-token themes, plus Ctrl-click Preview command dispatch and its paused visual indicator. The green and purple `reaper` previews use real colours from installed REAPER themes in the mock host; no live theme was changed.

## Still requires platform / host testing

The macOS universal and Linux x64 targets have source adapters, dependency declarations and CI build configurations, but have not been compiled or run here. Linux's native adapter requires GTK 3 and X11/XWayland. The remote GitHub workflow has not been executed.

The DLL load test and offscreen component checks do not validate REAPER's live Docker handling, undocking visibility, monitor/DPI transitions, automation playback, project state chunks or plug-in behaviour. The undocking and deferred monitor-fitting changes compile, but dragging from a secondary to a primary monitor needs your live REAPER check. Preview A/B behaviour also needs an audition with actual native/send/FX automation. As requested, no REAPER session was opened for testing. Start with a duplicate test project, especially for Suspend/restoration, Manual Write, send automation and repeat/fill boundaries.

The implementation is a native JUCE/C++ interface and integration layer with a headless Lua automation engine. It is not a complete C++ rewrite of the automation logic.
