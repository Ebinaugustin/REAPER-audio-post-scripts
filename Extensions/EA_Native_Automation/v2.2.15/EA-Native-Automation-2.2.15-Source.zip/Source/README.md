# EA Native Automation 2.2.15

**REAPER 7 lettering and Preview lamp:** the panel now loads Inter/Inter Medium from REAPER’s own font files. The custom pixel typeface has been removed. The whole Preview button blinks green while active; the separate dot has been removed.

**Compact pixel lettering:** 50% and 75% use a narrow embedded pixel typeface with solid single-pixel strokes. Buttons retain the same size, and standard horizontal labels fit in full at 50% on a 1× display.

**Sharper compact labels:** 50% keeps the same button footprint, with text rendered at the final display size rather than reduced to a six-pixel font. Short names fit the small buttons; tooltips retain full descriptions.

**Compact dock sizing restored:** explicit 50% and 75% presets work again. Auto uses a compact 75% dock toolbar; the floating Auto size still follows the monitor.

**Dock resizing reveals controls instead of changing their size.** Thin top/bottom docks use a fixed-size row, while left/right docks use a column. Dragging the divider exposes additional rows or columns. The toolbar starts at the upper-left corner; it does not grow, shrink or center itself as the Docker changes.

A compact JUCE/C++ automation panel for REAPER, with a dedicated native host integration layer. The automation engine remains a headless Lua script so the envelope, send matching and Manual Write fixes are retained. This is a native extension with a Lua backend.

## Install the Windows x64 package

1. Disable **Run at startup** in the older standalone panel if it was enabled, then close that panel. In REAPER choose **Options → Show REAPER resource path in explorer/finder**.
2. Exit REAPER. Copy the package's `UserPlugins` contents into that resource folder's `UserPlugins` folder. When upgrading, replace **both** the DLL and `EA_Native_Automation/engine.lua`. Keep the engine in its subfolder next to the DLL. Do not create a second nested `UserPlugins` folder.
3. Restart REAPER. Run **EA: Native Automation (JUCE) - toggle panel** from the Actions list.
4. Optional: load `Scripts/EA_Compact_Automation.lua` through **Actions → New action → Load ReaScript** as a launcher. It requires the extension; it is not the previous standalone script.

Use the gear menu to enable **Run at startup**. The extension opens the panel on subsequent REAPER starts without editing a startup script. The gear also switches automation items on/off. The default is ordinary envelope points; an existing saved preference from the older engine is retained.

The installed paths must look like this:

```text
REAPER resource folder/
  UserPlugins/
    reaper_ea_automation.dll
    EA_Native_Automation/
      engine.lua
```

The original standalone Lua deliverable is a separate fallback. Close one panel before opening the other. Copy buffers and capture snapshots are session data and are cleared when the panel closes.

## Keyboard shortcuts and toolbar actions

Version 2.2.15 registers **104 individual actions** alongside the existing panel toggle. They appear automatically when REAPER loads the extension; no separate action scripts need importing.

In **Actions → Show action list**, choose the **Main** section and search **EA: Automation**. Select an action, then use **Add** in the shortcut area to assign a key. The entries also work in REAPER custom actions and toolbars. Existing shortcuts for **EA: Native Automation (JUCE) - toggle panel** are preserved.

Actions include every Write Enable category, five Manual Write ranges, five Write on Stop modes, Suspend, Preview, Preview A/B suspension, all Capture variants, punch, Auto Match/Join, copy/paste/fill/stretch, track scope and automation modes. Panel menus, Docker placement, undocking, style, size and Run at startup are available too. Modifier-click commands have separate actions, so their shortcuts can be assigned directly. Full names and stable command IDs are listed in `ACTIONS.md`.

Automation actions open the panel automatically if it is closed, wait for its engine to connect, then run in order. Settings actions can save size, style or startup preferences without opening it. Closing the panel or failing to start the engine discards pending edits. An action triggered while the engine is closing is ignored; invoke it again after cleanup finishes.

Toggle actions reflect engine state in the Actions list and toolbars while the panel is running. Size/style/startup preferences also report their saved state while closed. The automation-mode radio state is clear for mixed modes or an active global override. Shared clipboards and Capture values last only while the panel remains open.

## Window and themes

The 100% floating content is 220 × 730 logical pixels, with larger labels, section headings and write buttons. **Size → Auto** is the default: it adapts to the current monitor's work area and OS display scaling, including when the floating window moves between monitors. Right-click offers 50%, 75%, 100%, 125%, 150%, 175% and 200%; this preference is saved. Floating windows retain a fixed size and fit inside the monitor's work area. On very small displays, use the mouse wheel to reach overflowing controls.

Left/right docks use a vertical layout; top/bottom docks use horizontal layouts. Thin docks automatically reflow every control into one horizontal row or one vertical column. Wider docks restore the familiar grouped layouts. Docked content adapts to the available space and chosen size. When a Docker is too small to display every control legibly, the mouse wheel scrolls the overflow. Undocking rebuilds the native floating wrapper and restores a visible position within the monitor. On Windows, monitor fitting/scaling waits until a titlebar drag finishes, so it does not snap the panel back to the previous monitor. The destination monitor is chosen from the largest window overlap. OS titlebars vary by platform.

Right-click for docking, Docker 1–16, size, themes, automation mode, track scope and settings. Menus open at the mouse cursor. A side command selects an existing Docker assigned to that side. If no Docker occupies that side, assign one using REAPER's native Docker tab menu first. The host API does not expose a supported command to relocate an arbitrary Docker.

Panel styles: Follow REAPER, Graphite, Silver, Midnight, Warm graphite and Classic charcoal. **Active buttons follow the current REAPER accent in every style.** The panel first uses the theme's enabled-toolbar colour, then a coloured resize/selection highlight when toolbar colours are neutral. Entirely monochrome themes retain neutral buttons; there is no fixed blue fallback. Colour changes are detected while the panel is open. The enabled-toolbar and highlight tokens come from [REAPER's theme-colour API](https://www.reaper.fm/sdk/reascript/reascripthelp.html#GetThemeColor); a theme's image-only colours are not exposed through this API.

Follow REAPER also reads REAPER's background colour and derives a contrasting panel palette; it does not copy every image asset from a REAPER theme. Icons are vector-drawn and scale with labels. Rounded buttons have a glass-style sheen, highlighted edges, pressed displacement and a brief release flash. This is drawn styling, without OS background blur. Active labels contrast with the button colour. Preview lights green and selected-track Capture blinks amber as status indicators.

## Automation controls

- Write Enable gates plug-in, track volume/pan/mute and send volume/pan/mute. PAN includes all ReaSurround/ReaSurroundPan automation; there is no OBJ/BUS gate.
- Suspend bypasses all existing track, master and take envelopes, independently of track scope and Write Enable. It also prevents automation writing. Newly created envelopes are bypassed while Suspend remains on. Releasing Suspend or closing the panel restores each envelope's previous activation and the previous global override; points are preserved.
- Manual Write and Write on Stop provide start, whole range, end, punch and next ranges. Start/all/end use the time selection when present, otherwise the project range. Punch uses the first-touch/punch position and next writes up to the next automation point; hover for details.
- A successful Manual Write switches Preview off and returns global automation to **No global override / per-track**. A write with no valid destination/range leaves Preview available so the values are not discarded. Write on Stop retains its separate behaviour.
- Preview, Capture, punch, Auto Match and Auto Join use the existing engine. Turning Preview off sets global automation to **No global override / per-track**.
- **Ctrl-click Preview on Windows/Linux, or Cmd-click on macOS**, suspends/resumes Preview for A/B comparison. This follows the [Pro Tools Preview-suspension shortcut](https://resources.avid.com/SupportFiles/PT/Pro_Tools_Reference_Guide_12.8.2.pdf). The panel keeps held preview values, sets previewed tracks to Read while auditioning existing envelopes and restores the held values on resume. The button displays **PREVIEW PAUSED** in muted amber. The Preview dropdown also offers Suspend/Resume. Ordinary clicking still turns Preview off. Manual Write from paused Preview commits the held values and exits Preview after a successful write; punching is blocked until Preview resumes. Clearing latches discards the held values.
- **Ctrl-click Capture on Windows/Linux, or Cmd-click on macOS**, captures values from selected tracks and makes Capture blink. This is the requested custom shortcut. **Alt/Option-click** captures all tracks; **Alt/Option + Shift-click** also captures selected tracks, matching the modifier pattern in the [Avid Pro Tools reference guide](https://resources.avid.com/SupportFiles/attach/Pro_Tools/10.0/ENGLISH/Pro_Tools_Reference_Guide.pdf). These shortcuts capture existing envelopes in enabled parameter categories, including unarmed envelopes; they do not expose every possible plug-in parameter. The selected-track shortcut leaves the panel's normal track scope unchanged. Ordinary Capture uses the current scope and armed controls, and its indicator is steady.
- Copy All and Copy Pan work across tracks. The paste menu offers cursor paste, stretch to selection and repeat/fill to selection. Ordinary points are the default. Flat values are reduced and repeat boundaries are held without a connecting ramp.
- Native envelopes are matched by parameter, and matching envelopes can be exposed on the destination. Send automation uses existing sends only: bus/channel first, then an unused matching send slot. No sends or routing are created. Missing destinations are reported only when parameters cannot be matched.

This panel recreates the reference control arrangement with added copy/paste/settings controls. Pro Tools-specific automation behaviours are implemented through the capabilities of REAPER and the existing engine; the integration does not add an Atmos workflow.

## Cross-platform source builds

Required: CMake 3.24+, a supported C++17 compiler, network access for the pinned dependencies (or the supplied offline source bundles), and 64-bit REAPER. The Windows binary targets Windows 10/11 x64. JUCE 8.0.12, REAPER SDK and Cockos WDL revisions are pinned in `CMakeLists.txt`. A REAPER installation is not required to compile.

**Windows:** Visual Studio 2022 Build Tools with Desktop development with C++ and a Windows SDK. In a developer terminal:

```powershell
cmake -S . -B build -A x64 -DCMAKE_MSVC_RUNTIME_LIBRARY=MultiThreaded
cmake --build build --config Release --parallel 2
ctest --test-dir build -C Release --output-on-failure
cmake --install build --config Release --prefix stage --component EA
```

**macOS:** Xcode command-line tools. Build a universal Intel/Apple Silicon extension:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release '-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64' -DCMAKE_OSX_DEPLOYMENT_TARGET=10.15
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
cmake --install build --prefix stage --component EA
```

**Linux:** GCC or Clang; development packages for GTK 3, X11, Xext, Xinerama, Xrandr, Xcursor, FreeType and Fontconfig. The window adapter requires REAPER's GTK/X11 or XWayland backend; pure Wayland is not supported. Install Lua 5.3/5.4 to run the engine model tests.

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
ctest --test-dir build --output-on-failure
cmake --install build --prefix stage --component EA
```

Copy the resulting `stage/UserPlugins` contents to the REAPER resource folder. Matching architecture is required. No installer modifies REAPER automatically. Windows uses `.dll`, macOS `.dylib`, Linux `.so`.

For an offline build, extract the three archives in `vendor` into separate folders and set `FETCHCONTENT_SOURCE_DIR_JUCE`, `FETCHCONTENT_SOURCE_DIR_REAPER_SDK` and `FETCHCONTENT_SOURCE_DIR_WDL` to their absolute paths when configuring. These archives contain the exact upstream source revisions used by this package.

The included GitHub workflow describes Windows x64, macOS universal and Linux x64 builds. It has not been run remotely. Check `VALIDATION.md` for what was actually compiled and tested. You will perform the live REAPER automation/docking tests.

For the optional Windows offscreen panel test and rendered theme previews, configure with `-DEA_BUILD_UI_TESTS=ON`. This test paints the production JUCE component without opening a window or REAPER, and checks button feedback, green Preview, Capture modifiers/blinking, cursor menu anchoring, size presets, mouse release/cancel behaviour and dock layout hit testing.

## Source and licence

The new native package is supplied with corresponding source under AGPL-3.0-or-later, using JUCE's open-source licensing option. JUCE also offers a commercial licence. Upstream source notices and licences are retained; see `THIRD-PARTY-NOTICES.md` and `LICENSE.txt`.

## Manual Write update in 2.2.1

Live Manual Write commits REAPER’s internal latched values with native action 42013 over the range chosen by the button. This avoids deriving native track/send envelope values from combined UI/trim reads. Only enabled, armed, actively writing envelopes in the panel scope participate. Automation items remain optional; captured, paused Preview and write-on-stop snapshots keep their explicit point path. A flat hold normally needs only its boundary points.

## Manual Write engine hotfix in 2.2.2

Manual Write finishes Preview before installing its final curve, then checks the complete hold after a host update. A successful status says **Verified … envelopes; Preview off**. If the curve changes afterwards, the status reports a verification failure and the latest operation is saved to `UserPlugins/EA_Native_Automation/ManualWrite-diagnostics.txt` for diagnosis. No additional import or setup is needed. The 2.2.2 engine-only hotfix reused the 2.2.1 native DLL; 2.2.3 rebuilds the DLL for the menu update.

## Lane visibility and version in 2.2.3

Writes preserve existing envelope visibility and inline/separate-lane placement. Manual writes require latched/touched controls or an explicit Capture; an empty Preview or repeated click after Preview ends does not target every armed envelope. Right-click the panel to see the running engine version in the menu header.

This update preserves your current layout. To close lanes already opened by an older version, select the affected tracks and run REAPER’s **Envelope: Hide all envelopes for tracks** action once. It hides lanes; your automation points remain.

## No time selection — version 2.2.4

The middle Manual Write button and **EA: Automation - Manual write: across selection / project range** now warn when there is no time selection. **OK** proceeds across the entire session; **Cancel** retains the current automation, Preview and Capture values. A valid time selection writes directly. Existing shortcut assignments still work. This engine update reuses the 2.2.3 native DLL.

## Copy individual send slots — version 2.2.5

Open the Copy/Paste dropdown (beside Fill Selection), or right-click the panel, then choose **Copy send automation → Copy send 1 automation** through **Copy send 10 automation**. These are separate commands; there is no combined first-ten copy command.

Select the source track(s), optionally set a time selection, then choose the send slot to copy. Without a time selection the existing copy command's source/project-range behaviour applies. Each command copies existing volume, pan and mute envelopes for that normal send slot, independently of Write Enable gates. Hardware outputs, other send slots, track envelopes and FX automation are excluded. A slot without any automation clears the previous clipboard and shows a status message, so a later paste cannot silently reuse old data.

Select the destination track(s) and use the existing cursor paste, stretch-to-selection or repeat/fill command. Existing destination sends are matched by bus/channel first, then an available matching send slot. No routing or sends are created. Missing destination parameters use the existing unmatched-envelope dialog.

Each command is also an action: search **EA: Automation - Copy send** in REAPER's Main Actions list and assign the keys you want. There are now 98 individual actions plus the original panel toggle. Existing command IDs and shortcut assignments are preserved. Replace both the native DLL and engine, then restart REAPER to register the new actions.

The previous native track volume/pan Manual Write and lane-visibility reports still require live confirmation. This update adds send-copy commands; it does not claim to resolve those separate reports.

## Preview drives every track — version 2.2.6

The Preview button now controls automation modes across the entire current project, including Master, regardless of the panel's track scope. **Preview on → all tracks Latch Preview. Preview off → all tracks Read.** The global override is set to **No global override / per-track** at both transitions. Turning Preview off does not restore pre-existing Write, Latch or Latch Preview modes.

Tracks added while Preview is active join Latch Preview; tracks added during A/B suspension stay Read until Preview resumes. Preview A/B switches all tracks between Read and Latch Preview and preserves held values across the session. Manual Write still obeys the chosen track scope, including when writing held values from suspended Preview.

Envelope visibility remains protected during mode transitions. Closing the panel while Preview remains active retains the existing cleanup behaviour of restoring the pre-Preview modes and override. Explicitly turning Preview off first leaves all tracks Read.

This engine-only update retains the 2.2.5 native DLL, all 98 actions and the ten separate send-copy commands. The connected engine version in the right-click menu is 2.2.6. The previous native track volume/pan Manual Write reports remain separate known issues requiring live confirmation.

## Preserve automatic-envelope preferences — version 2.2.7

The engine no longer changes REAPER's **Automatically add envelopes when tweaking parameters in automation write modes** preference. Earlier versions temporarily cleared it whenever any Write Enable group was protected or Suspend was active. The repeated guard pass could override a user change, and cleanup could restore a stale value.

Version 2.2.7 removes those preference writes entirely, including cleanup. Your enabled or disabled choice and unrelated preference flags are preserved when using Write Enable, Suspend, Preview, changing scope or closing the panel. If the option is already unticked after upgrading and restarting REAPER, enable it once if that is your preference; the engine leaves it alone.

Write Enable continues to protect envelopes through arming. Newly created protected envelopes are disarmed on the next guard pass; automatic creation itself follows your REAPER setting. Suspend continues to use envelope bypass and the existing global automation bypass.

This engine-only hotfix retains the tested 2.2.5 native DLL, 98 actions, Send 1–10 copy commands and the all-track Preview synchronization from 2.2.6. The connected version shown by the menu is 2.2.7.

## Single-row and single-column docking — version 2.2.8

As you resize a top/bottom dock to a thin strip, all 30 controls move onto one row. A narrow left/right dock becomes one column. Floating Docker containers choose orientation from their proportions. Expanding the dock restores the grouped layouts; the undocked window retains its original arrangement. The thresholds follow the saved size preset and automatic display scaling.

The compact buttons retain their original actions, theme colours, press feedback, green Preview, Capture blinking, modifier clicks, menus and full tooltips. Small **W** and **S** badges distinguish Manual Write from Write on Stop while retaining the range icons. Narrow columns shorten a few labels, such as **FILL SEL**, without changing their actions. Scope status messages remain available in the scope button tooltip.

If the available strip is shorter than all the controls, use the mouse wheel, a trackpad, or the small scrollbar to reach either end. Horizontal strips accept both horizontal trackpad scrolling and Shift+wheel. Overflow scrolls along the strip; it never wraps into a second row or column. Icons scale to fit their buttons.

Replace both the native extension and engine and restart REAPER. This build retains all 98 stable shortcut actions, the Preview and Send 1–10 improvements, and the 2.2.7 automatic-envelope preference fix. Windows is compiled; macOS/Linux contain the same updated shared source and build kits, with compilation and live platform testing pending.

## Readable docks and show/hide sections — version 2.2.9 (docking growth superseded below)

Docked controls now have a minimum text/icon scale of 100%. A saved 50% or 75% floating-window preset no longer produces tiny docked buttons. Floating windows still use the exact chosen size. Larger presets remain available for docks. Single rows and columns expand into spare space on the short axis; when possible, the entire strip fits without shrinking below the readable minimum. Otherwise use the scrollbar, wheel or trackpad. Extremely thin containers still constrain the actual button height or width; controls abbreviate narrow labels and retain full tooltips.

Right-click the panel or use the settings gear, then choose **Show sections**. Toggle **Suspend**, **Write Enable**, **Manual Write**, **Write on Stop**, or **Copy / Paste** independently. **Show all sections** restores the complete interface. Choices persist across restarts and apply to both floating and docked layouts. Hidden controls and their headings are removed from the layout and hit testing; remaining sections close up the gaps. The floating wrapper also resizes to its new content height.

These are display preferences only: hiding a section does not change Write Enable, Suspend, write-on-stop, Preview or any automation values. Existing button actions stay available in REAPER's Actions list even when hidden. Preview, Capture, Auto Join/Match, track scope and settings remain accessible.

Six additional shortcut actions show/hide the five sections or show all sections, bringing the total to **104 individual actions plus the original panel toggle**. Search **EA: Automation - Show** in the Main Actions list and assign your own keys. Their toolbar states follow saved visibility, including with the engine closed. No default keys are assigned.

Install the matching native extension and engine, then restart REAPER. The automation engine only has its version marker changed from 2.2.8; the previous Preview, send-copy and automatic-envelope preference fixes are retained. Windows is compiled and checked here; macOS/Linux share the updated source but their builds and live platform tests remain pending.

## Fixed-size Docker reveal and native context menu — version 2.2.10

This replaces 2.2.9's automatic button growth. At 100%, horizontal toolbar buttons are 28 logical pixels high; vertical buttons are 26 high. Dragging a divider never changes those dimensions or the label font. Thin docks retain a single row/column. More room reveals/reflows additional controls into more rows or columns, preserving their order and actions. Overflow remains available with the slim scrollbar, wheel or trackpad. Resizing returns to the first controls rather than leaving a stale scroll offset halfway through the toolbar.

The selected size preset is stable while resizing. The existing dock minimum of 100% prevents 50%/75% floating presets from making docked text tiny; larger presets enlarge the toolbar only when explicitly selected. Floating layout and sizing remain unchanged.

Right-click context requests delivered to the native content window are now routed to the panel menu, including requests REAPER forwards from its tab/native wrapper. Panel right-click and the settings gear remain available. The extension does not subclass or replace REAPER's shared Docker/flag window. Actual REAPER tab/flag behavior needs live confirmation; the prior implementation ignored the native WM_CONTEXTMENU request entirely.

The five saved Show sections choices and all 104 individual shortcut actions are retained. Hidden sections compact the flow; changing visibility does not change automation settings. Replace the native DLL and matching engine and restart REAPER. Windows is compiled and checked here; macOS/Linux contain updated shared source/build kits, with compilation and live platform testing pending.

## Compact dock size restored — version 2.2.11

The forced 100% dock minimum from 2.2.9–2.2.10 has been removed. A saved 50% preset now gives 14-pixel horizontal buttons instead of 28; 75% gives 21 pixels. All explicit presets apply exactly, and Auto now uses a fixed 75% compact default while docked. Floating Auto sizing continues to adapt to the monitor. OS display scaling still applies normally.

Dragging the Docker divider reveals more controls without changing their size. Section visibility and all 104 actions are retained. The native wrapper now reports small docking minimum-size hints at the selected preset, so the extension itself does not request a large content area. At 50%, a horizontal row requests a minimum content height of 17 logical pixels; a side column requests 44 pixels of content width.

Install and restart REAPER, then drag the Docker divider to the thinner height/width you want. The extension does not resize REAPER's shared Docker or change other tabs; REAPER controls the actual outer container, tab bar and any minimum imposed by other docked panels. Your saved size and visible sections remain unchanged. Choose another preset from right-click → Window size when desired.

The Lua automation behavior remains unchanged from 2.2.10. Native tab context-menu handling, the Preview/send-copy/preference fixes and fixed-size flow remain included. Live Docker minimum/flag behavior requires user confirmation. Windows is compiled here; macOS/Linux include shared source/build kits and remain uncompiled/unverified here.

## Sharper 50% rendering — version 2.2.12

The old renderer scaled a 12-pixel label font down to six pixels at 50%, and fitted text could be compressed further to fit its button. The new renderer draws directly at the final display size, aligns button edges and text baselines to the physical pixel grid, and uses a minimum 10-logical-pixel label font. This preserves the compact 14-pixel horizontal button height at 50%.

Where full names do not fit, compact labels such as **JOIN**, **MATCH**, **CAPT** and **FILL SEL** replace font compression. Full descriptions remain in tooltips and the Actions list; commands and shortcut IDs are unchanged. Wider buttons retain their full labels when they fit. Icons now have pixel-aligned strokes at least one physical pixel thick. Rounded corners, glass shading, active theme colours and press feedback remain.

Fixed-size Docker reveal, every size preset, the compact Auto default, five saved section toggles, native context handling and all 104 actions remain included. Rendering adapts to OS pixel density; it does not modify display settings, REAPER themes or global preferences. A native **1×** capture is included as `Source/previews/LCD-50-percent-1x.png` so the compact appearance can be inspected without a 2× preview hiding small-text issues.

Install the matching DLL and engine and restart REAPER. Automated rendering checks are not a live test of the user's LCD or REAPER Docker. Windows is compiled here; macOS/Linux include the shared source/build kits, with platform compilation and live testing pending. Lua automation only changes version markers.

## Narrow pixel typeface — version 2.2.13

Small presets now use an original embedded pixel alphabet inspired by compact audio-software buttons. Capitals are seven physical pixel cells high at 1× density, with narrow variable-width letters and single-pixel strokes. Text is drawn from solid integer-aligned cells instead of antialiased OS-font outlines. At 50% on a 1× display, standard horizontal button labels—including **AUTO JOIN**, **AUTO MATCH**, **CAPTURE** and **FILL SELECTION**—fit in full within the existing button sizes.

The pixel style applies at 50% and 75%, including compact Auto docking. Larger presets retain the platform font. Higher display densities use integer-sized pixel cells; where a name cannot fit, the existing shorter labels and full tooltips remain available. Unsupported characters, such as Unicode plug-in names in status messages, fall back to the platform font. This is a similar compact pixel style, not an identification or copy of the exact font in a reference screenshot.

The glyph source is compiled into the extension, so no font installation, font download or external asset is required. The same shapes are available to the Windows/macOS/Linux source builds. Existing button dimensions, divider reveal, section preferences, theme colours, press feedback, automation behavior and all 104 actions are retained.

A native 1× render is included at `Source/previews/Pixel-font-50-percent-1x.png`. Install the matching DLL and engine and restart REAPER. Windows was compiled and checked here; macOS/Linux compilation and live platform checks remain pending.

## REAPER 7 Inter fonts and blinking Preview light — version 2.2.14

The native UI now reads `Inter-Regular.ttf` and `Inter-Medium.ttf` from the REAPER application's font folders, using its optional GetExePath API to locate them. The installed Default 7 theme uses these families; Inter became the default theme font in REAPER 7.78. Medium labels use the actual Medium face, without synthesised bold. Files are read once and cached in-process; no OS font installation, font download, font redistribution or REAPER theme modification is performed.

If an older installation lacks the fonts or the path API, the panel uses the platform UI font without blocking extension startup. The shared source checks common Windows/macOS/Linux application resource locations; only the Windows build has been compiled and verified here. The custom compact pixel glyphs from 2.2.13 are removed.

Small label text uses a minimum 11-logical-pixel font while button dimensions remain unchanged. Where a full caption cannot fit, a shorter caption is used instead of font compression; full descriptions remain in tooltips and the Actions list. A native 1× capture is included as `Source/previews/REAPER-font-50-percent-1x.png`.

**Preview indicator:** while Preview is active, a small light inside its button alternates bright/dim green every 400 ms. The label remains steady. Preview off has an unlit lamp; suspended A/B Preview has a steady amber lamp. The existing green/amber button state and selected-track Capture blinking remain. This is a visual indicator only; its timer never sends automation commands.

Fixed-size docking, all presets, five saved section choices, native context handling and all 104 actions are retained. The Lua engine only changes version markers. Install the matching DLL and engine and restart REAPER. Actual LCD/REAPER confirmation and macOS/Linux compilation/live checks remain pending.

Reference: https://www.reaper.fm/download-old.php?ver=7x (REAPER 7.78 default theme font change).

## Full Preview button blinking — version 2.2.15

The entire Preview button alternates bright and dim green every 400 ms while Preview is on. The separate light/dot is removed, and the label has its full button width again. Preview off is steady normal grey; suspended A/B Preview remains steady amber. Text stays readable and no automation commands are sent by blinking.

REAPER Inter fonts, compact sizing, docking/reveal, section choices, all 104 actions and automation behavior are retained. Install the matching DLL and engine and restart REAPER. Windows is compiled and checked here; actual REAPER/LCD confirmation and macOS/Linux builds remain pending.
